# HereBox 部署说明

本文档说明如何在 Ubuntu Server（x86 或 ARM）上部署 HereBox，包括一键安装、WiFi 热点、mDNS 及可选的生产环境配置。

## 环境要求

- **系统**：Ubuntu Server 22.04 / 24.04（或兼容的 Debian 系）
- **网络**：至少一块无线网卡（用于 AP 模式，如 `wlan0`）
- **Node.js**：安装脚本会安装 **Node 22+** 与 **pnpm**，无需预装。

## 一键安装（推荐）

在仓库根目录执行（**必须使用 root**，例如 `sudo`）：

```bash
sudo ./scripts/install.sh
```

脚本**幂等**，可多次执行；也支持单步执行：`sudo ./scripts/install.sh --step STEP_NAME`（步骤名：ensure_user、apt_update、detect_wifi、install_dir、build、openclaw_install、openclaw_patch、openclaw_config、systemd_services、polkit_rules、nginx、mdns、start_services）。

脚本会：

1. 创建系统用户 **herebox**（固定用户名，可通过 `HEREBOX_USER` 覆盖）
2. 安装 Node 22+、pnpm、nginx、avahi-daemon 等
3. 将当前代码拷贝到 `/opt/herebox`（可通过 `HEREBOX_INSTALL_DIR` 覆盖）
4. 以 **herebox** 用户执行 pnpm install 与构建，产出位于 `packages/api/dist` 与 `packages/web/dist`
5. 以 **herebox** 用户安装 **OpenClaw**（pnpm install -g openclaw@latest），并完成 gateway 免认证与 Control UI 绕过等安全配置
6. 安装并启用 systemd 服务 **herebox.service**（API，端口 17321）、**herebox-gateway.service**（OpenClaw gateway，仅 loopback）
7. 安装 Polkit 规则，允许 herebox 管理 systemd 与 NetworkManager（WiFi/热点）
8. 安装并启用 **Nginx** 站点（从 `templates/nginx-herebox.conf` 生成），对外 80 端口提供 SPA、`/api/`、`/openclaw-ui/`
9. 配置 **mDNS**（herebox.local，端口 80），无需再单独执行 setup-mdns.sh

**实际运行的服务均以 herebox 用户执行**。安装完成后，通过 `http://herebox.local` 或设备 IP 的 80 端口即可访问管理界面；登录后菜单栏中的「OpenClaw」可打开 Control UI。

## 启用 WiFi 热点与 Captive Portal

安装完成后，在设备上执行：

```bash
sudo /opt/herebox/scripts/setup-ap.sh
```

会安装并配置 `hostapd`、`dnsmasq`，默认行为：

- **SSID**：`HereBox-Setup`
- **密码**：`herebox123`
- **接口**：`wlan0`
- **AP IP**：`192.168.50.1`，客户端分配 `192.168.50.10–200`
- 所有域名解析到盒子 IP，实现简易 captive portal

可通过环境变量覆盖：

```bash
export HEREBOX_SSID=MyHereBox
export HEREBOX_PASSPHRASE=your_password
export HEREBOX_WIFI_IFACE=wlan0
export HEREBOX_AP_IP=192.168.50.1
export HEREBOX_WIFI_COUNTRY=CN
sudo -E /opt/herebox/scripts/setup-ap.sh
```

`HEREBOX_WIFI_COUNTRY` 为 ISO 3166-1 双字母国家码（如 US、CN），用于 hostapd 与无线管制域；未设置时默认 US。若手机连上热点后超时，可尝试设为当地国家码并重跑脚本。

若本机无线网卡不叫 `wlan0`（例如为 `wlp2s0`、`wlan1` 等），脚本会先尝试自动检测；若检测不到或有多块无线网卡，会列出当前网卡并提示设置 `HEREBOX_WIFI_IFACE`（如 `export HEREBOX_WIFI_IFACE=wlp2s0`）后重试。

**注意**：执行前请为 `wlan0` 配置静态 IP（如 192.168.50.1/24）；若未配置，脚本会尝试自动配置（含写入 `/etc/netplan/99-herebox-ap.yaml` 并执行 `netplan apply`）。该文件与 `/etc/netplan/50-cloud-init.yaml` 互不冲突：netplan 会合并同目录下所有配置，50-cloud-init 通常只配置主网口（如 eth0），99-herebox-ap 仅增加 wlan0 的静态 IP。

## 启用 mDNS（herebox.local）

**一键安装（install.sh）已包含 mDNS 配置**，无需单独执行。若仅需重新应用 mDNS 配置，可执行：

```bash
sudo /opt/herebox/scripts/setup-mdns.sh
```

（内部会调用 `install.sh --step mdns`。）同一局域网内可通过 `http://herebox.local`（端口 80）访问管理界面。

## 生产环境：API + 静态资源

一键安装脚本已包含前端构建，并默认在 `herebox.service` 中设置 `HEREBOX_WEB_DIST=/opt/herebox/packages/web/dist`，因此单进程即可同时提供 API 与 Web 界面，无需额外配置。

若需单独重新构建前端：

```bash
cd /opt/herebox
sudo -u herebox pnpm --filter herebox-web build
sudo systemctl restart herebox.service
```

### 可选：Nginx 反向代理

安装脚本（`install.sh`）会安装 nginx（若未装），并根据 **`templates/nginx-herebox.conf`** 生成并启用 Nginx 站点配置（`/etc/nginx/sites-available/herebox`），包含 SPA 回退、API 反向代理与 OpenClaw Control UI 代理。模板与其它配置模板统一放在项目 **`templates/`** 目录。若安装时跳过了 Nginx，可事后运行 `install.sh --step nginx` 或按下列示例自行配置。

若希望完全由 Nginx 托管静态资源、API 仅提供接口，可：

1. 构建前端：`pnpm --filter herebox-web build`（安装脚本已执行则无需重复）。
2. 取消 API 的静态托管：在 `herebox.service` 中移除或留空 `HEREBOX_WEB_DIST`。
3. Nginx 配置示例（与模板一致，**必须**为前端做 SPA 回退，否则访问 /login、/dashboard 等会 404）：

   ```nginx
   server {
     listen 80;
     server_name herebox.local;
     root /opt/herebox/web/dist;
     index index.html;

     # API 反向代理
     location /api/ {
       proxy_pass http://127.0.0.1:17321;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
     }
     location /health {
       proxy_pass http://127.0.0.1:17321;
     }
     # OpenClaw Control UI：精确 /openclaw-ui（WebSocket）+ 前缀 /openclaw-ui/（页面），避免双斜杠 500
    location = /openclaw-ui {
       proxy_pass http://127.0.0.1:18789/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
       proxy_read_timeout 86400;
       proxy_send_timeout 86400;
       proxy_hide_header Content-Security-Policy;
       proxy_hide_header Content-Security-Policy-Report-Only;
       proxy_hide_header X-Frame-Options;
       add_header Content-Security-Policy "frame-ancestors 'self';";
       add_header X-Frame-Options "SAMEORIGIN";
     }
    location /openclaw-ui/ {
       proxy_pass http://127.0.0.1:18789/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
       proxy_read_timeout 86400;
       proxy_send_timeout 86400;
       proxy_hide_header Content-Security-Policy;
       proxy_hide_header Content-Security-Policy-Report-Only;
       proxy_hide_header X-Frame-Options;
       add_header Content-Security-Policy "frame-ancestors 'self';";
       add_header X-Frame-Options "SAMEORIGIN";
     }

     # SPA：任意路径未命中静态文件时回退到 index.html，避免 /login、/dashboard 等 404
     location / {
       try_files $uri $uri/ /index.html;
     }
   }
   ```

## 开机自检与首次访问

1. 设备上电后，若已执行 `setup-ap.sh`，会创建热点 `HereBox-Setup`。
2. 手机/电脑连接该 WiFi，浏览器可能自动弹出或提示登录；若无，可手动打开 `http://192.168.50.1` 或（若已启用 mDNS）`http://herebox.local`。
3. 使用默认账号登录：`admin` / `herebox`，进入初始化向导或管理面板。
4. 建议首次登录后在「安全设置」中修改密码。

## 服务管理

```bash
sudo systemctl status herebox herebox-gateway   # 状态
sudo systemctl restart herebox herebox-gateway # 重启
sudo journalctl -u herebox -f   # API 日志
sudo journalctl -u herebox-gateway -f   # OpenClaw gateway 日志
```

systemd 单元文件由 install.sh 从 **config/** 目录安装（config/herebox.service、config/herebox-gateway.service），安装时会将路径占位符替换为实际 INSTALL_DIR。

## 配置与数据

- **API 配置**：`~/.herebox/config.json`（以运行 API 的用户为准，如 `herebox` 则为 `/home/herebox/.herebox/config.json`）。
- **环境变量**：`MANAGER_API_PORT` 或 `ONBOARDING_API_PORT` 可修改 API 端口（默认 17321）；`HEREBOX_CONFIG_PATH` 可指定配置文件路径。

## 调试 install.sh 与服务

### 在真机上调试：是否需要拷贝整个工程

- **首次在真机安装**：需要设备上有一份「完整工程」（可克隆仓库或从本机拷贝一次），因为 `install.sh` 会从**当前脚本所在目录的上一级**当作 `ROOT_DIR`，把整份工程同步到 `/opt/herebox`（step_install_dir）。
  - 做法一：在真机上 `git clone` 本仓库，进入目录后执行 `sudo ./scripts/install.sh`。
  - 做法二：在本机打包（如 `tar czf herebox.tar.gz .` 在仓库根目录），传到真机解压到某目录，在该目录下执行 `sudo ./scripts/install.sh`。

- **真机已装过，只改脚本/配置再调试**：**不必每次拷贝整个工程**。设备上已有 `/opt/herebox` 时，只需把**你改动的文件**同步过去，再在真机执行 install 即可（脚本幂等）：
  - 只改了 `scripts/` 或 `config/` 或 `templates/` 时，在本机（仓库根目录）执行：
    ```bash
    rsync -avz scripts/ config/ templates/ 真机用户@真机IP:/opt/herebox/
    ```
    然后在真机上：
    ```bash
    sudo /opt/herebox/scripts/install.sh
    # 或只重跑某一步
    sudo /opt/herebox/scripts/install.sh --step nginx
    ```
  - 若改了 `packages/` 的代码，需要同步对应包并重新构建，例如：
    ```bash
    rsync -avz packages/ 真机用户@真机IP:/opt/herebox/
    ssh 真机用户@真机IP 'cd /opt/herebox && sudo -u herebox pnpm install && sudo -u herebox pnpm run build && sudo systemctl restart herebox'
    ```

- **小结**：第一次在真机装要有一份完整工程；之后调试只需把改动的目录（如 `scripts/`、`config/`、`templates/` 或 `packages/`）同步到真机的 `/opt/herebox`，再在真机执行 install 或对应 `--step` 即可。

### 安装脚本

- **单步执行**（定位卡在哪一步）：
  ```bash
  sudo ./scripts/install.sh --step ensure_user
  sudo ./scripts/install.sh --step apt_update
  sudo ./scripts/install.sh --step install_dir
  sudo ./scripts/install.sh --step build
  # ... 依此类推，步骤名见脚本 DISPATCH_STEPS
  ```
- **打开命令跟踪**（看实际执行的每行命令）：
  ```bash
  HEREBOX_DEBUG=1 sudo -E ./scripts/install.sh
  # 或只跟踪某一步
  HEREBOX_DEBUG=1 sudo -E ./scripts/install.sh --step build
  ```
- **用 bash -x 直接跟踪**（不依赖 HEREBOX_DEBUG）：
  ```bash
  sudo bash -x ./scripts/install.sh --step build
  ```
- **在非 root 下先做语法/逻辑检查**（不真正执行需 root 的步骤）：
  ```bash
  bash -n ./scripts/install.sh   # 仅语法检查
  ```

### 服务与进程

- **看服务状态与最近日志**：
  ```bash
  sudo systemctl status herebox herebox-gateway nginx
  sudo journalctl -u herebox -n 50 --no-pager
  sudo journalctl -u herebox-gateway -n 50 --no-pager
  sudo journalctl -u nginx -n 50 --no-pager
  ```
- **以 herebox 用户手动跑 API**（排查环境/依赖）：
  ```bash
  sudo -u herebox env NODE_ENV=production MANAGER_API_PORT=17321 \
    node /opt/herebox/packages/api/dist/index.js
  ```
- **以 herebox 用户手动跑 OpenClaw gateway**（看是否报错）：
  ```bash
  sudo -u herebox env HOME=/home/herebox /home/herebox/.local/bin/openclaw gateway --allow-unconfigured --bind loopback
  ```
- **检查端口与 Nginx 配置**：
  ```bash
  ss -tlnp | grep -E '80|17321|18789'
  sudo nginx -t
  cat /etc/nginx/sites-enabled/herebox
  ```

### 构建与 OpenClaw

- **在安装目录下用 herebox 用户重跑构建**：
  ```bash
  cd /opt/herebox
  sudo -u herebox pnpm install && sudo -u herebox pnpm run build
  ```
- **检查 OpenClaw 与 pnpm 全局**：
  ```bash
  sudo -u herebox env HOME=/home/herebox /home/herebox/.local/bin/openclaw --version
  sudo -u herebox env HOME=/home/herebox pnpm root -g
  ```

## 故障排查与更新策略

- **无法访问 herebox.local**：install.sh 已配置 mDNS（herebox.local 指向 80 端口）；确认客户端与设备在同一局域网，可先用设备 IP 或 http://设备IP 测试。
- **连接热点后无法打开页面**：确认 dnsmasq 与 hostapd 已启动，且 AP 接口（默认 wlan0/wlp\*）的 IP 为 192.168.50.1。
- **手机连接热点后一直「正在获取 IP」**：DHCP 由 dnsmasq 提供。先确认 `sudo systemctl status dnsmasq` 为 active；若未运行则执行 `sudo systemctl start dnsmasq` 或重新运行 `sudo /opt/herebox/scripts/setup-ap.sh`。确认 `/etc/dnsmasq.d/herebox.conf` 存在且含 `dhcp-range=...`；若有防火墙，需放行 UDP 67/68（见下文防火墙说明）。
- **`Failed to enable unit: Unit file hostapd.service is masked`**：部分发行版会 mask hostapd。`setup-ap.sh` 已自动在 enable 前执行 `systemctl unmask hostapd`；若仍报错，可先手动执行 `sudo systemctl unmask hostapd` 再重新运行脚本。
- **`Job for dnsmasq.service failed`**：多为 wlan0 尚未配置静态 IP 或 53 端口被占用。处理步骤：(1) 按脚本提示为 wlan0 配置 192.168.50.1/24（netplan 或其它方式），执行 `sudo netplan apply`；(2) 再执行一次 `sudo /opt/herebox/scripts/setup-ap.sh`。若仍失败，可查看 `journalctl -xeu dnsmasq.service`；若为 systemd-resolved 占用 53，脚本中的 dnsmasq 已配置为仅监听 192.168.50.1，一般不会冲突。
- **启用了 ufw/iptables 之后热点能连上但打不开网页**：install.sh 会在检测到 WiFi 接口后，自动为 AP 接口添加防火墙放行规则（UDP 67/68/53，TCP 80/443）。若你有自己的防火墙脚本，需确保 INPUT 链允许来自 AP 网段（默认 192.168.50.0/24）在 WiFi 接口上的这些端口流量，否则手机只能拿到 IP 但访问不到页面。
- **API 无法启动**：查看 `journalctl -u herebox`；确认 Node 版本 ≥20、`/opt/herebox/packages/api/dist/index.js` 存在且 `herebox` 用户有读权限。
- **Nginx 下访问 /login 或 /dashboard 返回 404**：前端为 SPA，需在 `location /` 中配置 `try_files $uri $uri/ /index.html;`，使未命中静态文件时回退到 index.html。参见上文「可选：Nginx 反向代理」配置示例。

### 安装脚本与 Setup 向导

- **install.sh 的职责**：
  - 仅用于设备首次安装或重大修复（root 下执行）。
  - 安装系统依赖（Node、pnpm、nginx、hostapd、dnsmasq、avahi 等）、创建 `herebox` 用户、部署 `/opt/herebox` 代码与 systemd 单元，并初始化 AP、防火墙规则。
  - 正常运行过程中不需要重复执行 install.sh，日常升级通过 Web 向导中的 `update-app` 完成。
- **Setup 向导步骤**：
  - `configure-wifi`：通过 Web 界面扫描附近 Wi‑Fi，并连接家庭路由；或选择跳过（仅使用有线）。
  - `update-app`：在设备上执行应用更新（开发机使用 `git pull`，量产设备使用 Release tar.gz 包）。
  - `configure-ai`：配置默认 AI 提供商（模型名称、API Key、Endpoint 等）。
  - `configure-channel`：可选的通知/消息渠道（如 Telegram），可在界面中跳过。
  - `complete`：所有必要步骤完成后，向导标记结束并引导用户进入 Dashboard。

### dev/stable 更新模式

- **环境变量 `HEREBOX_UPDATE_MODE`**：
  - `dev`：开发/内测设备；`/opt/herebox` 为 git 仓库，`update-app` 使用 `git pull --rebase` + `pnpm install` + `pnpm run build` 并重启服务。
  - `stable`：量产设备；`/opt/herebox` 作为发布目录，没有 `.git`，`update-app` 通过 Release tar.gz 包升级。
  - `auto`（默认）：若检测到 `/.git` 则按 `dev`；否则按 `stable`。
- **stable 模式 Release 升级**：
  - 通过环境变量 `HEREBOX_UPDATE_MANIFEST_URL` 提供一个 JSON manifest，例如：

    ```json
    {
      "version": "2025.03.12.1",
      "url": "https://github.com/OWNER/herebox/releases/download/v2025.03.12.1/herebox-2025.03.12.1.tar.gz",
      "sha256": "..."
    }
    ```

  - 设备上的 `update-app` 步骤会：
    - 下载 manifest（JSON，含 `version`、`url`、`sha256`）并读取最新 `version` 与 tarball `url`。
    - 读取本地 `$INSTALL_DIR/VERSION`（若存在），若版本一致则跳过更新。
    - 下载 tar.gz 到 `/opt/herebox-updates/`，**用 manifest 中的 `sha256` 校验**，校验通过后解压到 `/opt/herebox-releases/herebox-$VERSION/`。
    - 使用 `rsync` 将新版本同步到当前安装目录（默认 `/opt/herebox`），再以 `herebox` 用户执行 `pnpm install` 与 `pnpm run build`。
    - 重启 `herebox`、`herebox-gateway` 与 `nginx` 服务，并更新本地 `VERSION`。

## GitHub CI/CD 与自动版本发布

仓库内提供 GitHub Actions 工作流，与上述系统升级流程配套使用。

- **CI（`.github/workflows/ci.yml`）**
  - 触发：推送到 `main`/`master` 或针对该分支的 PR。
  - 内容：安装依赖（pnpm）、执行 `pnpm run build`，用于合并前检查构建是否通过。

- **Release（`.github/workflows/release.yml`）**
  - 触发：推送**标签**且标签名符合 `v*`。
  - **版本号规则**：日期 + 顺序号，格式 **YYYY.MM.DD.N**（如 `2025.03.12.1` 表示 2025-03-12 第 1 个发布）。打 tag 时使用 `v` + 版本号，如 `v2025.03.12.1`。
  - 内容：
    1. 安装依赖并执行 `pnpm run build`（与 CI 一致）。
    2. 在仓库根目录写入 `VERSION` 文件（内容为当前版本号），再打包生成 `herebox-<version>.tar.gz`（不含 `.git`、`node_modules`，与 install.sh 拷贝内容一致；解压后含 `VERSION`，便于设备与 stable 升级流程判断本地版本）。
    3. 计算 tarball 的 SHA256，生成 **checksum 清单 JSON** `herebox-<version>.json`，字段：`version`、`url`（该版本 tarball 的下载地址）、`sha256`，供升级时下载后校验完整性。
    4. 创建 GitHub Release，附上 tarball 与上述 JSON 两个附件，并自动生成 Release 说明。

**发布新版本步骤**（在本地或协作流程中）：

```bash
# 版本号 = 年.月.日.顺序号，同一天多次发布递增顺序号即可
git tag v2025.03.12.1
git push origin v2025.03.12.1
```

推送后 GitHub 会自动运行 Release 工作流；完成后在仓库的 **Releases** 页面可看到新版本及 `herebox-2025.03.12.1.tar.gz`、`herebox-2025.03.12.1.json` 两个附件。JSON 内容即 manifest 格式（`version`、`url`、`sha256`）。

**推荐：初始部署无需额外配置**。仓库根目录 `package.json` 已包含标准字段 `repository`（如 `"repository": { "type": "git", "url": "https://github.com/Woods30/herebox.git" }`），API 会从中解析出 `owner/repo`（如 `Woods30/herebox`），用于：
- **最新版本展示**：通过 GitHub Releases API 获取最新 release 的 tag 并展示。
- **升级**：用户点击「开始升级」时，前端将「最新版本」作为 `targetVersion` 传给 API；API 构造该版本的 manifest 地址并拉取、下载、校验、解压、执行 install.sh。

若部署时需覆盖仓库地址（例如 fork 或自建 Git），可设置环境变量 `HEREBOX_GITHUB_REPO=owner/repo`，优先于 package.json。自建 manifest 仍可配置 `HEREBOX_UPDATE_MANIFEST_URL`。
