#!/usr/bin/env bash
# mDNS is handled by install.sh step_mdns; this script runs the same logic when invoked alone (idempotent).
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "[herebox] Run setup-mdns.sh as root" >&2
  exit 1
fi

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
INSTALL_DIR="${HEREBOX_INSTALL_DIR:-/opt/herebox}"

if [ -f "$ROOT_DIR/scripts/install.sh" ]; then
  exec bash "$ROOT_DIR/scripts/install.sh" --step mdns
fi
if [ -f "$INSTALL_DIR/scripts/install.sh" ]; then
  exec bash "$INSTALL_DIR/scripts/install.sh" --step mdns
fi
echo "[herebox] mDNS is configured by install.sh. Run: sudo bash install.sh" >&2
exit 1
