#!/usr/bin/env bash
set -euo pipefail

# HereBox setup script.
# Protocol for wizard:
#   - stdout "##STEPS:step1,step2,..." once at the beginning
#   - stdout "##STEP:<id>:start|success|error[:message]" for step state
# This script can also run a single step:
#   bash herebox-setup.sh --step configure-wifi

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
HEREBOX_USER="${HEREBOX_USER:-herebox}"
API_PORT="${MANAGER_API_PORT:-17321}"

STEPS=(
  configure-wifi
  configure-ai
  configure-channel
  complete
)

log_step() {
  local id="$1"
  local level="$2"
  local msg="$3"
  echo "##STEP:${id}:${level}:${msg}"
}

step_error() {
  local id="$1"
  local msg="${2:-Unknown error}"
  log_step "$id" "error" "$msg"
  exit 1
}

run_configure-wifi() {
  local id="configure-wifi"
  log_step "$id" "log" "Checking WiFi status API for setup..."

  if ! curl -fsS -H "x-herebox-internal: setup" "http://127.0.0.1:${API_PORT}/api/wifi/status" >/dev/null 2>&1; then
    log_step "$id" "error" "WiFi status API (/api/wifi/status) is not reachable. Ensure HereBox API is running."
    return 1
  fi

  log_step "$id" "log" "WiFi API reachable. Use the web UI WiFi step to scan and connect."
  return 0
}

run_configure-ai() {
  local id="configure-ai"
  log_step "$id" "log" "Checking AI providers API..."

  if ! curl -fsS -H "x-herebox-internal: setup" "http://127.0.0.1:${API_PORT}/api/ai-providers" >/dev/null 2>&1; then
    log_step "$id" "error" "AI providers API (/api/ai-providers) is not reachable."
    return 1
  fi

  log_step "$id" "log" "AI providers API reachable. Configure AI models in the web UI."
  return 0
}

run_configure-channel() {
  local id="configure-channel"
  log_step "$id" "log" "Checking channels API..."

  if ! curl -fsS -H "x-herebox-internal: setup" "http://127.0.0.1:${API_PORT}/api/openclaw/channels" >/dev/null 2>&1; then
    log_step "$id" "error" "Channels API (/api/openclaw/channels) is not reachable."
    return 1
  fi

  log_step "$id" "log" "Channels API reachable. Channel configuration is optional and can be skipped in the UI."
  return 0
}

run_complete() {
  local id="complete"
  log_step "$id" "start" ""
  # TODO: any finalization logic if needed
  log_step "$id" "log" "setup complete"
  log_step "$id" "success" ""
}

run_step() {
  local step="$1"
  case "$step" in
    configure-wifi|configure-ai|configure-channel|complete)
      "run_${step}"
      ;;
    *)
      echo "[herebox-setup] Unknown step: $step" >&2
      exit 1
      ;;
  esac
}

if [ "${1:-}" = "--step" ]; then
  step_name="${2:-}"
  if [ -z "$step_name" ]; then
    echo "[herebox-setup] Missing step name for --step" >&2
    exit 1
  fi
  run_step "$step_name"
  exit 0
fi

# Wizard mode: run all steps sequentially
echo "##STEPS:configure-wifi,configure-ai,configure-channel,complete"

for s in "${STEPS[@]}"; do
  # start event without message (wizard.js treats this as status change)
  echo "##STEP:${s}:start"
  if run_step "$s"; then
    echo "##STEP:${s}:success"
  else
    # run_step already printed error event; just stop here with non-zero code
    exit 1
  fi
done

