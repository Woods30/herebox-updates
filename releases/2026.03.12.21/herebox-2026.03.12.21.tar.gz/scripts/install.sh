#!/usr/bin/env bash
# HereBox Installer — idempotent, step-based install for fresh or update.
#
# Usage:
#   sudo bash install.sh              — full install
#   sudo bash install.sh --step NAME  — run a single step
#
# Environment variables:
#   HEREBOX_USER        — system user (default: herebox)
#   HEREBOX_INSTALL_DIR — install target (default: /opt/herebox)
#   NETWORK_INTERFACE   — WiFi interface override (optional)
#   HEREBOX_DEBUG       — set to 1 to trace commands (set -x) for debugging
set -euo pipefail
[ "${HEREBOX_DEBUG:-0}" = "1" ] && set -x

# ── Require root ─────────────────────────────────────────────────────────────

if [ "$(id -u)" -ne 0 ]; then
  echo "[herebox] Run install.sh as root (e.g. sudo bash install.sh)" >&2
  exit 1
fi

# ── Constants ────────────────────────────────────────────────────────────────

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
HEREBOX_USER="${HEREBOX_USER:-herebox}"
HEREBOX_HOME="/home/$HEREBOX_USER"
INSTALL_DIR="${HEREBOX_INSTALL_DIR:-/opt/herebox}"
OPENCLAW_VERSION="${OPENCLAW_VERSION:-}"  # empty = use latest from pnpm
API_PORT="${MANAGER_API_PORT:-17321}"
PNPM_HOME="$HEREBOX_HOME/.local/share/pnpm"
OPENCLAW_BIN="$HEREBOX_HOME/.local/bin/openclaw"
POLKIT_PKLA_DIR="/etc/polkit-1/localauthority/50-local.d"
NGINX_AVAILABLE="/etc/nginx/sites-available/herebox"
NGINX_ENABLED="/etc/nginx/sites-enabled/herebox"
AVAHI_SERVICE_FILE="/etc/avahi/services/herebox.service"

# ── Helpers ──────────────────────────────────────────────────────────────────

as_herebox() { sudo -u "$HEREBOX_USER" "$@"; }
as_herebox_login() { su - "$HEREBOX_USER" -c "$*"; }

# 标记当前是否为“升级模式”（由升级服务触发，而非首次全新安装）
HEREBOX_UPGRADE_FLAG="${HEREBOX_UPGRADE:-0}"
if [ "${1:-}" = "--upgrade" ]; then
  HEREBOX_UPGRADE_FLAG=1
fi

log_install_step() {
  # Usage: log_install_step <id> <status> [message]
  # id: human-friendly business step id, e.g. prepare-system / install-dependencies / install-herebox / build-herebox / install-openclaw / configure-services / network-access / finalize
  # status: start|success|error
  local id="$1"
  local status="$2"
  local msg="${3:-}"
  if [ -n "$msg" ]; then
    echo "##STEP:install:${id}:${status}:${msg}"
  else
    echo "##STEP:install:${id}:${status}"
  fi
}

ensure_global_openclaw_path() {
  # Ensure HEREBOX_HOME/.local/bin is in system-wide PATH for interactive shells.
  local PROFILE_D="/etc/profile.d"
  local SCRIPT="$PROFILE_D/herebox-openclaw.sh"
  mkdir -p "$PROFILE_D"
  cat > "$SCRIPT" <<EOF
# Added by HereBox install.sh (idempotent)
if ! printf '%s' ":\$PATH:" | grep -q ":$HEREBOX_HOME/.local/bin:"; then
  export PATH="$HEREBOX_HOME/.local/bin:\$PATH"
fi
EOF
  chmod 644 "$SCRIPT" 2>/dev/null || true
}

wifi_already_configured() {
  # 与 API 与 herebox-setup.sh 保持一致：优先 HEREBOX_CONFIG_PATH，其次 herebox 用户目录
  local CONFIG_PATH
  if [ -n "${HEREBOX_CONFIG_PATH:-}" ]; then
    CONFIG_PATH="$HEREBOX_CONFIG_PATH"
  else
    CONFIG_PATH="$HEREBOX_HOME/.herebox/config.json"
  fi

  if [ -f "$CONFIG_PATH" ]; then
    # wifiConfigured 为 true 表示已配置过 WiFi
    # shellcheck disable=SC2016
    if node -e "const fs=require('fs');try{const c=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));if(c && c.wifiConfigured){process.exit(0)} }catch(e){}process.exit(1)" "$CONFIG_PATH"; then
      return 0
    fi
  fi
  return 1
}

# ── Step: ensure user ────────────────────────────────────────────────────────

step_ensure_user() {
  log_install_step "prepare-system" "start" "Ensuring herebox system user"
  if ! id -u "$HEREBOX_USER" &>/dev/null; then
    echo "  Creating user $HEREBOX_USER ..."
    useradd -m -s /bin/bash "$HEREBOX_USER"
    for grp in sudo video audio; do
      getent group "$grp" &>/dev/null && usermod -aG "$grp" "$HEREBOX_USER" 2>/dev/null || true
    done
    echo "  User $HEREBOX_USER created (uid=$(id -u "$HEREBOX_USER"))"
  else
    echo "  User $HEREBOX_USER exists (uid=$(id -u "$HEREBOX_USER"))"
  fi
  ensure_global_openclaw_path
  log_install_step "prepare-system" "success" "System user ready"
}

# ── Step: apt update + Node 22 + nginx + pnpm ────────────────────────────────

step_apt_update() {
  log_install_step "install-dependencies" "start" "Installing system dependencies (Node.js, pnpm, nginx, tools)"
  apt-get update -qq
  apt-get install -y -qq git curl network-manager avahi-daemon iptables iw
  # Node.js 22+
  if node --version 2>/dev/null | grep -qE '^v(2[2-9]|[3-9][0-9])\.'; then
    echo "  Node.js $(node --version) already installed"
  else
    echo "  Installing Node.js 22..."
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y -qq nodejs
    echo "  Node.js $(node --version) installed"
  fi
  # pnpm (corepack)
  if command -v corepack &>/dev/null; then
    corepack enable pnpm 2>/dev/null || true
  fi
  if ! sudo -u "$HEREBOX_USER" env "HOME=$HEREBOX_HOME" pnpm --version &>/dev/null; then
    npm install -g pnpm 2>/dev/null || true
  fi
  # nginx
  if command -v nginx &>/dev/null && [ -d /etc/nginx ]; then
    echo "  nginx already installed"
  else
    apt-get install -y -qq nginx
    echo "  nginx installed"
  fi
  log_install_step "install-dependencies" "success" "System dependencies installed"
}

# ── Step: detect WiFi (optional) ──────────────────────────────────────────────

step_detect_wifi() {
  local WIFI_IFACE="${NETWORK_INTERFACE:-}"
  if [ -z "$WIFI_IFACE" ]; then
    WIFI_IFACE=$(iw dev 2>/dev/null | awk '/Interface/{print $2}' | head -1)
  fi
  if [ -z "$WIFI_IFACE" ]; then
    echo "  No WiFi interface detected, skipping network.env (set NETWORK_INTERFACE to override)"
    return 0
  fi
  if ! iw dev "$WIFI_IFACE" info &>/dev/null; then
    echo "  Warning: $WIFI_IFACE is not a wireless interface, skipping"
    return 0
  fi
  echo "  WiFi interface: $WIFI_IFACE"
  mkdir -p "$INSTALL_DIR/data" /etc/herebox
  printf 'NETWORK_INTERFACE=%s\n' "$WIFI_IFACE" > "$INSTALL_DIR/data/network.env"
  printf 'NETWORK_INTERFACE=%s\n' "$WIFI_IFACE" > /etc/herebox/network.env
  chown "$HEREBOX_USER:$HEREBOX_USER" "$INSTALL_DIR/data" "$INSTALL_DIR/data/network.env" 2>/dev/null || true
  chmod 644 /etc/herebox/network.env
}

# ── Step: firewall rules for WiFi AP (ufw/iptables) ───────────────────────────

step_firewall_ap() {
  local WIFI_IFACE AP_IP

  AP_IP="${HEREBOX_AP_IP:-192.168.50.1}"

  if [ -f /etc/herebox/network.env ]; then
    # shellcheck disable=SC1091
    . /etc/herebox/network.env
  fi

  WIFI_IFACE="${NETWORK_INTERFACE:-${NETWORK_INTERFACE_OVERRIDE:-}}"
  if [ -z "$WIFI_IFACE" ]; then
    WIFI_IFACE=$(iw dev 2>/dev/null | awk '/Interface/{print $2}' | head -1)
  fi

  if [ -z "$WIFI_IFACE" ]; then
    echo "  No WiFi interface found; skipping firewall_ap step"
    return 0
  fi

  echo "  Configuring firewall for WiFi AP on $WIFI_IFACE ($AP_IP)..."

  # ufw: allow DHCP (67/68), DNS (53), HTTP/HTTPS (80/443) from AP network
  if command -v ufw &>/dev/null; then
    local UFW_STATUS
    UFW_STATUS=$(ufw status 2>/dev/null | head -1 || echo "")
    if echo "$UFW_STATUS" | grep -qi "active"; then
      ufw allow in on "$WIFI_IFACE" to any port 67 proto udp || true
      ufw allow in on "$WIFI_IFACE" to any port 68 proto udp || true
      ufw allow in on "$WIFI_IFACE" to any port 53 proto udp || true
      ufw allow in on "$WIFI_IFACE" to any port 80 proto tcp || true
      ufw allow in on "$WIFI_IFACE" to any port 443 proto tcp || true
      echo "  ufw rules for AP interface ensured (if ufw is active)"
    else
      echo "  ufw not active; skipping ufw rules"
    fi
  fi

  # iptables: allow DHCP (67/68), DNS (53), HTTP/HTTPS (80/443) from AP subnet
  if command -v iptables &>/dev/null; then
    local AP_NET="192.168.50.0/24"
    if [ -n "$AP_IP" ]; then
      AP_NET="${AP_IP%.*}.0/24"
    fi

    iptables -C INPUT -i "$WIFI_IFACE" -p udp --dport 67 -j ACCEPT 2>/dev/null || \
      iptables -A INPUT -i "$WIFI_IFACE" -p udp --dport 67 -j ACCEPT 2>/dev/null || true
    iptables -C INPUT -i "$WIFI_IFACE" -p udp --dport 68 -j ACCEPT 2>/dev/null || \
      iptables -A INPUT -i "$WIFI_IFACE" -p udp --dport 68 -j ACCEPT 2>/dev/null || true
    iptables -C INPUT -i "$WIFI_IFACE" -p udp --dport 53 -s "$AP_NET" -j ACCEPT 2>/dev/null || \
      iptables -A INPUT -i "$WIFI_IFACE" -p udp --dport 53 -s "$AP_NET" -j ACCEPT 2>/dev/null || true
    iptables -C INPUT -i "$WIFI_IFACE" -p tcp --dport 80 -s "$AP_NET" -j ACCEPT 2>/dev/null || \
      iptables -A INPUT -i "$WIFI_IFACE" -p tcp --dport 80 -s "$AP_NET" -j ACCEPT 2>/dev/null || true
    iptables -C INPUT -i "$WIFI_IFACE" -p tcp --dport 443 -s "$AP_NET" -j ACCEPT 2>/dev/null || \
      iptables -A INPUT -i "$WIFI_IFACE" -p tcp --dport 443 -s "$AP_NET" -j ACCEPT 2>/dev/null || true

    echo "  iptables rules for AP interface ensured (UDP 67/68/53, TCP 80/443 from $AP_NET)"
  else
    echo "  iptables not found; skipping iptables rules"
  fi
}

# ── Step: install dir (rsync) ─────────────────────────────────────────────────

step_install_dir() {
  log_install_step "install-herebox" "start" "Copying HereBox to install directory"
  echo "  Copying HereBox to $INSTALL_DIR ..."
  mkdir -p "$INSTALL_DIR"
  if command -v rsync &>/dev/null; then
    rsync -a --exclude '.git' --exclude 'node_modules' "$ROOT_DIR/" "$INSTALL_DIR/"
  else
    cp -a "$ROOT_DIR"/* "$INSTALL_DIR/" 2>/dev/null || true
    for f in .gitignore .env.example; do [ -f "$ROOT_DIR/$f" ] && cp -a "$ROOT_DIR/$f" "$INSTALL_DIR/" 2>/dev/null || true; done
  fi
  chown -R "$HEREBOX_USER:$HEREBOX_USER" "$INSTALL_DIR"
  find "$INSTALL_DIR/scripts" -name "*.sh" -exec chmod +x {} + 2>/dev/null || true
  echo "  Synced to $INSTALL_DIR"
  log_install_step "install-herebox" "success" "HereBox files installed"
}

# ── Step: build ─────────────────────────────────────────────────────────────

step_build() {
  if [ ! -f "$INSTALL_DIR/package.json" ]; then
    echo "  Skipping build (no package.json)"
    return 0
  fi
  log_install_step "build-herebox" "start" "Installing dependencies and building HereBox"
  echo "  Installing dependencies and building..."
  as_herebox_login "cd $INSTALL_DIR && pnpm install && pnpm run build"
  if [ ! -f "$INSTALL_DIR/packages/api/dist/index.js" ] || [ ! -d "$INSTALL_DIR/packages/web/dist" ]; then
    echo "  Warning: build artifacts may be incomplete, check pnpm and Node version" >&2
  else
    echo "  Build complete"
  fi
  log_install_step "build-herebox" "success" "HereBox build finished"
}

# ── Step: OpenClaw install (pnpm global) ────────────────────────────────────

step_openclaw_install() {
  mkdir -p "$HEREBOX_HOME/.local/share/pnpm" "$HEREBOX_HOME/.local/bin"
  chown -R "$HEREBOX_USER:$HEREBOX_USER" "$HEREBOX_HOME/.local"
  as_herebox env "HOME=$HEREBOX_HOME" "PATH=$HEREBOX_HOME/.local/bin:$PATH" pnpm config set global-dir "$PNPM_HOME" 2>/dev/null || true
  as_herebox env "HOME=$HEREBOX_HOME" "PATH=$HEREBOX_HOME/.local/bin:$PATH" pnpm config set global-bin-dir "$HEREBOX_HOME/.local/bin" 2>/dev/null || true
  if [ -x "$OPENCLAW_BIN" ]; then
    local VER
    VER=$(as_herebox "$OPENCLAW_BIN" --version 2>/dev/null || echo "")
    echo "  OpenClaw already installed: $VER"
    log_install_step "install-openclaw" "success" "OpenClaw already installed"
    return 0
  fi
  log_install_step "install-openclaw" "start" "Installing OpenClaw runtime"
  echo "  Installing OpenClaw (pnpm install -g openclaw@latest)..."
  as_herebox env "HOME=$HEREBOX_HOME" "PATH=$HEREBOX_HOME/.local/bin:$PATH" "PNPM_HOME=$PNPM_HOME" \
    pnpm install -g "openclaw@${OPENCLAW_VERSION:-latest}"
  if [ ! -x "$OPENCLAW_BIN" ]; then
    echo "Error: OpenClaw binary not found after install: $OPENCLAW_BIN" >&2
    log_install_step "install-openclaw" "error" "OpenClaw binary not found after install"
    exit 1
  fi
  echo "  OpenClaw installed: $(as_herebox "$OPENCLAW_BIN" --version 2>/dev/null || echo 'unknown')"
  log_install_step "install-openclaw" "success" "OpenClaw installed"
}

# ── Step: OpenClaw patch (scope + device bypass) ───────────────────────────

step_openclaw_patch() {
  [ -x "$OPENCLAW_BIN" ] || return 0
  as_herebox "$OPENCLAW_BIN" config set gateway.controlUi.allowInsecureAuth true --json 2>/dev/null || true
  echo "  allowInsecureAuth set"
  local GATEWAY_DIST
  GATEWAY_DIST=$(as_herebox env "HOME=$HEREBOX_HOME" "PATH=$HEREBOX_HOME/.local/bin:$PATH" pnpm root -g 2>/dev/null)/openclaw/dist
  if [ ! -d "$GATEWAY_DIST" ]; then
    GATEWAY_DIST="$HEREBOX_HOME/.local/share/pnpm/global/node_modules/openclaw/dist"
  fi
  if [ ! -d "$GATEWAY_DIST" ]; then
    for d in "$HEREBOX_HOME/.local/share/pnpm/global"*/node_modules/openclaw/dist; do
      [ -d "$d" ] && GATEWAY_DIST=$d && break
    done
  fi
  if [ ! -d "$GATEWAY_DIST" ]; then
    echo "  Warning: GATEWAY_DIST not found, skipping gateway source patch"
    return 0
  fi
  local PATCHED_MARKER='isControlUi && allowControlUiBypass'
  if grep -qrl "$PATCHED_MARKER" "$GATEWAY_DIST" 2>/dev/null; then
    echo "  Gateway scope patch: already applied"
  else
    local SCOPE_FILES
    SCOPE_FILES=$(grep -Prl 'if\s*\(\s*scopes\.length\s*>\s*0\s*\)\s*\{' "$GATEWAY_DIST" 2>/dev/null || true)
    if [ -n "$SCOPE_FILES" ]; then
      for f in $SCOPE_FILES; do
        sed -i -E 's/if[[:space:]]*\([[:space:]]*scopes\.length[[:space:]]*>[[:space:]]*0[[:space:]]*\)[[:space:]]*\{/if (scopes.length > 0 \&\& !(isControlUi \&\& allowControlUiBypass)) {/g' "$f"
      done
      echo "  Gateway scope patch applied"
    fi
  fi
  local DEVICE_MARKER='controlUiAuthPolicy.allowBypass) return'
  local DEVICE_FILES
  DEVICE_FILES=$(grep -rl 'reject-device-required' "$GATEWAY_DIST" 2>/dev/null || true)
  if [ -z "$DEVICE_FILES" ]; then
    echo "  Device identity patch: target not found, skipping"
    return 0
  fi
  local NEEDS_PATCH=""
  for f in $DEVICE_FILES; do
    grep -q "$DEVICE_MARKER" "$f" 2>/dev/null || NEEDS_PATCH="$NEEDS_PATCH $f"
  done
  if [ -z "$NEEDS_PATCH" ]; then
    echo "  Device identity patch: already applied"
    return 0
  fi
  for f in $NEEDS_PATCH; do
    sed -i 's|if (roleCanSkipDeviceIdentity(params.role, params.sharedAuthOk)) return { kind: "allow" };|if (roleCanSkipDeviceIdentity(params.role, params.sharedAuthOk)) return { kind: "allow" };\n\tif (params.isControlUi \&\& params.controlUiAuthPolicy.allowBypass) return { kind: "allow" };|' "$f"
  done
  echo "  Device identity patch applied"
}

# ── Step: OpenClaw config（管理 gateway auth token 与 Control UI 策略） ────────
# 若 openclaw.json 不存在则从仓库模版复制；若已存在则只合并必要字段，不整文件覆盖。

step_openclaw_config() {
  local OPENCLAW_CONFIG="$HEREBOX_HOME/.openclaw/openclaw.json"
  mkdir -p "$HEREBOX_HOME/.openclaw"
  chown "$HEREBOX_USER:$HEREBOX_USER" "$HEREBOX_HOME/.openclaw"

  if [ ! -f "$OPENCLAW_CONFIG" ]; then
    local TPL
    for TPL in "$INSTALL_DIR/templates/openclaw.json" "$ROOT_DIR/templates/openclaw.json"; do
      if [ -f "$TPL" ]; then
        echo "  Initializing OpenClaw config from template: $TPL"
        cp "$TPL" "$OPENCLAW_CONFIG"
        break
      fi
    done
    if [ ! -f "$OPENCLAW_CONFIG" ]; then
      echo "  Warning: template not found at ROOT_DIR or INSTALL_DIR/templates/openclaw.json; gateway-only config will be written"
    fi
  else
    echo "  OpenClaw config exists, merging required gateway fields only"
  fi

  # 只更新 gateway 相关字段，其余配置（agents/models/channels 等）保持不变。
  # 若未配置 gateway.auth.token，则为当前安装生成一个随机 token；已存在的 token 保持不变。
  OPENCLAW_CONFIG="$OPENCLAW_CONFIG" node -e "
const fs=require('fs');
const crypto=require('crypto');
const p=process.env.OPENCLAW_CONFIG;
let c;
try { c=JSON.parse(fs.readFileSync(p,'utf8')); } catch(e) { c={}; }
if(!c.gateway) c.gateway={};
if(!c.gateway.auth) c.gateway.auth={};
if(!c.gateway.auth.mode) c.gateway.auth.mode='token';
if(!c.gateway.auth.token){
  c.gateway.auth.token=crypto.randomBytes(24).toString('hex');
}
if(!c.gateway.controlUi) c.gateway.controlUi={};
c.gateway.controlUi.allowInsecureAuth=true;
c.gateway.controlUi.dangerouslyDisableDeviceAuth=true;
fs.writeFileSync(p,JSON.stringify(c,null,2));
"

  chown -R "$HEREBOX_USER:$HEREBOX_USER" "$HEREBOX_HOME/.openclaw" 2>/dev/null || true
  echo "  OpenClaw config updated"
}

# ── Step: systemd services ───────────────────────────────────────────────────

step_systemd_services() {
  local SRC
  for name in herebox herebox-gateway; do
    SRC="$INSTALL_DIR/config/${name}.service"
    if [ ! -f "$SRC" ]; then
      SRC="$ROOT_DIR/config/${name}.service"
    fi
    if [ -f "$SRC" ]; then
      sed -e "s|INSTALL_DIR_PLACEHOLDER|$INSTALL_DIR|g" -e "s|HEREBOX_HOME_PLACEHOLDER|$HEREBOX_HOME|g" "$SRC" > "/etc/systemd/system/${name}.service"
      echo "  Installed ${name}.service"
    fi
  done
  # 为会话签名生成持久化的 HEREBOX_SESSION_SECRET（若尚未存在）
  local ENV_DIR="/etc/herebox"
  local ENV_FILE="$ENV_DIR/env"
  mkdir -p "$ENV_DIR"
  if ! grep -q '^HEREBOX_SESSION_SECRET=' "$ENV_FILE" 2>/dev/null; then
    local SECRET
    if command -v openssl >/dev/null 2>&1; then
      SECRET="$(openssl rand -hex 32)"
    else
      SECRET="$(head -c 32 /dev/urandom | tr -dc 'a-f0-9' | head -c 64)"
    fi
    {
      echo "# HereBox session secret (HMAC for stateless cookies)"
      echo "HEREBOX_SESSION_SECRET=$SECRET"
    } >> "$ENV_FILE"
    echo "  Generated HEREBOX_SESSION_SECRET at $ENV_FILE"
  fi
  # 升级临时目录：确保存在且归 herebox 所有，供升级进程写入
  mkdir -p /opt/herebox-updates /opt/herebox-releases
  chown "$HEREBOX_USER:$HEREBOX_USER" /opt/herebox-updates /opt/herebox-releases 2>/dev/null || true
  chmod +x "$INSTALL_DIR/scripts/gateway-pre-start.sh" 2>/dev/null || true
  systemctl daemon-reload
  systemctl enable herebox.service herebox-gateway.service 2>/dev/null || true
  echo "  systemd services enabled"
}

# ── Step: sudoers (allow herebox to run install.sh as root) ───────────────────

step_sudoers() {
  local SUDOERS_D="/etc/sudoers.d"
  local DEST="$SUDOERS_D/99-herebox-install"
  local SRC="$INSTALL_DIR/config/99-herebox-install.sudoers"
  [ -f "$SRC" ] || SRC="$ROOT_DIR/config/99-herebox-install.sudoers"
  if [ ! -f "$SRC" ]; then
    echo "  Sudoers template not found, skipping"
    return 0
  fi
  mkdir -p "$SUDOERS_D"
  sed "s|INSTALL_DIR_PLACEHOLDER|$INSTALL_DIR|g" "$SRC" > "$DEST"
  chmod 440 "$DEST"
  if visudo -c -f "$DEST" 2>/dev/null; then
    echo "  Sudoers installed ($DEST)"
  else
    echo "  Warning: visudo check failed, removing $DEST" >&2
    rm -f "$DEST"
  fi
}

step_setup_ap_if_needed() {
  log_install_step "network-access" "start" "Ensuring WiFi AP for first-time access (if WiFi not configured)"
  # 若系统已配置 WiFi，则无论是否处于升级模式，都不再尝试创建 AP
  if wifi_already_configured; then
    echo "  WiFi already configured, skipping setup-ap.sh"
    log_install_step "network-access" "success" "WiFi already configured, AP setup skipped"
    return 0
  fi

  local SCRIPT="$INSTALL_DIR/scripts/setup-ap.sh"
  if [ ! -x "$SCRIPT" ]; then
    echo "  setup-ap.sh not found or not executable at $SCRIPT, skipping AP setup"
    log_install_step "network-access" "error" "setup-ap.sh not available, AP not configured"
    return 0
  fi

  echo "  Running setup-ap.sh for initial WiFi AP..."
  if sudo "$SCRIPT"; then
    echo "  WiFi AP setup completed"
    log_install_step "network-access" "success" "WiFi AP enabled (HereBox-Setup)"
  else
    echo "  Warning: setup-ap.sh failed (see logs for details)" >&2
    log_install_step "network-access" "error" "WiFi AP setup failed"
  fi
}

# ── Step: polkit rules ───────────────────────────────────────────────────────

step_polkit_rules() {
  mkdir -p "$POLKIT_PKLA_DIR"
  local SRC="$INSTALL_DIR/config/49-herebox-updates.pkla"
  [ -f "$SRC" ] || SRC="$ROOT_DIR/config/49-herebox-updates.pkla"
  if [ -f "$SRC" ]; then
    cp "$SRC" "$POLKIT_PKLA_DIR/"
    rm -f /etc/polkit-1/rules.d/49-herebox-updates.rules 2>/dev/null || true
    echo "  Polkit rules installed"
  fi
}

# ── Step: nginx ───────────────────────────────────────────────────────────────

step_nginx() {
  if [ ! -d /etc/nginx ] || ! command -v nginx &>/dev/null; then
    echo "  Installing nginx..."
    apt-get update -qq
    apt-get install -y -qq nginx
    echo "  nginx installed"
  fi
  if [ ! -d /etc/nginx ]; then
    echo "  nginx dir not found, skipping site config"
    return 0
  fi
  local TPL="$INSTALL_DIR/templates/nginx-herebox.conf"
  [ -f "$TPL" ] || TPL="$ROOT_DIR/templates/nginx-herebox.conf"
  if [ ! -f "$TPL" ]; then
    echo "  nginx template not found, skipping"
    return 0
  fi
  local OPENCLAW_CONFIG_PATH="$HEREBOX_HOME/.openclaw/openclaw.json"
  local OPENCLAW_TOKEN=""
  if [ -f "$OPENCLAW_CONFIG_PATH" ]; then
    OPENCLAW_TOKEN="$(
      OPENCLAW_CONFIG=\"$OPENCLAW_CONFIG_PATH\" node - <<'EOF'
const fs = require('fs');
const p = process.env.OPENCLAW_CONFIG;
let c;
try {
  c = JSON.parse(fs.readFileSync(p, 'utf8'));
} catch (e) {
  c = {};
}
const t = c && c.gateway && c.gateway.auth && c.gateway.auth.token;
process.stdout.write(t || '');
EOF
    )"
  fi
  sed -e "s|INSTALL_DIR_PLACEHOLDER|$INSTALL_DIR|g" \
      -e "s|API_PORT_PLACEHOLDER|$API_PORT|g" \
      -e "s|OPENCLAW_TOKEN_PLACEHOLDER|$OPENCLAW_TOKEN|g" \
      "$TPL" > "$NGINX_AVAILABLE"
  if [ ! -L "$NGINX_ENABLED" ]; then
    ln -sf "$NGINX_AVAILABLE" "$NGINX_ENABLED"
  fi
  # Disable default nginx welcome site if present to avoid serving the default page instead of HereBox UI.
  if [ -L /etc/nginx/sites-enabled/default ] || [ -f /etc/nginx/sites-enabled/default ]; then
    rm -f /etc/nginx/sites-enabled/default
    echo "  Disabled nginx default site"
  fi
  if nginx -t 2>/dev/null; then
    systemctl reload nginx 2>/dev/null || true
    echo "  Nginx site herebox enabled and reloaded"
  else
    echo "  Warning: nginx -t failed, check config" >&2
  fi
}

# ── Step: mDNS (avahi) ──────────────────────────────────────────────────────

step_mdns() {
  # 升级流程且系统已经有 WiFi 配置时，不再重新配置或重启 mDNS，避免不必要的网络变更
  if [ "$HEREBOX_UPGRADE_FLAG" = "1" ] && wifi_already_configured; then
    echo "  Upgrade with existing WiFi configuration detected, skipping mDNS setup"
    return 0
  fi

  apt-get install -y -qq avahi-daemon 2>/dev/null || true
  if ! command -v avahi-daemon &>/dev/null; then
    echo "  avahi-daemon not installed, skipping mDNS"
    return 0
  fi
  mkdir -p "$(dirname "$AVAHI_SERVICE_FILE")"
  local TPL="$INSTALL_DIR/templates/avahi-herebox.service"
  [ -f "$TPL" ] || TPL="$ROOT_DIR/templates/avahi-herebox.service"
  if [ -f "$TPL" ]; then
    cp "$TPL" "$AVAHI_SERVICE_FILE"
    echo "  Installed $AVAHI_SERVICE_FILE"
  fi
  systemctl enable avahi-daemon 2>/dev/null || true
  systemctl restart avahi-daemon 2>/dev/null || true
  echo "  mDNS (herebox.local) configured"
}

# ── Step: start services ────────────────────────────────────────────────────
# 先重启 nginx；herebox/herebox-gateway 延后重启，避免升级由 API 触发时立刻杀进程导致前端收不到成功响应。

step_start_services() {
  systemctl restart nginx 2>/dev/null || true
  (
    sleep 5
    systemctl restart herebox.service 2>/dev/null || true
    systemctl restart herebox-gateway.service 2>/dev/null || true
  ) &
  echo "  Services started (herebox/herebox-gateway will restart in 5s)"
}

# ── Single-step dispatch ────────────────────────────────────────────────────

DISPATCH_STEPS=(
  ensure_user apt_update detect_wifi firewall_ap install_dir build
  openclaw_install openclaw_patch openclaw_config
  systemd_services sudoers polkit_rules nginx mdns setup_ap_if_needed start_services
)

if [ "${1:-}" = "--step" ]; then
  local_step="${2:-}"
  step_valid=false
  for s in "${DISPATCH_STEPS[@]}"; do
    [ "$s" = "$local_step" ] && step_valid=true && break
  done
  if [ "$step_valid" = false ]; then
    echo "Unknown step: ${local_step:-<empty>}" >&2
    echo "Available steps: ${DISPATCH_STEPS[*]}" >&2
    exit 1
  fi
  "step_${local_step}"
  exit 0
fi

# ── Full install ───────────────────────────────────────────────────────────

echo "=== HereBox Install (idempotent) ==="
step_ensure_user
step_apt_update
step_detect_wifi
step_firewall_ap
step_install_dir
step_build
step_openclaw_install
step_openclaw_config
step_openclaw_patch
step_systemd_services
step_sudoers
step_polkit_rules
step_nginx
step_mdns
step_setup_ap_if_needed
step_start_services
echo ""
echo "=== HereBox install complete ==="
echo "  Dashboard: http://herebox.local or http://$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "  Services: systemctl status herebox herebox-gateway nginx"
echo "  Enable WiFi AP: sudo $INSTALL_DIR/scripts/setup-ap.sh"
echo ""
