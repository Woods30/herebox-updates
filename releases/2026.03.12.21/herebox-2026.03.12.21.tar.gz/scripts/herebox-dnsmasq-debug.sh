#!/usr/bin/env bash
set -euo pipefail

CONF="/etc/dnsmasq.d/herebox.conf"

echo "[herebox] Ensuring dnsmasq DHCP logging is enabled ..."

# Ensure config file exists
if [ ! -f "$CONF" ]; then
  echo "[herebox] ERROR: $CONF does not exist. HereBox AP config may not have been written yet." >&2
  echo "[herebox] Please run setup-ap.sh or the install script first, then run this script again." >&2
  exit 1
fi

# Add log-dhcp
if ! grep -q '^[[:space:]]*log-dhcp' "$CONF"; then
  echo "log-dhcp" | sudo tee -a "$CONF" >/dev/null
  echo "[herebox] Appended log-dhcp to $CONF"
else
  echo "[herebox] log-dhcp already present in $CONF"
fi

# Optional: add log-queries (more detailed)
if ! grep -q '^[[:space:]]*log-queries' "$CONF"; then
  echo "log-queries" | sudo tee -a "$CONF" >/dev/null
  echo "[herebox] Appended log-queries to $CONF"
else
  echo "[herebox] log-queries already present in $CONF"
fi

echo "[herebox] Restarting dnsmasq ..."
sudo systemctl restart dnsmasq

echo
echo "[herebox] dnsmasq status:"
sudo systemctl --no-pager status dnsmasq || true

echo
echo "[herebox] Tailing dnsmasq logs. Now connect your phone to the HereBox hotspot and watch DHCP logs below."
echo "[herebox] Press Ctrl+C to stop."
sudo journalctl -fu dnsmasq