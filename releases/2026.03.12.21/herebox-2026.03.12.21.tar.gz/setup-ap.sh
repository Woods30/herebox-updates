#!/usr/bin/env bash

echo "herebox setup-ap placeholder"

