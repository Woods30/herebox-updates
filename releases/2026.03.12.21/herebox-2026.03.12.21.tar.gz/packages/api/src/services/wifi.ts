import fs from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

function resolveInterface(): string {
  if (process.env.NETWORK_INTERFACE) return process.env.NETWORK_INTERFACE;
  if (process.env.NETWORK_INTERFACE_OVERRIDE) return process.env.NETWORK_INTERFACE_OVERRIDE;

  try {
    const content = fs.readFileSync('/etc/herebox/network.env', 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const [k, v] = trimmed.split('=', 2);
      if (k === 'NETWORK_INTERFACE' && v) return v.trim();
    }
  } catch {
    // ignore, fall through to default
  }

  return 'wlp2s0';
}

const IFACE = resolveInterface();
const NETWORK_TIMEOUT = Number(process.env.NETWORK_COMMAND_TIMEOUT ?? 60000);

export type WifiNetwork = {
  ssid: string;
  signal: number;
  security: string;
  freq: string;
};

export async function getWifiStatus(): Promise<Record<string, string>> {
  try {
    const { stdout } = await execFileAsync(
      'nmcli',
      [
        '-t',
        '-f',
        'GENERAL.STATE,GENERAL.CONNECTION,IP4.ADDRESS,IP4.GATEWAY',
        'device',
        'show',
        IFACE,
      ],
      { timeout: NETWORK_TIMEOUT, encoding: 'utf8' }
    );

    const info: Record<string, string> = {};
    for (const line of stdout.split('\n')) {
      const idx = line.indexOf(':');
      if (idx > -1) {
        info[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
      }
    }
    return info;
  } catch {
    return { error: 'WiFi interface not available' };
  }
}

export async function scanWifi(opts?: { skipRescan?: boolean }): Promise<WifiNetwork[]> {
  if (!opts?.skipRescan) {
    await execFileAsync('nmcli', ['device', 'wifi', 'rescan', 'ifname', IFACE], {
      timeout: NETWORK_TIMEOUT,
    }).catch(() => {});
  }

  const { stdout } = await execFileAsync(
    'nmcli',
    ['-t', '-f', 'SSID,SIGNAL,SECURITY,FREQ', 'device', 'wifi', 'list', 'ifname', IFACE],
    { timeout: NETWORK_TIMEOUT, encoding: 'utf8' }
  );

  const networks = stdout
    .trim()
    .split('\n')
    .filter((line) => line.trim())
    .map((line) => {
      const parts = line.split(':');
      if (parts.length < 4) return null;
      const freq = parts.pop()!;
      const security = parts.pop()!;
      const signal = parts.pop()!;
      const ssid = parts.join(':');
      const signalNum = parseInt(signal, 10);
      if (!ssid || Number.isNaN(signalNum)) return null;
      return { ssid, signal: signalNum, security, freq };
    })
    .filter((n): n is WifiNetwork => !!n);

  return networks.sort((a, b) => b.signal - a.signal);
}

export async function connectWifi(
  ssid: string,
  password?: string
): Promise<{ message: string }> {
  const args = password
    ? ['device', 'wifi', 'connect', ssid, 'password', password, 'ifname', IFACE]
    : ['device', 'wifi', 'connect', ssid, 'ifname', IFACE];

  const { stdout } = await execFileAsync('nmcli', args, {
    timeout: NETWORK_TIMEOUT,
    encoding: 'utf8',
  });

  return { message: stdout.trim() };
}

