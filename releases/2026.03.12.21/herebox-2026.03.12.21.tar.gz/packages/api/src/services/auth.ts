import type { HereboxConfig } from '../lib/config.js';
import { loadConfig, saveConfig, DEFAULT_PASSWORD } from '../lib/config.js';
import { hashPassword, verifyPassword, signJsonSession, verifyJsonSession } from '../lib/crypto.js';

type Session = {
  username: string;
  createdAt: number;
};

// 30 分钟 TTL，活跃时自动续期
const SESSION_TTL_MS = 30 * 60 * 1000;
const SESSION_SECRET = process.env.HEREBOX_SESSION_SECRET || 'herebox-dev-session-secret';

export function ensureConfigWithHashedPassword(): HereboxConfig {
  const cfg = loadConfig();
  if (!cfg.auth.passwordHash || !cfg.auth.salt) {
    const { hash, salt } = hashPassword(DEFAULT_PASSWORD);
    cfg.auth.passwordHash = hash;
    cfg.auth.salt = salt;
    saveConfig(cfg);
  }
  return cfg;
}

export function login(username: string, password: string) {
  const cfg = ensureConfigWithHashedPassword();
  if (username !== cfg.auth.username) return null;
  const ok = verifyPassword(password, cfg.auth.passwordHash, cfg.auth.salt);
  if (!ok) return null;
  const now = Date.now();
  const payload: Session = { username, createdAt: now };
  return signJsonSession(payload, SESSION_SECRET);
}

export function getSession(token: string | undefined | null): Session | null {
  if (!token) return null;
  const payload = verifyJsonSession<Session>(token, SESSION_SECRET);
  if (!payload) return null;
  if (Date.now() - payload.createdAt > SESSION_TTL_MS) {
    return null;
  }
  return payload;
}

export function refreshSession(username: string): string {
  const now = Date.now();
  const payload: Session = { username, createdAt: now };
  return signJsonSession(payload, SESSION_SECRET);
}

export function logout(token: string | undefined | null) {
  // Stateless 会话：logout 仅依赖前端删除 cookie，这里无需额外操作
  return;
}

export function changePassword(
  current: string,
  nextPassword: string,
  newUsername?: string
): boolean {
  const cfg = ensureConfigWithHashedPassword();
  const ok = verifyPassword(current, cfg.auth.passwordHash, cfg.auth.salt);
  if (!ok) return false;
  const { hash, salt } = hashPassword(nextPassword);
  cfg.auth.passwordHash = hash;
  cfg.auth.salt = salt;
  cfg.auth.passwordChangedAt = Date.now();
  if (newUsername != null && newUsername.trim()) {
    cfg.auth.username = newUsername.trim();
  }
  saveConfig(cfg);
  return true;
}

/**
 * 向导内设置用户名与密码（无需当前密码），保存后返回新 session 的 token，用于完成登录。
 * 仅应在向导未完成时调用。
 */
export function setWizardCredentials(
  username: string,
  password: string
): string | null {
  const trimmed = username.trim();
  if (!trimmed || !password) return null;
  const cfg = loadConfig();
  const { hash, salt } = hashPassword(password);
  cfg.auth.username = trimmed;
  cfg.auth.passwordHash = hash;
  cfg.auth.salt = salt;
  cfg.auth.passwordChangedAt = Date.now();
  saveConfig(cfg);
  const now = Date.now();
  const payload: Session = { username: trimmed, createdAt: now };
  return signJsonSession(payload, SESSION_SECRET);
}

