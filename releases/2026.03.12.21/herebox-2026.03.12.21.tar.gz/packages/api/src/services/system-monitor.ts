import os from 'node:os';
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

export type SystemInfo = {
  hostname: string;
  platform: NodeJS.Platform;
  arch: string;
  release: string;
  uptimeSec: number;
};

export type SystemMonitorSnapshot = {
  cpuUsagePercent: number;
  cpuCores: number;
  totalMem: number;
  freeMem: number;
  diskUsedPercent: number | null;
  diskFreeBytes: number | null;
  temperatureC: number | null;
  gpuName: string | null;
  gpuUsagePercent: number | null;
  gpuTemperatureC: number | null;
  uptimeSec: number;
};

type CpuTimes = ReturnType<typeof os.cpus>[0]['times'];
let prevCpu: { times: CpuTimes } | null = null;

function getCpuUsagePercent(): number {
  const cpus = os.cpus();
  if (!cpus.length) return 0;
  const times = cpus[0].times;
  const total = times.user + times.nice + times.sys + times.irq + times.idle;
  const used = total - times.idle;
  let cpuUsagePercent = 0;
  if (prevCpu) {
    const prevTotal =
      prevCpu.times.user + prevCpu.times.nice + prevCpu.times.sys + prevCpu.times.irq + prevCpu.times.idle;
    const dTotal = total - prevTotal;
    const dUsed = used - (prevTotal - prevCpu.times.idle);
    if (dTotal > 0) cpuUsagePercent = Math.round((dUsed / dTotal) * 100);
  }
  prevCpu = {
    times: {
      user: times.user,
      nice: times.nice,
      sys: times.sys,
      idle: times.idle,
      irq: times.irq,
    },
  };
  return Math.min(100, Math.max(0, cpuUsagePercent));
}

function getDiskStats(): { diskUsedPercent: number | null; diskFreeBytes: number | null } {
  try {
    const out = execFileSync('df', ['-k', '.'], { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
    const lines = out.trim().split('\n');
    const lastLine = lines[lines.length - 1];
    if (!lastLine) return { diskUsedPercent: null, diskFreeBytes: null };
    const parts = lastLine.split(/\s+/);
    if (parts.length < 5) return { diskUsedPercent: null, diskFreeBytes: null };
    const usedPercentStr = parts[4].replace('%', '');
    const diskUsedPercent = parseInt(usedPercentStr, 10);
    const availableK = parseInt(parts[3], 10);
    if (Number.isNaN(diskUsedPercent) || Number.isNaN(availableK))
      return { diskUsedPercent: null, diskFreeBytes: null };
    return {
      diskUsedPercent,
      diskFreeBytes: availableK * 1024,
    };
  } catch {
    return { diskUsedPercent: null, diskFreeBytes: null };
  }
}

function getTemperatureC(): number | null {
  try {
    if (process.platform === 'linux' && fs.existsSync('/sys/class/thermal/thermal_zone0/temp')) {
      const buf = fs.readFileSync('/sys/class/thermal/thermal_zone0/temp', 'utf8');
      const millideg = parseInt(buf.trim(), 10);
      if (Number.isNaN(millideg)) return null;
      return Math.round(millideg / 1000);
    }
  } catch {
    // ignore
  }
  return null;
}

function getGpuInfo(): {
  gpuName: string | null;
  gpuUsagePercent: number | null;
  gpuTemperatureC: number | null;
} {
  try {
    const out = execFileSync('nvidia-smi', [
      '--query-gpu=name,utilization.gpu,temperature.gpu',
      '--format=csv,noheader,nounits',
    ], { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
    const line = out.trim().split('\n')[0];
    if (!line) return { gpuName: null, gpuUsagePercent: null, gpuTemperatureC: null };
    const parts = line.split(',').map((s) => s.trim());
    const name = parts[0] || null;
    const usage = parts[1] ? parseInt(parts[1], 10) : NaN;
    const temp = parts[2] ? parseInt(parts[2], 10) : NaN;
    return {
      gpuName: name || null,
      gpuUsagePercent: Number.isInteger(usage) ? usage : null,
      gpuTemperatureC: Number.isInteger(temp) ? temp : null,
    };
  } catch {
    return { gpuName: null, gpuUsagePercent: null, gpuTemperatureC: null };
  }
}

export function getSystemInfo(): SystemInfo {
  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    release: os.release(),
    uptimeSec: os.uptime(),
  };
}

export function getSystemMonitorSnapshot(): SystemMonitorSnapshot {
  const cpuCores = os.cpus().length;
  const cpuUsagePercent = getCpuUsagePercent();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const { diskUsedPercent, diskFreeBytes } = getDiskStats();
  const temperatureC = getTemperatureC();
  const { gpuName, gpuUsagePercent, gpuTemperatureC } = getGpuInfo();

  return {
    cpuUsagePercent,
    cpuCores,
    totalMem,
    freeMem,
    diskUsedPercent,
    diskFreeBytes,
    temperatureC,
    gpuName,
    gpuUsagePercent,
    gpuTemperatureC,
    uptimeSec: os.uptime(),
  };
}

