import { spawn } from "node:child_process";
import os from "node:os";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";
import { loadConfig, saveConfig } from "../lib/config.js";
import { logger } from "../lib/logger.js";

export type WizardStepId =
  | "configure-wifi"
  | "configure-ai"
  | "configure-channel"
  | "complete";

export type StepStatus = "pending" | "running" | "success" | "error" | "skipped";

export type WizardStepState = {
  id: string;
  nameKey: string;
  status: StepStatus;
  lastMessage?: string;
};

export type WizardStatus = {
  steps: WizardStepState[];
  startedAt?: number;
  finishedAt?: number;
  running: boolean;
  done: boolean;
  /** 从 config 读取，向导是否已完成（完成后禁止再次执行） */
  completed: boolean;
};

export type WizardBroadcastEvent =
  | { type: "wizard-status"; payload: WizardStatus }
  | { type: "wizard-log"; payload: { stepId: string; message: string } };

const STEP_NAME_KEYS: Record<string, string> = {
  "configure-wifi": "wizard.steps.configureWifi",
  "configure-ai": "wizard.steps.configureAi",
  "configure-channel": "wizard.steps.configureChannel",
  complete: "wizard.steps.complete",
};

const DEFAULT_STEP_IDS: WizardStepId[] = [
  "configure-wifi",
  "configure-ai",
  "configure-channel",
  "complete",
];

const listeners = new Set<(event: WizardBroadcastEvent) => void>();

type InternalState = {
  steps: Record<string, WizardStepState>;
  startedAt?: number;
  finishedAt?: number;
  running: boolean;
};

function initialStepState(
  stepIds: string[] = DEFAULT_STEP_IDS,
  persisted?: { id: string; status: string; lastMessage?: string }[],
): Record<string, WizardStepState> {
  const byId = new Map<string, { id: string; status: string; lastMessage?: string }>();
  if (persisted) {
    for (const s of persisted) {
      if (!s?.id || !stepIds.includes(s.id)) continue;
      byId.set(s.id, s);
    }
  }
  return Object.fromEntries(
    stepIds.map((id) => {
      const base = {
        id,
        nameKey: STEP_NAME_KEYS[id] ?? `wizard.steps.${id}`,
      };
      const persistedStep = byId.get(id);
      if (!persistedStep) {
        return [
          id,
          {
            ...base,
            status: "pending" as StepStatus,
          },
        ];
      }
      const status: StepStatus =
        persistedStep.status === "running"
          ? "pending"
          : (["pending", "success", "error", "skipped"].includes(persistedStep.status)
              ? (persistedStep.status as StepStatus)
              : "pending");
      return [
        id,
        {
          ...base,
          status,
          lastMessage: persistedStep.lastMessage,
        },
      ];
    }),
  );
}

const bootConfig = loadConfig();

const state: InternalState = {
  steps: initialStepState(
    DEFAULT_STEP_IDS,
    bootConfig.wizardSteps,
  ),
  running: false,
};

function emit(event: WizardBroadcastEvent) {
  for (const listener of listeners) {
    try {
      listener(event);
    } catch {
      // ignore
    }
  }
}

export function isWizardCompleted(): boolean {
  const cfg = loadConfig();
  return cfg.wizardCompletedAt != null;
}

export function getWizardStatus(): WizardStatus {
  const steps = Object.values(state.steps);
  const done =
    steps.length > 0 &&
    steps.every((s) => s.status === "success" || s.status === "skipped");
  return {
    steps,
    startedAt: state.startedAt,
    finishedAt: state.finishedAt,
    running: state.running,
    done,
    completed: isWizardCompleted(),
  };
}

export function subscribeWizard(
  listener: (event: WizardBroadcastEvent) => void,
): () => void {
  listeners.add(listener);
  listener({ type: "wizard-status", payload: getWizardStatus() });
  return () => listeners.delete(listener);
}

function appendLog(stepId: string, message: string) {
  const step = state.steps[stepId];
  if (step) step.lastMessage = message;
  emit({ type: "wizard-log", payload: { stepId, message } });
}

function handleStepEvent(stepId: string, action: string, message?: string) {
  let step = state.steps[stepId];
  if (!step) {
    state.steps[stepId] = {
      id: stepId,
      nameKey: STEP_NAME_KEYS[stepId] ?? `wizard.steps.${stepId}`,
      status: "pending",
    };
    step = state.steps[stepId];
  }
  switch (action) {
    case "start":
      step.status = "running";
      break;
    case "success":
      step.status = "success";
      break;
    case "error":
      step.status = "error";
      step.lastMessage = message ?? "Unknown error";
      break;
    case "log":
      step.lastMessage = message;
      emit({ type: "wizard-log", payload: { stepId, message: message ?? "" } });
      break;
  }
  const cfg = loadConfig();
  cfg.wizardSteps = Object.values(state.steps).map((s) => ({
    id: s.id,
    status: s.status,
    lastMessage: s.lastMessage,
  }));
  saveConfig(cfg);
  emit({ type: "wizard-status", payload: getWizardStatus() });
}

function markCurrentRunningAsError(exitCode: number) {
  for (const step of Object.values(state.steps)) {
    if (step.status === "running") {
      step.status = "error";
      step.lastMessage = `Process exited with code ${exitCode}`;
      break;
    }
  }
  const cfg = loadConfig();
  cfg.wizardSteps = Object.values(state.steps).map((s) => ({
    id: s.id,
    status: s.status,
    lastMessage: s.lastMessage,
  }));
  saveConfig(cfg);
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const INIT_SCRIPT = path.resolve(
  __dirname,
  "../../../../scripts/herebox-setup.sh",
);

/**
 * 按「单步」方式执行向导步骤。
 * 仅在用户点击前端按钮时由路由显式调用，不再自动整套执行。
 */
export function runWizardStep(stepId: WizardStepId): Promise<void> {
  if (state.running) {
    throw new Error("wizard_step_running");
  }

  // 已完成的向导不再允许执行步骤（除非后续有重置逻辑）
  if (isWizardCompleted()) {
    throw new Error("wizard_already_completed");
  }

  if (!state.steps[stepId]) {
    state.steps[stepId] = {
      id: stepId,
      nameKey: STEP_NAME_KEYS[stepId] ?? `wizard.steps.${stepId}`,
      status: "pending",
    };
  }

  state.running = true;
  state.startedAt = state.startedAt ?? Date.now();
  state.steps[stepId]!.status = "running";
  const cfg = loadConfig();
  cfg.wizardSteps = Object.values(state.steps).map((s) => ({
    id: s.id,
    status: s.status,
    lastMessage: s.lastMessage,
  }));
  saveConfig(cfg);
  emit({ type: "wizard-status", payload: getWizardStatus() });

  logger.info("wizard step starting", {
    script: INIT_SCRIPT,
    stepId,
  });

  return new Promise((resolve, reject) => {
    let currentStepId: string | null = stepId;

    const proc = spawn("bash", [INIT_SCRIPT, "--step", stepId], {
      env: { ...process.env, HOME: os.homedir() },
      cwd: path.resolve(__dirname, "../.."),
    });

    const stdout = proc.stdout;
    const stderr = proc.stderr;

    if (stdout) {
      const rl = readline.createInterface({ input: stdout });
      rl.on("line", (line: string) => {
        const match = line.match(/^##STEP:(\S+):(\w+)(?::(.*))?$/);
        if (match) {
          const [, sid, action, message] = match;
          handleStepEvent(sid, action, message);
          currentStepId = sid;
          return;
        }
        if (currentStepId) appendLog(currentStepId, line);
      });
    }

    if (stderr) {
      const rlErr = readline.createInterface({ input: stderr });
      rlErr.on("line", (line: string) => {
        if (currentStepId) appendLog(currentStepId, line);
      });
    }

    proc.on("exit", (code) => {
      state.running = false;
      state.finishedAt = Date.now();
      if (code !== 0) {
        markCurrentRunningAsError(code ?? 1);
        const status = getWizardStatus();
        const failedStep = status.steps.find((s) => s.status === "error");
        logger.warn("wizard step exited with error", {
          code: code ?? 1,
          stepId,
          failedStep: failedStep?.id,
          lastMessage: failedStep?.lastMessage,
        });
        emit({ type: "wizard-status", payload: getWizardStatus() });
        reject(new Error(`wizard_step_failed:${stepId}`));
      } else {
        const step = state.steps[stepId];
        if (step && step.status === "running") {
          step.status = "success";
        }
        logger.info("wizard step completed", { stepId });
        emit({ type: "wizard-status", payload: getWizardStatus() });
        resolve();
      }
    });
  });
}

/**
 * 向后兼容的空实现：旧的 /api/wizard/start 如果被调用，直接返回，不再自动执行整套步骤。
 */
export function startWizardIfNeeded(): void {
  logger.info("wizard start ignored in per-step mode");
}

export function skipWizardStep(stepId: WizardStepId): void {
  if (isWizardCompleted()) {
    throw new Error("wizard_already_completed");
  }
  if (!state.steps[stepId]) {
    state.steps[stepId] = {
      id: stepId,
      nameKey: STEP_NAME_KEYS[stepId] ?? `wizard.steps.${stepId}`,
      status: "pending",
    };
  }
  const step = state.steps[stepId]!;
  step.status = "skipped";
  step.lastMessage = "Skipped by user";
  logger.info("wizard step skipped", { stepId });
  const cfg = loadConfig();
  cfg.wizardSteps = Object.values(state.steps).map((s) => ({
    id: s.id,
    status: s.status,
    lastMessage: s.lastMessage,
  }));
  saveConfig(cfg);
  emit({ type: "wizard-status", payload: getWizardStatus() });
}

export function resetWizardState(): void {
  state.steps = initialStepState();
  state.running = false;
  state.startedAt = undefined;
  state.finishedAt = undefined;
  const cfg = loadConfig();
  delete cfg.wizardCompletedAt;
  delete cfg.wizardSteps;
  saveConfig(cfg);
  logger.info("wizard state reset");
}

/** 仅重置步骤状态（全部变为 pending），不修改 wizardCompletedAt，用于「从第一步重新执行」 */
export function resetWizardStepsOnly(): void {
  state.steps = initialStepState();
  state.running = false;
  state.startedAt = undefined;
  state.finishedAt = undefined;
  const cfg = loadConfig();
  cfg.wizardSteps = Object.values(state.steps).map((s) => ({
    id: s.id,
    status: s.status,
    lastMessage: s.lastMessage,
  }));
  saveConfig(cfg);
  emit({ type: "wizard-status", payload: getWizardStatus() });
  logger.info("wizard steps reset (re-run from first step)");
}

/** 标记向导已完成（例如用户跳过更新仅设置密码后调用） */
export function markWizardComplete(): void {
  const cfg = loadConfig();
  if (cfg.wizardCompletedAt == null) {
    cfg.wizardCompletedAt = Date.now();
    saveConfig(cfg);
  }
}
