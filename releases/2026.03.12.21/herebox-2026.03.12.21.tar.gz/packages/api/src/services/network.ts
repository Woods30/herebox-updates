import fs from 'node:fs';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export type NetworkInterfaceInfo = {
  name: string;
  addresses: string[];
  internal: boolean;
};

export type NetworkInfo = {
  interfaces: NetworkInterfaceInfo[];
  defaultGateway: string | null;
  nameservers: string[];
  ok: boolean;
};

async function getDefaultGateway(): Promise<string | null> {
  try {
    if (process.platform === 'linux') {
      const { stdout } = await execFileAsync('ip', ['route', 'show', 'default'], { encoding: 'utf8' });
      const m = stdout.trim().match(/default via (\S+)/);
      return m ? m[1] : null;
    }
  } catch {
    // ignore
  }
  return null;
}

function getNameservers(): string[] {
  try {
    if (process.platform === 'linux' && fs.existsSync('/etc/resolv.conf')) {
      const content = fs.readFileSync('/etc/resolv.conf', 'utf8');
      const names: string[] = [];
      for (const line of content.split('\n')) {
        const m = line.trim().match(/^nameserver\s+(\S+)/);
        if (m) names.push(m[1]);
      }
      return names;
    }
  } catch {
    // ignore
  }
  return [];
}

export async function getNetworkInfo(): Promise<NetworkInfo> {
  const ifaces = os.networkInterfaces();
  const interfaces: NetworkInterfaceInfo[] = [];
  let hasNonInternal = false;

  for (const [name, addrs] of Object.entries(ifaces ?? {})) {
    if (!addrs?.length) continue;
    const addresses = addrs.filter((a) => a.family === 'IPv4').map((a) => a.address);
    const internal = addrs.every((a) => a.internal);
    if (addresses.length) {
      if (!internal) hasNonInternal = true;
      interfaces.push({ name, addresses, internal });
    }
  }

  const defaultGateway = await getDefaultGateway();
  const nameservers = getNameservers();
  const ok = hasNonInternal || Boolean(defaultGateway) || nameservers.length > 0;

  return {
    interfaces,
    defaultGateway,
    nameservers,
    ok,
  };
}
