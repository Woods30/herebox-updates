import type { Context, Next } from 'hono';
import { logger } from '../lib/logger.js';

export async function requestLog(c: Context, next: Next) {
  const method = c.req.method;
  const path = c.req.path;
  const start = Date.now();
  await next();
  const status = c.res.status;
  const duration = Date.now() - start;
  logger.info('request', {
    method,
    path,
    status,
    durationMs: duration,
  });
}
