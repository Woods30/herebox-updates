import type { Context, Next } from 'hono';
import { getCookie, setCookie } from 'hono/cookie';
import { getSession, refreshSession } from '../services/auth.js';

const COOKIE_NAME = 'herebox_session';
const SESSION_MAX_AGE_SECONDS = 30 * 60;

export async function requireAuth(c: Context, next: Next) {
  const path = c.req.path;
  const method = c.req.method;
  // Internal setup calls (from herebox-setup.sh) are allowed without session when carrying a trusted header.
  const internal = c.req.header('x-herebox-internal');
  if (internal === 'setup') return await next();

  if (path === '/api/auth/login' && method === 'POST') return await next();
  if (path === '/api/auth/session' && method === 'GET') return await next();
  if (path === '/api/auth/check' && method === 'GET') return await next();
  // 向导流程在设置账号密码前无需登录
  if (path.startsWith('/api/wizard/')) return await next();

  const token = getCookie(c, COOKIE_NAME);
  const sess = getSession(token);
  if (!sess) return c.json({ error: 'unauthorized' }, 401);

  // 活跃续期：基于当前用户名刷新一个新的会话 token，并重写 cookie
  const refreshedToken = refreshSession(sess.username);
  setCookie(c, COOKIE_NAME, refreshedToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: SESSION_MAX_AGE_SECONDS,
  });

  return await next();
}
