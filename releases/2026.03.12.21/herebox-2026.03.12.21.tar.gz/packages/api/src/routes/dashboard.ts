import type { Context } from 'hono';
import { loadConfig } from '../lib/config.js';
import { getNetworkInfo } from '../services/network.js';

export type SectionStatus = 'pending' | 'done';

export type DashboardStatus = {
  network: SectionStatus;
  ai: SectionStatus;
  channels: SectionStatus;
  security: SectionStatus;
};

function getStepStatus(
  wizardSteps: { id: string; status: string }[] | undefined,
  stepId: string,
): string | undefined {
  return wizardSteps?.find((s) => s.id === stepId)?.status;
}

export async function handleDashboardStatus(c: Context) {
  const cfg = loadConfig();
  const wizardSteps = cfg.wizardSteps;

  const networkInfo = await getNetworkInfo();
  const wifiStepSuccess = getStepStatus(wizardSteps, 'configure-wifi') === 'success';
  // 任一满足即 DONE：向导步骤成功、config 标记已配 WiFi、或当前网络可用
  const networkDone =
    wifiStepSuccess || Boolean(cfg.wifiConfigured) || networkInfo.ok;

  const aiStepSuccess = getStepStatus(wizardSteps, 'configure-ai') === 'success';
  const aiHasConfig = Boolean(cfg.ai?.provider && cfg.ai?.model);
  const aiDone = aiStepSuccess || aiHasConfig;

  const channels = cfg.channels ?? {};
  const hasChannel =
    Boolean(channels.telegram?.token) ||
    Boolean(channels.discord?.token) ||
    Boolean(channels.feishu?.appId && channels.feishu?.appSecret);
  const channelStepSuccess =
    getStepStatus(wizardSteps, 'configure-channel') === 'success';
  const channelsDone = channelStepSuccess || hasChannel;

  const securityDone = Boolean(cfg.auth?.passwordChangedAt);

  const status: DashboardStatus = {
    network: networkDone ? 'done' : 'pending',
    ai: aiDone ? 'done' : 'pending',
    channels: channelsDone ? 'done' : 'pending',
    security: securityDone ? 'done' : 'pending',
  };
  return c.json(status);
}
