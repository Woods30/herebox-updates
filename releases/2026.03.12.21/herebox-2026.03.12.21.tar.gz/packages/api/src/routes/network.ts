import type { Context } from 'hono';
import { loadConfig, saveConfig } from '../lib/config.js';
import { logger } from '../lib/logger.js';
import { getNetworkInfo } from '../services/network.js';

export async function handleNetworkInfo(c: Context) {
  const info = await getNetworkInfo();
  const cfg = loadConfig();
  return c.json({
    ...info,
    desired: cfg.network ?? null,
  });
}

export async function handleNetworkSettingsPut(c: Context) {
  const body = await c.req
    .json<{
      interface?: string;
      address?: string;
      gateway?: string;
      nameservers?: string[];
    }>()
    .catch(() => null);
  if (!body) {
    logger.warn('network settings put failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }

  const cfg = loadConfig();
  cfg.network = {
    ...cfg.network,
    ...(body.interface !== undefined && { interface: body.interface || undefined }),
    ...(body.address !== undefined && { address: body.address || undefined }),
    ...(body.gateway !== undefined && { gateway: body.gateway || undefined }),
    ...(body.nameservers !== undefined && { nameservers: body.nameservers?.length ? body.nameservers : undefined }),
  };
  saveConfig(cfg);
  logger.info('network settings put', {
    interface: cfg.network?.interface,
    address: cfg.network?.address ? '(set)' : undefined,
  });
  const info = await getNetworkInfo();
  return c.json({
    ...info,
    desired: cfg.network,
  });
}
