import type { Context } from 'hono';
import { getCookie, setCookie, deleteCookie } from 'hono/cookie';
import { logger } from '../lib/logger.js';
import {
  changePassword,
  ensureConfigWithHashedPassword,
  getSession,
  login,
  logout,
} from '../services/auth.js';

const COOKIE_NAME = 'herebox_session';

export async function handleLogin(c: Context) {
  const body = await c.req.json<{ username: string; password: string }>().catch(
    () => null,
  );
  if (!body) {
    logger.warn('login failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }

  const token = login(body.username, body.password);
  if (!token) {
    logger.warn('login failed', { username: body.username, reason: 'invalid_credentials' });
    return c.json({ error: 'invalid_credentials' }, 401);
  }

  setCookie(c, COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: 30 * 60,
  });
  logger.info('login success', { username: body.username });
  return c.json({ ok: true });
}

export function handleSession(c: Context) {
  const token = getCookie(c, COOKIE_NAME);
  const sess = getSession(token);
  const cfg = ensureConfigWithHashedPassword();
  const wizardCompleted = !!cfg.wizardCompletedAt;
  if (!sess) {
    return c.json(
      {
        authenticated: false,
        username: null,
        passwordIsDefault: true,
        wizardCompleted,
      },
      200,
    );
  }

  const passwordIsDefault = cfg.auth.username === 'admin';

  return c.json(
    {
      authenticated: true,
      username: sess.username,
      passwordIsDefault,
      wizardCompleted,
    },
    200,
  );
}

// 供 nginx auth_request 使用的轻量鉴权接口：登录时返回 204，未登录时返回 401。
export function handleAuthCheck(c: Context) {
  const token = getCookie(c, COOKIE_NAME);
  const sess = getSession(token);
  if (!sess) return c.body(null, 401);
  return c.body(null, 204);
}

export async function handleChangePassword(c: Context) {
  const token = getCookie(c, COOKIE_NAME);
  const sess = getSession(token);
  if (!sess) return c.json({ error: 'unauthorized' }, 401);

  const body = await c
    .req
    .json<{ currentPassword: string; newPassword: string; newUsername?: string }>()
    .catch(() => null);
  if (!body) return c.json({ error: 'invalid_body' }, 400);

  const ok = changePassword(
    body.currentPassword,
    body.newPassword,
    body.newUsername
  );
  if (!ok) {
    logger.warn('changePassword failed', { username: sess.username, reason: 'invalid_current_password' });
    return c.json({ error: 'invalid_current_password' }, 400);
  }

  deleteCookie(c, COOKIE_NAME, { path: '/' });
  logger.info('changePassword success', { username: body.newUsername?.trim() || sess.username });
  return c.json({ ok: true });
}

export function handleLogout(c: Context) {
  const token = getCookie(c, COOKIE_NAME);
  const sess = getSession(token);
  logout(token);
  deleteCookie(c, COOKIE_NAME, { path: '/' });
  if (sess) logger.info('logout', { username: sess.username });
  return c.json({ ok: true });
}

