import type { Context } from 'hono';
import { loadConfig, saveConfig } from '../lib/config.js';
import {
  syncAiToOpenclawJson,
  syncChannelsToOpenclawJson,
} from '../lib/openclaw-config-sync.js';
import { logger } from '../lib/logger.js';

export function handleOpenClawStatus(c: Context) {
  return c.json({ running: false });
}

export function handleOpenClawConfigGet(c: Context) {
  const cfg = loadConfig();
  const ai = cfg.ai ?? {};
  return c.json({
    provider: ai.provider,
    model: ai.model,
    hasApiKey: Boolean(ai.apiKey),
  });
}

export async function handleOpenClawConfigPut(c: Context) {
  const body = await c.req
    .json<{ provider?: string; model?: string; apiKey?: string }>()
    .catch(() => null);
  if (!body) {
    logger.warn('openclaw config put failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }

  const cfg = loadConfig();
  cfg.ai = cfg.ai ?? {};
  if (body.provider != null) cfg.ai.provider = body.provider;
  if (body.model != null) cfg.ai.model = body.model;
  if (body.apiKey !== undefined) cfg.ai.apiKey = body.apiKey || undefined;
  saveConfig(cfg);
  syncAiToOpenclawJson(cfg.ai.provider, cfg.ai.model, cfg.ai.apiKey);
  logger.info('openclaw config put', { provider: cfg.ai.provider, model: cfg.ai.model });
  return c.json({
    provider: cfg.ai.provider,
    model: cfg.ai.model,
    hasApiKey: Boolean(cfg.ai.apiKey),
  });
}

export function handleChannelsGet(c: Context) {
  const cfg = loadConfig();
  const ch = cfg.channels ?? {};
  return c.json({
    telegram: { hasToken: Boolean(ch.telegram?.token) },
    discord: { hasToken: Boolean(ch.discord?.token) },
    feishu: { configured: Boolean(ch.feishu?.appId && ch.feishu?.appSecret) },
  });
}

export async function handleChannelsPut(c: Context) {
  const body = await c.req
    .json<{
      telegram?: { token?: string };
      discord?: { token?: string };
      feishu?: { appId?: string; appSecret?: string };
    }>()
    .catch(() => null);
  if (!body) {
    logger.warn('openclaw channels put failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }

  const cfg = loadConfig();
  cfg.channels = cfg.channels ?? {};
  if (body.telegram !== undefined) {
    cfg.channels.telegram = { ...cfg.channels.telegram, ...body.telegram };
    if (body.telegram.token === '') cfg.channels.telegram.token = undefined;
  }
  if (body.discord !== undefined) {
    cfg.channels.discord = { ...cfg.channels.discord, ...body.discord };
    if (body.discord.token === '') cfg.channels.discord.token = undefined;
  }
  if (body.feishu !== undefined) {
    cfg.channels.feishu = { ...cfg.channels.feishu, ...body.feishu };
    if (body.feishu.appId === '') cfg.channels.feishu = undefined;
  }
  saveConfig(cfg);
  syncChannelsToOpenclawJson(cfg.channels);
  logger.info('openclaw channels put', {
    telegram: Boolean(cfg.channels?.telegram?.token),
    discord: Boolean(cfg.channels?.discord?.token),
    feishu: Boolean(cfg.channels?.feishu?.appId && cfg.channels?.feishu?.appSecret),
  });
  return c.json({
    telegram: { hasToken: Boolean(cfg.channels?.telegram?.token) },
    discord: { hasToken: Boolean(cfg.channels?.discord?.token) },
    feishu: { configured: Boolean(cfg.channels?.feishu?.appId && cfg.channels?.feishu?.appSecret) },
  });
}
