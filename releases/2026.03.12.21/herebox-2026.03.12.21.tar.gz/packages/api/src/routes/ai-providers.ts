import type { Context } from 'hono';
import { loadAiProviders } from '../lib/ai-providers.js';

export function handleGetAiProviders(c: Context) {
  return c.json(loadAiProviders());
}
