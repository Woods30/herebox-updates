import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { Context } from 'hono';
import { streamSSE } from 'hono/streaming';
import { logger } from '../lib/logger.js';
import { verifyPassword } from '../lib/crypto.js';
import { ensureConfigWithHashedPassword } from '../services/auth.js';
import { resetWizardState } from '../services/wizard.js';
import { getSystemInfo, getSystemMonitorSnapshot } from '../services/system-monitor.js';
import {
  getUpgradeStatus,
  getVersionInfo,
  runUpgrade,
  subscribeUpgrade,
  type UpgradeBroadcastEvent,
} from '../services/upgrade.js';

export function handleSystemInfo(c: Context) {
  return c.json(getSystemInfo());
}

export async function handleSystemVersion(c: Context) {
  const info = await getVersionInfo();
  return c.json(info);
}

export function handleSystemMonitor(c: Context) {
  return c.json(getSystemMonitorSnapshot());
}

export async function handleSystemReset(c: Context) {
  const body = await c.req.json<{ password: string }>().catch(() => null);
  if (!body?.password) {
    logger.warn('system reset failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }

  const cfg = ensureConfigWithHashedPassword();
  const ok = verifyPassword(body.password, cfg.auth.passwordHash, cfg.auth.salt);
  if (!ok) {
    logger.warn('system reset failed', { reason: 'invalid_password' });
    return c.json({ error: 'invalid_password' }, 401);
  }

  const openclawHome = path.join(os.homedir(), '.openclaw');
  if (fs.existsSync(openclawHome)) {
    fs.rmSync(openclawHome, { recursive: true, force: true });
  }
  resetWizardState();
  logger.info('system reset success', { openclawHome });
  return c.json({ ok: true });
}

export async function handleSystemUpgradeStart(c: Context) {
  let targetVersion: string | undefined;
  try {
    const body = await c.req.json<{ targetVersion?: string }>().catch(
      (): { targetVersion?: string } => ({}),
    );
    targetVersion = body.targetVersion;
  } catch {
    // ignore
  }
  return runUpgrade({ targetVersion })
    .then(() => c.json(getUpgradeStatus()))
    .catch((err: unknown) => {
      const message = err instanceof Error ? err.message : String(err);
      logger.warn('system upgrade failed', { err: message });
      if (message === 'upgrade_already_running') {
        return c.json({ error: 'upgrade_already_running' }, 409);
      }
      return c.json({ error: 'upgrade_failed' }, 500);
    });
}

export function handleSystemUpgradeStream(c: Context) {
  logger.info('upgrade stream connected');
  return streamSSE(c, async (stream) => {
    const queue: UpgradeBroadcastEvent[] = [];
    let resolveNext: () => void = () => {};
    const next = () => new Promise<void>((r) => { resolveNext = r; });

    const push = (event: UpgradeBroadcastEvent) => {
      queue.push(event);
      resolveNext();
    };

    const unsubscribe = subscribeUpgrade(push);

    const abort = c.req.raw.signal;
    let stopped = false;
    abort.addEventListener('abort', () => {
      stopped = true;
      resolveNext();
      unsubscribe();
    });

    while (!stopped) {
      if (queue.length === 0) await next();
      if (stopped) break;
      const event = queue.shift();
      if (!event) continue;
      try {
        await stream.writeSSE({
          data: JSON.stringify(event.payload),
          event: event.type,
        });
      } catch {
        break;
      }
    }
  });
}

