import type { Context } from 'hono';
import { logger } from '../lib/logger.js';
import { loadConfig, saveConfig } from '../lib/config.js';
import { connectWifi, getWifiStatus, scanWifi } from '../services/wifi.js';

export async function handleWifiStatus(c: Context) {
  try {
    const status = await getWifiStatus();
    // 即使没有可用 Wi‑Fi 接口，也返回 200，由前端/向导决定是否提示或跳过
    return c.json(status);
  } catch (err) {
    logger.error('wifi status failed', { err });
    return c.json({ error: 'Status check failed' }, 500);
  }
}

export async function handleWifiScan(c: Context) {
  const skipRescan = c.req.query('rescan') === '0' || c.req.query('quick') === '1';
  try {
    const networks = await scanWifi({ skipRescan });
    return c.json({ networks });
  } catch (err) {
    logger.error('wifi scan failed', { err });
    // 扫描失败时返回空列表而不是 500，前端可以选择手动输入或跳过
    return c.json({ networks: [], error: 'Scan failed' });
  }
}

export async function handleWifiConnect(c: Context) {
  const body = await c.req.json().catch(() => null) as {
    ssid?: unknown;
    password?: unknown;
    skip?: unknown;
  } | null;

  if (!body) {
    return c.json({ error: 'Invalid JSON' }, 400);
  }

  if (body.skip) {
    // Skip WiFi setup (Ethernet only)
    return c.json({ success: true, message: 'WiFi skipped (Ethernet only)' });
  }

  const { ssid, password } = body;
  if (!ssid || typeof ssid !== 'string' || !ssid.trim()) {
    return c.json({ error: 'SSID is required' }, 400);
  }
  if (password !== undefined && typeof password !== 'string') {
    return c.json({ error: 'Password must be a string' }, 400);
  }

  try {
    const { message } = await connectWifi(ssid, password as string | undefined);
    const cfg = loadConfig();
    cfg.wifiConfigured = true;
    saveConfig(cfg);
    return c.json({ success: true, message });
  } catch (err) {
    logger.error('wifi connect failed', { err });
    return c.json({ error: 'Connection failed' }, 500);
  }
}

