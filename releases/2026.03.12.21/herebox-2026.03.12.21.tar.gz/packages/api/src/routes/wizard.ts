import type { Context } from 'hono';
import { setCookie } from 'hono/cookie';
import { streamSSE } from 'hono/streaming';
import { logger } from '../lib/logger.js';
import { setWizardCredentials } from '../services/auth.js';
import {
  getWizardStatus,
  isWizardCompleted,
  markWizardComplete,
  resetWizardStepsOnly,
  runWizardStep,
  skipWizardStep,
  subscribeWizard,
  type WizardBroadcastEvent,
  type WizardStepId,
} from '../services/wizard.js';

const COOKIE_NAME = 'herebox_session';

export function handleWizardStatus(c: Context) {
  return c.json(getWizardStatus());
}

export async function handleWizardStart(c: Context) {
  if (isWizardCompleted()) {
    logger.info('wizard start rejected', { reason: 'wizard_already_completed' });
    return c.json({ error: 'wizard_already_completed' }, 403);
  }
  // 新模式下不再自动执行整套步骤，仅返回当前状态（兼容旧前端）
  logger.info('wizard start (no-op in per-step mode)');
  return c.json(getWizardStatus());
}

export async function handleWizardResetSteps(c: Context) {
  if (isWizardCompleted()) {
    return c.json({ error: 'wizard_already_completed' }, 403);
  }
  resetWizardStepsOnly();
  return c.json(getWizardStatus());
}

export async function handleWizardRunStep(c: Context) {
  if (isWizardCompleted()) {
    logger.info('wizard run-step rejected', { reason: 'wizard_already_completed' });
    return c.json({ error: 'wizard_already_completed' }, 403);
  }

  const stepId = c.req.param('id') as WizardStepId | undefined;
  if (
    !stepId ||
    ![
      'configure-wifi',
      'configure-ai',
      'configure-channel',
      'complete',
    ].includes(stepId)
  ) {
    return c.json({ error: 'invalid_step' }, 400);
  }

  try {
    await runWizardStep(stepId);
    return c.json(getWizardStatus());
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    logger.warn('wizard run-step failed', { stepId, err: message });
    if (message === 'wizard_step_running') {
      return c.json({ error: 'wizard_step_running' }, 409);
    }
    if (message === 'wizard_already_completed') {
      return c.json({ error: 'wizard_already_completed' }, 403);
    }
    return c.json({ error: 'wizard_step_failed', stepId }, 500);
  }
}

const SKIPPABLE_STEPS: WizardStepId[] = [
  'configure-wifi',
  'configure-ai',
  'configure-channel',
];

export async function handleWizardSkipStep(c: Context) {
  if (isWizardCompleted()) {
    logger.info('wizard skip-step rejected', { reason: 'wizard_already_completed' });
    return c.json({ error: 'wizard_already_completed' }, 403);
  }
  const stepId = c.req.param('id') as WizardStepId | undefined;
  if (!stepId || !SKIPPABLE_STEPS.includes(stepId)) {
    return c.json({ error: 'invalid_step' }, 400);
  }
  try {
    skipWizardStep(stepId);
    return c.json(getWizardStatus());
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    logger.warn('wizard skip-step failed', { stepId, err: message });
    if (message === 'wizard_already_completed') {
      return c.json({ error: 'wizard_already_completed' }, 403);
    }
    return c.json({ error: 'wizard_skip_failed', stepId }, 500);
  }
}

export async function handleWizardComplete(c: Context) {
  if (isWizardCompleted()) return c.json(getWizardStatus());
  markWizardComplete();
  logger.info('wizard complete marked');
  return c.json(getWizardStatus());
}

export async function handleWizardSetCredentials(c: Context) {
  if (isWizardCompleted()) {
    logger.info('wizard set-credentials rejected', { reason: 'wizard_already_completed' });
    return c.json({ error: 'wizard_already_completed' }, 403);
  }
  const body = await c.req
    .json<{ username: string; password: string }>()
    .catch(() => null);
  if (!body?.username?.trim() || !body?.password) {
    logger.warn('wizard set-credentials failed', { reason: 'invalid_body' });
    return c.json({ error: 'invalid_body' }, 400);
  }
  const token = setWizardCredentials(body.username.trim(), body.password);
  if (!token) return c.json({ error: 'invalid_body' }, 400);
  markWizardComplete();
  setCookie(c, COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: 24 * 60 * 60,
  });
  logger.info('wizard set-credentials success', { username: body.username.trim() });
  return c.json({ ok: true });
}

export function handleWizardStream(c: Context) {
  if (isWizardCompleted()) {
    logger.info('wizard stream rejected', { reason: 'wizard_already_completed' });
    return c.json({ error: 'wizard_already_completed' }, 403);
  }
  logger.info('wizard stream connected');
  return streamSSE(c, async (stream) => {
    const queue: WizardBroadcastEvent[] = [];
    let resolveNext: () => void = () => {};
    const next = () => new Promise<void>((r) => { resolveNext = r; });

    const push = (event: WizardBroadcastEvent) => {
      queue.push(event);
      resolveNext();
    };

    // subscribeWizard 会在注册时立即用当前状态调用 push，然后后续事件也通过 push 入队，由下方循环串行写出
    const unsubscribe = subscribeWizard(push);

    const abort = c.req.raw.signal;
    let stopped = false;
    abort.addEventListener('abort', () => {
      stopped = true;
      resolveNext();
      unsubscribe();
    });

    while (!stopped) {
      if (queue.length === 0) await next();
      if (stopped) break;
      const event = queue.shift();
      if (!event) continue;
      try {
        await stream.writeSSE({
          data: JSON.stringify(event.payload),
          event: event.type,
        });
      } catch {
        break;
      }
    }
  });
}

