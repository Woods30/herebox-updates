import { Hono } from "hono";
import { requestLog } from "./middleware/requestLog.js";
import { requireAuth } from "./middleware/requireAuth.js";
import {
  handleLogin,
  handleSession,
  handleChangePassword,
  handleLogout,
  handleAuthCheck,
} from "./routes/auth.js";
import { handleDashboardStatus } from "./routes/dashboard.js";
import { serveStatic } from "./lib/static.js";
import {
  handleChannelsGet,
  handleChannelsPut,
  handleOpenClawConfigGet,
  handleOpenClawConfigPut,
  handleOpenClawStatus,
} from "./routes/openclaw.js";
import {
  handleSystemInfo,
  handleSystemMonitor,
  handleSystemReset,
  handleSystemUpgradeStart,
  handleSystemUpgradeStream,
  handleSystemVersion,
} from "./routes/system.js";
import {
  handleNetworkInfo,
  handleNetworkSettingsPut,
} from "./routes/network.js";
import {
  handleWifiConnect,
  handleWifiScan,
  handleWifiStatus,
} from "./routes/wifi.js";
import { handleGetAiProviders } from "./routes/ai-providers.js";
import {
  handleWizardComplete,
  handleWizardResetSteps,
  handleWizardRunStep,
  handleWizardSetCredentials,
  handleWizardSkipStep,
  handleWizardStatus,
  handleWizardStart,
  handleWizardStream,
} from "./routes/wizard.js";

const app = new Hono();

app.use("*", requestLog);

// Health check（无需登录）
app.get("/health", (c) => c.json({ ok: true }));

// Captive portal 探测：DNS 劫持后设备会请求本机，路径为 /generate_204 或 /hotspot-detect.html，便于自动弹窗
app.get("/generate_204", (c) => c.body(null, 204));
app.get("/hotspot-detect.html", (c) => c.redirect("/", 302));

app.get("/api/system/info", handleSystemInfo);
app.get("/api/system/version", handleSystemVersion);
// /api 下除 login、session 外均需登录
app.use("/api/*", requireAuth);

// Auth
app.post("/api/auth/login", handleLogin);
app.get("/api/auth/session", handleSession);
app.get("/api/auth/check", handleAuthCheck);
app.post("/api/auth/password", handleChangePassword);
app.post("/api/auth/logout", handleLogout);

// System
app.get("/api/system/monitor", handleSystemMonitor);
app.post("/api/system/reset", handleSystemReset);
app.post("/api/system/upgrade", handleSystemUpgradeStart);
app.get("/api/system/upgrade/stream", handleSystemUpgradeStream);

// AI providers（向导 Connect AI 与 Dashboard 使用）
app.get("/api/ai-providers", handleGetAiProviders);

// Wizard
app.get("/api/wizard/status", handleWizardStatus);
app.post("/api/wizard/start", handleWizardStart);
app.post("/api/wizard/reset-steps", handleWizardResetSteps);
app.post("/api/wizard/step/:id", handleWizardRunStep);
app.post("/api/wizard/step/:id/skip", handleWizardSkipStep);
app.post("/api/wizard/complete", handleWizardComplete);
app.post("/api/wizard/set-credentials", handleWizardSetCredentials);
app.get("/api/wizard/stream", handleWizardStream);

// Dashboard
app.get("/api/dashboard/status", handleDashboardStatus);

// Network
app.get("/api/network/info", handleNetworkInfo);
app.put("/api/network/settings", handleNetworkSettingsPut);

// WiFi (setup wizard)
app.get("/api/wifi/status", handleWifiStatus);
app.get("/api/wifi/scan", handleWifiScan);
app.post("/api/wifi/connect", handleWifiConnect);

// OpenClaw
app.get("/api/openclaw/status", handleOpenClawStatus);
app.get("/api/openclaw/config", handleOpenClawConfigGet);
app.put("/api/openclaw/config", handleOpenClawConfigPut);
app.get("/api/openclaw/channels", handleChannelsGet);
app.put("/api/openclaw/channels", handleChannelsPut);

// 生产环境：若设置 HEREBOX_WEB_DIST，则托管前端静态资源（SPA 回退到 index.html）
const webDist = process.env.HEREBOX_WEB_DIST;
if (webDist) {
  const staticHandler = serveStatic(webDist);
  if (staticHandler) app.get("/*", staticHandler);
}

export { app };
