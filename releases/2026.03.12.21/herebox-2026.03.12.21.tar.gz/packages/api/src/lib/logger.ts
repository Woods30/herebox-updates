const PREFIX = '[herebox-api]';

function timestamp(): string {
  return new Date().toISOString();
}

function format(level: string, msg: string, meta?: Record<string, unknown>): string {
  const metaStr = meta && Object.keys(meta).length > 0 ? ' ' + JSON.stringify(meta) : '';
  return `${timestamp()} ${PREFIX} ${level} ${msg}${metaStr}`;
}

export const logger = {
  info(msg: string, meta?: Record<string, unknown>): void {
    console.log(format('INFO', msg, meta));
  },
  warn(msg: string, meta?: Record<string, unknown>): void {
    console.warn(format('WARN', msg, meta));
  },
  error(msg: string, meta?: Record<string, unknown>): void {
    console.error(format('ERROR', msg, meta));
  },
};
