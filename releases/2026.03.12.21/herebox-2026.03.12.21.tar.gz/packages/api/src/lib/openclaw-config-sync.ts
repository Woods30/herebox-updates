import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { HereboxConfig } from './config.js';

function getOpenclawConfigPath(): string {
  const home = os.homedir();
  return path.join(home, '.openclaw', 'openclaw.json');
}

function readOpenclawJson(): Record<string, unknown> | null {
  const file = getOpenclawConfigPath();
  if (!fs.existsSync(file)) return null;
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function writeOpenclawJson(data: Record<string, unknown>): void {
  const file = getOpenclawConfigPath();
  const dir = path.dirname(file);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

/**
 * Merge HereBox AI config into ~/.openclaw/openclaw.json (models / agents.defaults).
 * If file does not exist, skip (initial write is done by init script).
 */
export function syncAiToOpenclawJson(
  provider: string,
  model: string,
  apiKey?: string
): void {
  const data = readOpenclawJson();
  if (!data) return;

  if (!data.agents || typeof data.agents !== 'object') {
    data.agents = {};
  }
  const agents = data.agents as Record<string, unknown>;
  if (!agents.defaults || typeof agents.defaults !== 'object') {
    agents.defaults = {};
  }
  const defaults = agents.defaults as Record<string, unknown>;
  if (!defaults.model || typeof defaults.model !== 'object') {
    defaults.model = {};
  }
  const modelDef = defaults.model as Record<string, unknown>;
  modelDef.primary = `${provider}/${model}`;

  if (!data.models || typeof data.models !== 'object') {
    data.models = {};
  }
  const models = data.models as Record<string, unknown>;
  if (apiKey != null && apiKey !== '') {
    models.apiKey = apiKey;
  } else if ('apiKey' in models) {
    delete models.apiKey;
  }

  writeOpenclawJson(data);
}

/**
 * Merge HereBox channels into ~/.openclaw/openclaw.json channels section.
 */
export function syncChannelsToOpenclawJson(
  channels: HereboxConfig['channels']
): void {
  const data = readOpenclawJson();
  if (!data) return;

  data.channels = {
    telegram: channels?.telegram?.token
      ? { token: channels.telegram.token }
      : undefined,
    discord: channels?.discord?.token
      ? { token: channels.discord.token }
      : undefined,
    feishu:
      channels?.feishu?.appId && channels?.feishu?.appSecret
        ? {
            appId: channels.feishu.appId,
            appSecret: channels.feishu.appSecret,
          }
        : undefined,
  };

  writeOpenclawJson(data);
}
