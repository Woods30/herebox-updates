import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export type ConnectionType = 'subscription' | 'apiKey';

export type AiModel = {
  id: string;
  nameKey: string;
};

export type AiProvider = {
  id: string;
  nameKey: string;
  descriptionKey: string;
  connectionTypes: ConnectionType[];
  models: AiModel[];
  defaultModelId: string;
};

export type AiProvidersConfig = {
  providers: AiProvider[];
};

function getHereboxDir(): string {
  const home = os.homedir();
  const dir = path.join(home, '.herebox');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

export function getAiProvidersPath(): string {
  return path.join(getHereboxDir(), 'ai-providers.json');
}

const defaultAiProviders: AiProvidersConfig = {
  providers: [
    {
      id: 'self-hosted',
      nameKey: 'ai.providers.selfHosted.name',
      descriptionKey: 'ai.providers.selfHosted.description',
      connectionTypes: ['apiKey'],
      models: [
        { id: 'local-default', nameKey: 'ai.models.localDefault' },
      ],
      defaultModelId: 'local-default',
    },
    {
      id: 'openrouter',
      nameKey: 'ai.providers.openrouter.name',
      descriptionKey: 'ai.providers.openrouter.description',
      connectionTypes: ['apiKey'],
      models: [
        { id: 'openrouter/free-default', nameKey: 'ai.models.openrouterFree' },
      ],
      defaultModelId: 'openrouter/free-default',
    },
  ],
};

export function loadAiProviders(): AiProvidersConfig {
  const file = getAiProvidersPath();
  if (!fs.existsSync(file)) {
    return defaultAiProviders;
  }
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw) as AiProvidersConfig;
    if (!data?.providers || !Array.isArray(data.providers)) {
      return defaultAiProviders;
    }
    return {
      providers: data.providers.map((p) => ({
        id: p.id ?? '',
        nameKey: p.nameKey ?? p.id,
        descriptionKey: p.descriptionKey ?? '',
        connectionTypes: Array.isArray(p.connectionTypes) ? p.connectionTypes : ['apiKey'],
        models: Array.isArray(p.models) ? p.models : [],
        defaultModelId: p.defaultModelId ?? (p.models?.[0]?.id ?? ''),
      })),
    };
  } catch {
    return defaultAiProviders;
  }
}

export function saveAiProviders(config: AiProvidersConfig): void {
  const file = getAiProvidersPath();
  fs.writeFileSync(file, JSON.stringify(config, null, 2), 'utf8');
}
