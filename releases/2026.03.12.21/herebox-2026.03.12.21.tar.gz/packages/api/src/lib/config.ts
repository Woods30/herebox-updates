import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export type HereboxConfig = {
  auth: {
    username: string;
    passwordHash: string;
    salt: string;
    passwordChangedAt?: number;
  };
  ai: {
    provider: string;
    model: string;
    apiKey?: string;
  };
  channels?: {
    telegram?: { token?: string };
    discord?: { token?: string };
    feishu?: { appId?: string; appSecret?: string };
  };
  network?: {
    interface?: string;
    address?: string;
    gateway?: string;
    nameservers?: string[];
  };
  /** WiFi 是否已经配置完成（用于 AP/向导逻辑） */
  wifiConfigured?: boolean;
  /** 向导完成时间戳，存在则表示已完成 */
  wizardCompletedAt?: number;
  /** 向导步骤持久化状态，用于服务重启后恢复 */
  wizardSteps?: {
    id: string;
    status: string;
    lastMessage?: string;
  }[];
};

const DEFAULT_USERNAME = 'admin';
const DEFAULT_PASSWORD = 'herebox';

const defaultConfig: HereboxConfig = {
  auth: {
    username: DEFAULT_USERNAME,
    passwordHash: '',
    salt: '',
  },
  ai: {
    // 先给一个简单的默认模型占位，后续可改成真实模型
    provider: 'openrouter',
    model: 'openrouter/free-default',
  },
};

function getConfigPath() {
  const envPath = process.env.HEREBOX_CONFIG_PATH;
  if (envPath && envPath.length > 0) return envPath;

  const home = os.homedir();
  const dir = path.join(home, '.herebox');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return path.join(dir, 'config.json');
}

export function loadConfig(): HereboxConfig {
  const file = getConfigPath();
  if (!fs.existsSync(file)) {
    return { ...defaultConfig };
  }
  const raw = fs.readFileSync(file, 'utf8');
  const data = JSON.parse(raw) as Partial<HereboxConfig>;
  return {
    ...defaultConfig,
    ...data,
    auth: { ...defaultConfig.auth, ...data.auth },
    ai: { ...defaultConfig.ai, ...data.ai },
  };
}

export function saveConfig(config: HereboxConfig) {
  const file = getConfigPath();
  const dir = path.dirname(file);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(file, JSON.stringify(config, null, 2), 'utf8');
}

export { DEFAULT_USERNAME, DEFAULT_PASSWORD };

