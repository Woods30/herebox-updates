import crypto from 'node:crypto';

export function hashPassword(password: string, salt?: string) {
  const s = salt ?? crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, s, 64).toString('hex');
  return { hash, salt: s };
}

export function verifyPassword(password: string, hash: string, salt: string) {
  const { hash: calc } = hashPassword(password, salt);
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(calc, 'hex'));
}

export function randomToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ── Stateless session token (HMAC-signed JSON) ───────────────────────────────

function base64UrlEncode(buf: Buffer): string {
  return buf
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str: string): Buffer {
  const pad = 4 - (str.length % 4);
  const s = str.replace(/-/g, '+').replace(/_/g, '/') + (pad < 4 ? '='.repeat(pad) : '');
  return Buffer.from(s, 'base64');
}

export function signJsonSession(payload: unknown, secret: string): string {
  const json = JSON.stringify(payload);
  const body = base64UrlEncode(Buffer.from(json, 'utf8'));
  const sig = base64UrlEncode(
    crypto.createHmac('sha256', secret).update(body).digest(),
  );
  return `${body}.${sig}`;
}

export function verifyJsonSession<T>(token: string, secret: string): T | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expectedSig = base64UrlEncode(
    crypto.createHmac('sha256', secret).update(body).digest(),
  );
  try {
    if (
      !crypto.timingSafeEqual(
        Buffer.from(sig, 'utf8'),
        Buffer.from(expectedSig, 'utf8'),
      )
    ) {
      return null;
    }
  } catch {
    return null;
  }
  try {
    const json = base64UrlDecode(body).toString('utf8');
    return JSON.parse(json) as T;
  } catch {
    return null;
  }
}

