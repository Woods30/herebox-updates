import fs from 'node:fs';
import path from 'node:path';
import type { Context } from 'hono';

const MIMES: Record<string, string> = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
};

export function serveStatic(webDist: string) {
  const root = path.resolve(webDist);
  if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
    return null;
  }
  return async (c: Context) => {
    const url = new URL(c.req.url);
    let p = url.pathname;
    if (p === '/' || p === '') p = '/index.html';
    if (p.startsWith('/')) p = p.slice(1);
    const filePath = path.join(root, path.normalize(p).replace(/^(\.\.(\/|\\))+/, ''));
    if (!filePath.startsWith(root)) return c.notFound();
    let stat: fs.Stats;
    try {
      stat = fs.statSync(filePath);
    } catch {
      if (!p.endsWith('.html')) return c.html(fs.readFileSync(path.join(root, 'index.html'), 'utf8'), 200);
      return c.notFound();
    }
    if (stat.isDirectory()) {
      const index = path.join(filePath, 'index.html');
      if (fs.existsSync(index)) {
        return c.html(fs.readFileSync(index, 'utf8'), 200);
      }
      return c.notFound();
    }
    const ext = path.extname(filePath);
    const mime = MIMES[ext] ?? 'application/octet-stream';
    const body = fs.readFileSync(filePath);
    return new Response(body, { status: 200, headers: { 'Content-Type': mime } });
  };
}
