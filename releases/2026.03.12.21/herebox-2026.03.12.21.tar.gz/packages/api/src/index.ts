import { serve } from '@hono/node-server';
import { app } from './app.js';
import { logger } from './lib/logger.js';

const port = Number(process.env.MANAGER_API_PORT ?? process.env.ONBOARDING_API_PORT ?? 17321);

logger.info('starting', { port, url: `http://127.0.0.1:${port}` });

serve({
  fetch: app.fetch,
  port,
});

