import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import zhCN from './zh-CN.json';
import enUS from './en-US.json';

const resources = {
  'zh-CN': { translation: zhCN },
  'en-US': { translation: enUS },
};

const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('herebox-lang') : null;
const initialLng =
  stored === 'zh-CN' || stored === 'en-US'
    ? stored
    : (typeof navigator !== 'undefined' && navigator.language?.startsWith('zh'))
      ? 'zh-CN'
      : 'en-US';

i18n.use(initReactI18next).init({
  resources,
  lng: initialLng,
  fallbackLng: 'en-US',
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;

