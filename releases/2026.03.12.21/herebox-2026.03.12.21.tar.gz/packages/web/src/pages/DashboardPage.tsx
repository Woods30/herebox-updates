import { ChevronDown, Loader2, RefreshCw } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { AiConfigForm } from "../components/settings/AiConfigForm";
import { ChannelsSection } from "../components/settings/ChannelsSection";
import { ConfigureWifiStep } from "../components/setup/ConfigureWifiStep";
import {
  dangerButtonClass,
  dangerButtonClassDisabled,
  dashboardPrimaryButtonClass,
  primaryButtonClass,
} from "../components/ui/link-button";

type UpgradeStatus = "idle" | "running" | "success" | "error";

type UpgradeStepStatus = "pending" | "running" | "success" | "error";

type UpgradeStep = {
  id: string;
  status: UpgradeStepStatus;
  lastMessage?: string;
};

type ComponentVersionInfo = {
  currentVersion: string | null;
  latestVersion: string | null;
  hasUpdate: boolean;
};

type VersionInfo = {
  herebox: ComponentVersionInfo;
  openclaw: ComponentVersionInfo;
  hasUpdate: boolean;
};

type SectionStatus = "pending" | "done";

type DashboardStatus = {
  network: SectionStatus;
  ai: SectionStatus;
  channels: SectionStatus;
  security: SectionStatus;
};

type MonitorSnapshot = {
  cpuUsagePercent: number;
  cpuCores: number;
  totalMem: number;
  freeMem: number;
  diskUsedPercent: number | null;
  diskFreeBytes: number | null;
  temperatureC: number | null;
  gpuName: string | null;
  gpuUsagePercent: number | null;
  gpuTemperatureC: number | null;
  uptimeSec: number;
};

type OpenClawConfig = {
  provider: string;
  model: string;
  hasApiKey: boolean;
};

const sections = ["network", "ai", "channels", "security"] as const;
const UPGRADE_SECTION = "upgrade" as const;
const RESET_SECTION = "reset" as const;

export function DashboardPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [dashboardStatus, setDashboardStatus] =
    useState<DashboardStatus | null>(null);
  const [monitor, setMonitor] = useState<MonitorSnapshot | null>(null);
  const [openSection, setOpenSection] = useState<string | null>(null);
  const [openclawConfig, setOpenclawConfig] = useState<OpenClawConfig | null>(
    null,
  );
  const [channelsStatus, setChannelsStatus] = useState<{
    telegram: { hasToken: boolean };
    discord: { hasToken: boolean };
    feishu: { configured: boolean };
  } | null>(null);
  const [cpuHistory, setCpuHistory] = useState<number[]>([]);
  const CPU_HISTORY_LEN = 20;
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [resetPassword, setResetPassword] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const [resetError, setResetError] = useState("");
  const [upgradeStatus, setUpgradeStatus] = useState<UpgradeStatus>("idle");
  const [upgradeLogs, setUpgradeLogs] = useState<string[]>([]);
  const [upgradeSteps, setUpgradeSteps] = useState<UpgradeStep[]>([]);
  const [showUpgradeLogs, setShowUpgradeLogs] = useState(false);
  const [upgradeRefreshCountdown, setUpgradeRefreshCountdown] = useState<
    number | null
  >(null);
  const upgradeStreamRef = useRef<EventSource | null>(null);
  const upgradeStatusRef = useRef<UpgradeStatus>("idle");
  const upgradeStepsRef = useRef<UpgradeStep[]>([]);
  const [versionInfo, setVersionInfo] = useState<VersionInfo | null>(null);
  const [checkingVersion, setCheckingVersion] = useState(false);
  const [upgradeConfirmOpen, setUpgradeConfirmOpen] = useState(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);

  const fetchDashboardStatus = useCallback(async () => {
    const res = await fetch("/api/dashboard/status", {
      credentials: "include",
    });
    if (!res.ok) return;
    const data = (await res.json()) as DashboardStatus;
    setDashboardStatus(data);
  }, []);

  const fetchVersionInfo = useCallback(async () => {
    try {
      const res = await fetch("/api/system/version", {
        credentials: "include",
      });
      if (res.ok) {
        const data = (await res.json()) as VersionInfo;
        setVersionInfo(data);
        return data;
      }
      setVersionInfo({
        herebox: { currentVersion: null, latestVersion: null, hasUpdate: false },
        openclaw: { currentVersion: null, latestVersion: null, hasUpdate: false },
        hasUpdate: false,
      });
      return null;
    } catch {
      setVersionInfo({
        herebox: { currentVersion: null, latestVersion: null, hasUpdate: false },
        openclaw: { currentVersion: null, latestVersion: null, hasUpdate: false },
        hasUpdate: false,
      });
      return null;
    }
  }, []);

  const checkForUpdates = useCallback(async () => {
    if (checkingVersion) return;
    setCheckingVersion(true);
    try {
      const info = await fetchVersionInfo();
      if (info?.hasUpdate) {
        const parts: string[] = [];
        if (info.herebox.hasUpdate && info.herebox.latestVersion) {
          parts.push(`HereBox v${info.herebox.latestVersion}`);
        }
        if (info.openclaw.hasUpdate && info.openclaw.latestVersion) {
          parts.push(`OpenClaw v${info.openclaw.latestVersion}`);
        }
        const componentsSummary = parts.join(", ");
        toast.success(
          t("dashboard.upgrade.checkUpdateNew", {
            components: componentsSummary || "HereBox / OpenClaw",
          }),
        );
      } else if (
        info &&
        (info.herebox.currentVersion != null ||
          info.herebox.latestVersion != null ||
          info.openclaw.currentVersion != null ||
          info.openclaw.latestVersion != null)
      ) {
        toast.success(t("dashboard.upgrade.checkUpdateDone"));
      } else {
        toast.error(t("dashboard.upgrade.checkUpdateFail"));
      }
    } finally {
      setCheckingVersion(false);
    }
  }, [checkingVersion, fetchVersionInfo, t]);

  const closeUpgradeStream = useCallback(() => {
    if (upgradeStreamRef.current) {
      upgradeStreamRef.current.close();
      upgradeStreamRef.current = null;
    }
  }, []);

  const finalizeUpgradeStatusOnError = useCallback(async () => {
    try {
      const res = await fetch("/api/system/version", {
        credentials: "include",
      });
      if (res.ok) {
        const data = (await res.json()) as VersionInfo;
        setVersionInfo(data);
        if (
          data.herebox.currentVersion &&
          data.herebox.latestVersion &&
          data.herebox.currentVersion === data.herebox.latestVersion &&
          data.openclaw.currentVersion &&
          data.openclaw.latestVersion &&
          data.openclaw.currentVersion === data.openclaw.latestVersion
        ) {
          setUpgradeStatus("success");
          setUpgradeRefreshCountdown(5);
          toast.success(t("dashboard.upgrade.success"));
          return;
        }
      }
    } catch {
      // ignore and fall through to error state
    }
    setUpgradeStatus("error");
  }, [t]);

  const startUpgrade = useCallback(() => {
    if (upgradeStatus === "running") return;
    closeUpgradeStream();
    setUpgradeLogs([]);
    setUpgradeSteps([]);
    setShowUpgradeLogs(false);
    setUpgradeRefreshCountdown(null);
    upgradeStatusRef.current = "running";
    upgradeStepsRef.current = [];
    setUpgradeStatus("running");
    const ev = new EventSource("/api/system/upgrade/stream", {
      withCredentials: true,
    });
    upgradeStreamRef.current = ev;
    ev.addEventListener("upgrade-status", (e: MessageEvent) => {
      try {
        const data = JSON.parse(e.data) as {
          running: boolean;
          status: UpgradeStatus;
          lastMessage?: string;
          steps?: UpgradeStep[];
        };
        upgradeStatusRef.current = data.status;
        if (Array.isArray(data.steps)) upgradeStepsRef.current = data.steps;
        setUpgradeStatus(data.status);
        if (Array.isArray(data.steps)) {
          setUpgradeSteps(data.steps);
        }
        if (data.status === "success") {
          toast.success(t("dashboard.upgrade.success"));
          setUpgradeRefreshCountdown(5);
          closeUpgradeStream();
          ev.close();
        } else if (data.status === "error") {
          closeUpgradeStream();
          ev.close();
        }
      } catch {
        // ignore
      }
    });
    ev.addEventListener("upgrade-log", (e: MessageEvent) => {
      try {
        const data = JSON.parse(e.data) as { message: string };
        setUpgradeLogs((prev) => [...prev, data.message]);
      } catch {
        // ignore
      }
    });
    ev.onerror = () => {
      if (upgradeStreamRef.current === ev) {
        closeUpgradeStream();
        // SSE 被打断（例如后端重启）时，根据当前步骤与版本号自检决定最终结果
        const lastStatus = upgradeStatusRef.current;
        const steps = upgradeStepsRef.current;
        const allStepsSuccess =
          steps.length > 0 && steps.every((s) => s.status === "success");
        if (lastStatus === "success" || allStepsSuccess) {
          setUpgradeStatus("success");
          setUpgradeRefreshCountdown(5);
          toast.success(t("dashboard.upgrade.success"));
        } else {
          void finalizeUpgradeStatusOnError();
        }
      }
    };
    fetch("/api/system/upgrade", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(
        versionInfo?.herebox.latestVersion
          ? { targetVersion: versionInfo.herebox.latestVersion }
          : {},
      ),
    })
      .then(async (res) => {
        if (res.ok) {
          const data = (await res.json()) as {
            status?: UpgradeStatus;
            steps?: UpgradeStep[];
          };
          if (data.status) {
            upgradeStatusRef.current = data.status;
            setUpgradeStatus(data.status);
          }
          if (Array.isArray(data.steps)) {
            upgradeStepsRef.current = data.steps;
            setUpgradeSteps(data.steps);
          }
          if (data.status === "success") {
            toast.success(t("dashboard.upgrade.success"));
            setUpgradeRefreshCountdown(5);
            closeUpgradeStream();
            ev.close();
          }
        } else if (res.status === 409) {
          // 已有升级在进行中，由 SSE 驱动状态，无需额外处理
        } else {
          // 请求返回错误（如 500），但如果 SSE 已经报告成功，则仍视为成功
          const lastStatus = upgradeStatusRef.current;
          const steps = upgradeStepsRef.current;
          const allStepsSuccess =
            steps.length > 0 && steps.every((s) => s.status === "success");
          if (lastStatus === "success" || allStepsSuccess) {
            setUpgradeStatus("success");
            setUpgradeRefreshCountdown(5);
            toast.success(t("dashboard.upgrade.success"));
          } else {
            void finalizeUpgradeStatusOnError();
          }
          closeUpgradeStream();
        }
      })
      .catch(() => {
        const lastStatus = upgradeStatusRef.current;
        const steps = upgradeStepsRef.current;
        const allStepsSuccess =
          steps.length > 0 && steps.every((s) => s.status === "success");
        if (lastStatus === "success" || allStepsSuccess) {
          setUpgradeStatus("success");
          setUpgradeRefreshCountdown(5);
          toast.success(t("dashboard.upgrade.success"));
        } else {
          void finalizeUpgradeStatusOnError();
        }
        closeUpgradeStream();
      });
  }, [upgradeStatus, t, closeUpgradeStream, versionInfo?.herebox.latestVersion, finalizeUpgradeStatusOnError]);

  useEffect(() => () => closeUpgradeStream(), [closeUpgradeStream]);

  useEffect(() => {
    if (upgradeRefreshCountdown == null || upgradeRefreshCountdown <= 0) return;
    const id = setInterval(() => {
      setUpgradeRefreshCountdown((prev) => {
        if (prev == null || prev <= 1) {
          clearInterval(id);
          window.location.reload();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [upgradeRefreshCountdown]);

  useEffect(() => {
    fetchDashboardStatus();
    const id = setInterval(fetchDashboardStatus, 30000);
    return () => clearInterval(id);
  }, [fetchDashboardStatus]);

  useEffect(() => {
    fetchVersionInfo();
  }, [fetchVersionInfo]);

  useEffect(() => {
    const interval = setInterval(fetchVersionInfo, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchVersionInfo]);

  useEffect(() => {
    let cancelled = false;
    async function fetchMonitor() {
      const res = await fetch("/api/system/monitor", {
        credentials: "include",
      });
      if (!res.ok || cancelled) return;
      const data = (await res.json()) as MonitorSnapshot;
      if (!cancelled) setMonitor(data);
    }
    fetchMonitor();
    const id = setInterval(fetchMonitor, 2000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  useEffect(() => {
    if (openSection !== "ai") return;
    let cancelled = false;
    fetch("/api/openclaw/config", { credentials: "include" })
      .then((res) => res.json())
      .then((data: OpenClawConfig) => {
        if (!cancelled) setOpenclawConfig(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [openSection]);

  useEffect(() => {
    if (openSection !== "channels") return;
    let cancelled = false;
    fetch("/api/openclaw/channels", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => {
        if (!cancelled) setChannelsStatus(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [openSection]);

  useEffect(() => {
    if (monitor == null) return;
    setCpuHistory((prev) => {
      const next = [...prev, monitor.cpuUsagePercent];
      return next.slice(-CPU_HISTORY_LEN);
    });
  }, [monitor?.cpuUsagePercent]);

  const memUsedPercent =
    monitor && monitor.totalMem > 0
      ? Math.round(
          ((monitor.totalMem - monitor.freeMem) / monitor.totalMem) * 100,
        )
      : 0;
  const memFreeMb = monitor ? Math.round(monitor.freeMem / 1024 / 1024) : 0;
  const diskFreeGb =
    monitor?.diskFreeBytes != null
      ? (monitor.diskFreeBytes / 1024 / 1024 / 1024).toFixed(0)
      : "—";

  const uptimeStr =
    monitor?.uptimeSec != null
      ? (() => {
          const h = Math.floor(monitor.uptimeSec / 3600);
          const m = Math.floor((monitor.uptimeSec % 3600) / 60);
          if (h > 24) return `${Math.floor(h / 24)}d ${h % 24}h ${m}m`;
          return `${h}h ${m}m`;
        })()
      : "—";

  return (
    <div className="space-y-4">
      <div className="w-full space-y-1">
        {sections.map((key) => {
          const status = dashboardStatus?.[key] ?? "pending";
          const title = t(`dashboard.${key}.title`);
          const isOpen = openSection === key;
          return (
            <div
              key={key}
              className="rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden"
            >
              <button
                type="button"
                className="w-full flex items-center justify-between gap-2 px-4 py-3 text-left text-sm hover:bg-slate-800/50 transition-colors"
                onClick={() => setOpenSection(isOpen ? null : key)}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <ChevronDown
                    className={`w-4 h-4 shrink-0 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                    aria-hidden
                  />
                  <span className="font-medium truncate">{title}</span>
                </span>
                <span
                  className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] ${
                    status === "done"
                      ? "bg-emerald-500/15 text-emerald-300"
                      : "bg-amber-500/15 text-amber-300"
                  }`}
                >
                  {status === "done" ? "DONE" : "PENDING"}
                </span>
              </button>
              {isOpen && (
                <div className="border-t border-slate-800 px-4 py-3 text-xs text-slate-400">
                  {key === "network" && (
                    <div className="space-y-2">
                      {dashboardStatus?.network === "pending" && (
                        <p className="text-[11px] text-amber-300/90">
                          {t("dashboard.network.apHint")}
                        </p>
                      )}
                      <ConfigureWifiStep
                        onAfterSuccessOrSkip={fetchDashboardStatus}
                        hideHotspotNote={dashboardStatus?.network === "done"}
                        mode="dashboard"
                      />
                    </div>
                  )}
                  {key === "ai" && (
                    <DashboardAiSection
                      config={openclawConfig}
                      onSaved={fetchDashboardStatus}
                      t={t}
                    />
                  )}
                  {key === "channels" && (
                    <DashboardChannelsSection
                      status={channelsStatus}
                      onSaved={fetchDashboardStatus}
                      t={t}
                    />
                  )}
                  {key === "security" && (
                    <DashboardSecuritySection
                      onSaved={() => {
                        fetchDashboardStatus();
                        navigate("/login", { replace: true });
                      }}
                      t={t}
                    />
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="w-full rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
        <button
          type="button"
          className="w-full flex items-center justify-between gap-2 px-4 py-3 text-left text-sm hover:bg-slate-800/50 transition-colors"
          onClick={() =>
            setOpenSection(
              openSection === UPGRADE_SECTION ? null : UPGRADE_SECTION,
            )
          }
        >
          <span className="flex items-center gap-2 min-w-0">
            <ChevronDown
              className={`w-4 h-4 shrink-0 text-slate-400 transition-transform duration-200 ${openSection === UPGRADE_SECTION ? "rotate-180" : ""}`}
              aria-hidden
            />
            <span className="font-medium truncate text-cyan-200/90">
              {t("dashboard.upgrade.title")}
            </span>
          </span>
        </button>
        {openSection === UPGRADE_SECTION && (
          <div className="border-t border-slate-800 px-4 py-3 text-xs text-slate-400">
            <div className="mb-3 space-y-1">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="text-[11px] font-semibold text-slate-300">
                  {t("dashboard.upgrade.hereboxLabel", "HereBox")}
                </span>
                <span>
                  {t("dashboard.upgrade.currentVersion")}:{" "}
                  <span className="text-slate-200 font-medium">
                    {versionInfo
                      ? versionInfo.herebox.currentVersion ?? "—"
                      : "…"}
                  </span>
                </span>
                <span>
                  {t("dashboard.upgrade.latestVersion")}:{" "}
                  <span className="text-slate-200 font-medium">
                    {versionInfo
                      ? versionInfo.herebox.latestVersion ?? "—"
                      : "…"}
                  </span>
                </span>
                {versionInfo?.herebox.hasUpdate && (
                  <span className="inline-flex items-center rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-300">
                    {t("dashboard.upgrade.hasUpdateBadge", "有新版本")}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="text-[11px] font-semibold text-slate-300">
                  {t("dashboard.upgrade.openclawLabel", "OpenClaw")}
                </span>
                <span>
                  {t("dashboard.upgrade.currentVersion")}:{" "}
                  <span className="text-slate-200 font-medium">
                    {versionInfo
                      ? versionInfo.openclaw.currentVersion ?? "—"
                      : "…"}
                  </span>
                </span>
                <span>
                  {t("dashboard.upgrade.latestVersion")}:{" "}
                  <span className="text-slate-200 font-medium">
                    {versionInfo
                      ? versionInfo.openclaw.latestVersion ?? "—"
                      : "…"}
                  </span>
                </span>
                {versionInfo?.openclaw.hasUpdate && (
                  <span className="inline-flex items-center rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-300">
                    {t("dashboard.upgrade.hasUpdateBadge", "有新版本")}
                  </span>
                )}
                <button
                  type="button"
                  onClick={checkForUpdates}
                  disabled={checkingVersion}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-600 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-300 hover:bg-slate-700/80 disabled:opacity-50"
                >
                  <RefreshCw
                    className={`h-3.5 w-3.5 ${checkingVersion ? "animate-spin" : ""}`}
                    aria-hidden
                  />
                  {t("dashboard.upgrade.checkUpdate")}
                </button>
              </div>
            </div>
            {versionInfo &&
              !versionInfo.hasUpdate &&
              versionInfo.herebox.currentVersion != null &&
              versionInfo.herebox.latestVersion != null &&
              versionInfo.openclaw.currentVersion != null &&
              versionInfo.openclaw.latestVersion != null && (
                <p className="mb-3 text-emerald-400/90">
                  {t("dashboard.upgrade.noUpdate")}
                </p>
              )}
            {versionInfo &&
              versionInfo.herebox.currentVersion == null &&
              versionInfo.herebox.latestVersion == null &&
              versionInfo.openclaw.currentVersion == null &&
              versionInfo.openclaw.latestVersion == null && (
                <p className="mb-3 text-slate-500">
                  {t("dashboard.upgrade.versionUnknown")}
                </p>
              )}
            {versionInfo?.hasUpdate && (
              <p className="mb-3">{t("dashboard.upgrade.description")}</p>
            )}
            <div className="flex flex-wrap gap-2">
              {versionInfo?.hasUpdate === true && upgradeStatus !== "running" && (
                <button
                  type="button"
                  onClick={() => setUpgradeConfirmOpen(true)}
                  className={primaryButtonClass}
                >
                  {t("dashboard.upgrade.start")}
                </button>
              )}
              {upgradeStatus === "running" && (
                <span className="flex items-center gap-2 text-cyan-300">
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden />
                  {t("wizard.update.running", "正在执行更新…")}
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="w-full rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
        <button
          type="button"
          className="w-full flex items-center justify-between gap-2 px-4 py-3 text-left text-sm hover:bg-slate-800/50 transition-colors"
          onClick={() =>
            setOpenSection(openSection === RESET_SECTION ? null : RESET_SECTION)
          }
        >
          <span className="flex items-center gap-2 min-w-0">
            <ChevronDown
              className={`w-4 h-4 shrink-0 text-slate-400 transition-transform duration-200 ${openSection === RESET_SECTION ? "rotate-180" : ""}`}
              aria-hidden
            />
            <span className="font-medium truncate text-rose-300/90">
              {t("dashboard.reset.title")}
            </span>
          </span>
        </button>
        {openSection === RESET_SECTION && (
          <div className="border-t border-slate-800 px-4 py-3 text-xs text-slate-400">
            <p className="mb-3">{t("dashboard.reset.description")}</p>
            <p className="mb-3 text-amber-300/90">
              {t("dashboard.reset.warning")}
            </p>
            <button
              type="button"
              onClick={() => {
                setResetError("");
                setResetPassword("");
                setResetModalOpen(true);
              }}
              className={dangerButtonClass}
            >
              {t("dashboard.reset.confirm")}
            </button>
          </div>
        )}
      </div>

      {resetModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-sm rounded-xl border border-slate-700 bg-slate-900 p-4 shadow-xl">
            <h3 className="text-sm font-semibold text-slate-200 mb-2">
              {t("dashboard.reset.title")}
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              {t("dashboard.reset.warning")}
            </p>
            {resetError && (
              <p className="text-xs text-rose-400 mb-2" role="alert">
                {resetError}
              </p>
            )}
            <label className="block text-xs text-slate-400 mb-1">
              {t("dashboard.reset.passwordLabel")}
            </label>
            <input
              type="password"
              value={resetPassword}
              onChange={(e) => setResetPassword(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 mb-4"
              placeholder=""
            />
            <div className="flex gap-3 justify-end">
              <button
                type="button"
                onClick={() => {
                  setResetModalOpen(false);
                  setResetPassword("");
                  setResetError("");
                }}
                className="rounded-xl border border-slate-600 px-6 py-3 text-sm font-medium text-slate-300 hover:bg-slate-800"
              >
                {t("common.cancel")}
              </button>
              <button
                type="button"
                disabled={resetLoading}
                onClick={async () => {
                  setResetError("");
                  setResetLoading(true);
                  try {
                    const res = await fetch("/api/system/reset", {
                      method: "POST",
                      credentials: "include",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ password: resetPassword }),
                    });
                    const data = await res.json().catch(() => ({}));
                    if (!res.ok) {
                      setResetError(
                        (data as { error?: string }).error ===
                          "invalid_password"
                          ? t("login.errorCredentials")
                          : t("login.errorGeneric"),
                      );
                      setResetLoading(false);
                      return;
                    }
                    toast.success(t("dashboard.reset.success"));
                    setResetModalOpen(false);
                    navigate("/wizard", { replace: true });
                  } catch {
                    setResetError(t("login.errorGeneric"));
                  } finally {
                    setResetLoading(false);
                  }
                }}
                className={dangerButtonClassDisabled}
              >
                {resetLoading ? "…" : t("dashboard.reset.confirm")}
              </button>
            </div>
          </div>
        </div>
      )}

      {upgradeConfirmOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-sm rounded-xl border border-slate-700 bg-slate-900 p-4 shadow-xl">
            <h3 className="text-sm font-semibold text-slate-200 mb-2">
              {t("dashboard.upgrade.confirmTitle", "确认升级")}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {t(
                "dashboard.upgrade.confirmDescription",
                "升级过程中 HereBox 服务可能会短暂中断，请确认当前没有重要任务正在运行。",
              )}
            </p>
            <div className="flex gap-3 justify-end">
              <button
                type="button"
                onClick={() => setUpgradeConfirmOpen(false)}
                className="rounded-xl border border-slate-600 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800"
              >
                {t("dashboard.upgrade.confirmCancel", "取消")}
              </button>
              <button
                type="button"
                onClick={() => {
                  setUpgradeConfirmOpen(false);
                  setUpgradeModalOpen(true);
                  startUpgrade();
                }}
                className={primaryButtonClass}
              >
                {t("dashboard.upgrade.confirmOk", "确认升级")}
              </button>
            </div>
          </div>
        </div>
      )}

      {upgradeModalOpen && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-lg max-h-[80vh] overflow-y-auto rounded-xl border border-slate-700 bg-slate-900 p-4 shadow-2xl">
            <h3 className="text-sm font-semibold text-slate-200 mb-1">
              {t("dashboard.upgrade.modalTitle", "系统升级进度")}
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              {upgradeStatus === "running" &&
                t(
                  "dashboard.upgrade.modalSubtitleRunning",
                  "正在升级 HereBox 与 OpenClaw，请不要关闭本页面。",
                )}
              {upgradeStatus === "success" &&
                t(
                  "dashboard.upgrade.modalSubtitleSuccess",
                  "升级已完成，即将刷新页面。",
                )}
              {upgradeStatus === "error" &&
                t(
                  "dashboard.upgrade.modalSubtitleError",
                  "升级发生错误，请查看日志后重试。",
                )}
            </p>

            {upgradeSteps.length > 0 && (
              <div className="mb-3 space-y-1">
                <p className="text-[11px] text-slate-500">
                  {t("wizard.stepsSummary", "各步骤状态")}
                </p>
                <ul className="space-y-1">
                  {upgradeSteps.map((s) => {
                    const labelKey = `install.steps.${s.id}` as const;
                    const label =
                      (t(labelKey, {
                        defaultValue: s.id,
                      }) as string) || s.id;
                    let badgeClass =
                      "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium";
                    let badgeText = "";
                    switch (s.status) {
                      case "success":
                        badgeClass += " bg-emerald-500/15 text-emerald-300";
                        badgeText = t("common.done");
                        break;
                      case "running":
                        badgeClass += " bg-cyan-500/15 text-cyan-300";
                        badgeText = t("common.running");
                        break;
                      case "error":
                        badgeClass += " bg-rose-500/15 text-rose-300";
                        badgeText = t("common.error");
                        break;
                      default:
                        badgeClass += " bg-slate-700/40 text-slate-300";
                        badgeText = t("common.pending");
                    }
                    return (
                      <li
                        key={s.id}
                        className="flex items-center justify-between gap-2 rounded-md border border-slate-800/80 bg-slate-900/80 px-2 py-1.5"
                      >
                        <div className="min-w-0 truncate text-slate-100 text-[11px]">
                          {label}
                        </div>
                        <span className={badgeClass}>{badgeText}</span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {upgradeStatus !== "idle" && (
              <div className="mb-3">
                <button
                  type="button"
                  className="flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-300"
                  onClick={() => setShowUpgradeLogs((v) => !v)}
                >
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      showUpgradeLogs ? "rotate-180" : ""
                    }`}
                    aria-hidden
                  />
                  {t("wizard.update.logTitle", "详细日志")}
                </button>
                {showUpgradeLogs && (
                  <div className="mt-1 max-h-48 overflow-y-auto rounded-md border border-slate-700 bg-slate-900/80 px-2 py-1.5 font-mono text-[11px] text-slate-300">
                    {upgradeLogs.length === 0 &&
                    upgradeStatus !== "success" &&
                    upgradeStatus !== "error" ? (
                      <span className="text-slate-500">
                        {t("wizard.update.logPlaceholder", "等待输出…")}
                      </span>
                    ) : (
                      upgradeLogs.map((line, i) => <div key={i}>{line}</div>)
                    )}
                  </div>
                )}
              </div>
            )}

            <div className="mt-3 flex justify-end gap-2">
              {upgradeStatus === "success" && (
                <button
                  type="button"
                  onClick={() => setUpgradeModalOpen(false)}
                  className="rounded-xl border border-slate-600 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800"
                >
                  {t("common.ok", "知道了")}
                </button>
              )}
              {upgradeStatus === "error" && (
                <>
                  <button
                    type="button"
                    onClick={() => startUpgrade()}
                    className={primaryButtonClass}
                  >
                    {t("wizard.update.retry", "重试")}
                  </button>
                  <button
                    type="button"
                    onClick={() => setUpgradeModalOpen(false)}
                    className="rounded-xl border border-slate-600 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800"
                  >
                    {t("common.close", "关闭")}
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="w-full">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
            <div className="text-[11px] text-slate-400">
              {t("dashboard.monitor.cpu")}
            </div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-lg font-semibold">
                {monitor != null ? `${monitor.cpuUsagePercent}%` : "—"}
              </span>
              <span className="text-[11px] text-slate-500">
                {monitor != null ? `${monitor.cpuCores} cores` : ""}
              </span>
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
            <div className="text-[11px] text-slate-400">
              {t("dashboard.monitor.memory")}
            </div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-lg font-semibold">
                {monitor != null ? `${memUsedPercent}%` : "—"}
              </span>
              <span className="text-[11px] text-slate-500">
                {monitor != null ? `${memFreeMb} MB free` : ""}
              </span>
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
            <div className="text-[11px] text-slate-400">
              {t("dashboard.monitor.storage")}
            </div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-lg font-semibold">
                {monitor?.diskUsedPercent != null
                  ? `${monitor.diskUsedPercent}%`
                  : "—"}
              </span>
              <span className="text-[11px] text-slate-500">
                {diskFreeGb !== "—" ? `${diskFreeGb}G free` : ""}
              </span>
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
            <div className="text-[11px] text-slate-400">
              {t("dashboard.monitor.temperature")}
            </div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-lg font-semibold">
                {monitor?.temperatureC != null
                  ? `${monitor.temperatureC}°C`
                  : "—"}
              </span>
            </div>
          </div>
          {monitor?.uptimeSec != null && (
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
              <div className="text-[11px] text-slate-400">
                {t("dashboard.system.uptime")}
              </div>
              <div className="mt-1 flex items-baseline justify-between">
                <span className="text-lg font-semibold">{uptimeStr}</span>
              </div>
            </div>
          )}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2.5">
            <div className="text-[11px] text-slate-400">
              {t("dashboard.monitor.cpuTimeline")}
            </div>
            <div className="mt-1 h-10 rounded-md bg-slate-900/80 flex items-end gap-0.5 overflow-hidden">
              {cpuHistory.length === 0 ? (
                <span className="text-[10px] text-slate-500 self-center">
                  —
                </span>
              ) : (
                cpuHistory.map((p, i) => (
                  <div
                    key={i}
                    className="flex-1 min-w-[2px] rounded-sm bg-cyan-500/70 transition-all"
                    style={{ height: `${Math.min(100, Math.max(2, p))}%` }}
                    title={`${p}%`}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DashboardSecuritySection({
  onSaved,
  t,
}: {
  onSaved: () => void;
  t: (key: string) => string;
}) {
  const [current, setCurrent] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (newPass !== confirm) {
      setError(t("login.errorGeneric"));
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword: current,
          newPassword: newPass,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg =
          (data as { error?: string }).error === "invalid_current_password"
            ? t("login.errorCredentials")
            : t("login.errorGeneric");
        setError(msg);
        toast.error(msg);
        setLoading(false);
        return;
      }
      setSuccess(true);
      toast.success(t("dashboard.security.saved"));
      setTimeout(onSaved, 1500);
    } catch {
      const msg = t("login.errorGeneric");
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  if (success)
    return (
      <p className="text-emerald-400 text-sm">
        {t("dashboard.security.saved")}
      </p>
    );

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {error && (
        <p className="text-rose-400 text-[11px]" role="alert">
          {error}
        </p>
      )}
      <div>
        <label className="block text-slate-300 mb-1">
          {t("dashboard.security.currentPassword")}
        </label>
        <input
          type="password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
          className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm"
          required
        />
      </div>
      <div>
        <label className="block text-slate-300 mb-1">
          {t("dashboard.security.newPassword")}
        </label>
        <input
          type="password"
          value={newPass}
          onChange={(e) => setNewPass(e.target.value)}
          className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm"
          required
        />
      </div>
      <div>
        <label className="block text-slate-300 mb-1">
          {t("dashboard.security.confirmPassword")}
        </label>
        <input
          type="password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm"
          required
        />
      </div>
      <button
        type="submit"
        disabled={loading}
        className={dashboardPrimaryButtonClass}
      >
        {t("dashboard.security.changePassword")}
      </button>
    </form>
  );
}

type ChannelsStatus = {
  telegram: { hasToken: boolean };
  discord: { hasToken: boolean };
  feishu: { configured: boolean };
};

type ChannelTab = "telegram" | "discord" | "feishu";

function DashboardChannelsSection({
  status,
  onSaved,
  t,
}: {
  status: ChannelsStatus | null;
  onSaved: () => void;
  t: (key: string) => string;
}) {
  return (
    <ChannelsSection status={status} onSaved={onSaved} t={t} mode="dashboard" />
  );
}

function DashboardAiSection({
  config,
  onSaved,
  t,
}: {
  config: OpenClawConfig | null;
  onSaved: () => void;
  t: (key: string) => string;
}) {
  return (
    <AiConfigForm config={config} onSaved={onSaved} t={t} mode="dashboard" />
  );
}
