/**
 * OpenClaw Control UI 通过 iframe 嵌入，便于在应用内回退到向导/管理面板。
 */
export function OpenClawPage() {
  return (
    <div className="absolute inset-0 flex flex-col min-h-0">
      <iframe
        src="/openclaw-ui/"
        title="OpenClaw Control"
        className="flex-1 w-full min-h-0 border-0 bg-slate-900"
      />
    </div>
  );
}
