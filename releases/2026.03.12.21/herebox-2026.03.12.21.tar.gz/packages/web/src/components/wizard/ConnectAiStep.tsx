import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { cn } from '../../lib/utils';

export type ConnectionType = 'subscription' | 'apiKey';

export type AiModel = {
  id: string;
  nameKey: string;
};

export type AiProvider = {
  id: string;
  nameKey: string;
  descriptionKey: string;
  connectionTypes: ConnectionType[];
  models: AiModel[];
  defaultModelId: string;
};

export type AiProvidersConfig = {
  providers: AiProvider[];
};

type OpenClawConfig = {
  provider: string;
  model: string;
  hasApiKey: boolean;
};

type ConnectAiStepProps = {
  onFinish: () => void;
  className?: string;
};

export function ConnectAiStep({ onFinish, className }: ConnectAiStepProps) {
  const { t } = useTranslation();
  const [config, setConfig] = useState<AiProvidersConfig | null>(null);
  const [current, setCurrent] = useState<OpenClawConfig | null>(null);
  const [selectedProviderId, setSelectedProviderId] = useState<string>('');
  const [selectedModelId, setSelectedModelId] = useState<string>('');
  const [apiKey, setApiKey] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      fetch('/api/ai-providers', { credentials: 'include' }).then((r) =>
        r.ok ? r.json() : null,
      ),
      fetch('/api/openclaw/config', { credentials: 'include' }).then((r) =>
        r.ok ? r.json() : null,
      ),
    ]).then(([providersData, openclawData]) => {
      if (cancelled) return;
      const prov = providersData as AiProvidersConfig | null;
      const cfg = openclawData as OpenClawConfig | null;
      setConfig(prov ?? { providers: [] });
      setCurrent(cfg ?? null);
      const defaultProvider = prov?.providers?.find((p) => p.id === 'self-hosted') ?? prov?.providers?.[0];
      const providerId = cfg?.provider ?? defaultProvider?.id ?? '';
      const modelId = cfg?.model ?? defaultProvider?.defaultModelId ?? defaultProvider?.models?.[0]?.id ?? '';
      setSelectedProviderId(providerId);
      setSelectedModelId(modelId);
      if (cfg?.hasApiKey) setApiKey(''); // 不回显 Key，仅用 hasApiKey 显示罐装提示
    }).catch(() => setLoadError('load_failed'));
    return () => { cancelled = true; };
  }, []);

  const selectedProvider = config?.providers?.find((p) => p.id === selectedProviderId);
  const needsApiKey = selectedProvider?.connectionTypes?.includes('apiKey') ?? true;
  const hasCannedKey = current?.hasApiKey === true && selectedProviderId === current?.provider;

  const handleSubmit = useCallback(async () => {
    if (!selectedProviderId || !selectedModelId) return;
    setSaving(true);
    try {
      const body: { provider: string; model: string; apiKey?: string } = {
        provider: selectedProviderId,
        model: selectedModelId,
      };
      if (needsApiKey && apiKey.trim()) body.apiKey = apiKey.trim();
      const res = await fetch('/api/openclaw/config', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) onFinish();
    } finally {
      setSaving(false);
    }
  }, [selectedProviderId, selectedModelId, needsApiKey, apiKey, onFinish]);

  if (loadError) {
    return (
      <div className={cn('rounded-2xl border border-slate-800 bg-slate-900/60 p-6', className)}>
        <p className="text-sm text-slate-400">{t('common.error')}</p>
        <button
          type="button"
          onClick={onFinish}
          className="mt-3 rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300"
        >
          {t('wizard.continue')}
        </button>
      </div>
    );
  }

  if (!config) {
    return (
      <div className={cn('rounded-2xl border border-slate-800 bg-slate-900/60 p-6', className)}>
        <p className="text-sm text-slate-400">{t('wizard.connectAi.loading')}</p>
      </div>
    );
  }

  return (
    <div className={cn('rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl shadow-black/50 backdrop-blur flex flex-col', className)}>
      <h2 className="text-lg font-semibold mb-1">{t('wizard.connectAi.title')}</h2>
      <p className="text-sm text-slate-400 mb-6">{t('wizard.connectAi.subtitle')}</p>

      <div className="space-y-4 flex-1">
        <div>
          <label className="text-xs font-medium text-slate-400 mb-2 block">{t('dashboard.ai.provider')}</label>
          <RadioGroup
            value={selectedProviderId}
            onValueChange={(v) => {
              setSelectedProviderId(v);
              const p = config.providers.find((x) => x.id === v);
              if (p) {
                setSelectedModelId((p.defaultModelId || p.models?.[0]?.id) ?? '');
              }
            }}
            className="grid gap-2"
          >
            {config.providers.map((p) => (
              <RadioGroupItem key={p.id} value={p.id} className="flex items-start gap-2">
                <span className="flex-1">
                  <span className="font-medium">{t(p.nameKey)}</span>
                  <span className="ml-2 text-xs text-slate-500">{t(p.descriptionKey)}</span>
                </span>
              </RadioGroupItem>
            ))}
          </RadioGroup>
        </div>

        {selectedProvider && (
          <div>
            <label className="text-xs font-medium text-slate-400 mb-2 block">{t('dashboard.ai.model')}</label>
            <Select value={selectedModelId} onValueChange={setSelectedModelId}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {selectedProvider.models.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {t(m.nameKey)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {needsApiKey && (
          <div>
            <label className="text-xs font-medium text-slate-400 mb-2 block">{t('dashboard.ai.apiKey')}</label>
            {hasCannedKey ? (
              <p className="text-xs text-cyan-400 rounded-md bg-slate-800/80 px-3 py-2">
                {t('wizard.connectAi.cannedKeyHint')}
              </p>
            ) : (
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={t('dashboard.ai.apiKey')}
                className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            )}
          </div>
        )}
      </div>

      <div className="mt-6 pt-4 border-t border-slate-700/80 flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={handleSubmit}
          disabled={saving || !selectedProviderId || !selectedModelId}
          className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-500 disabled:opacity-50"
        >
          {saving ? t('common.save') + '…' : t('common.save')}
        </button>
        <button
          type="button"
          onClick={onFinish}
          className="rounded-lg border border-slate-600 bg-slate-800/80 px-4 py-2 text-sm font-medium text-slate-300 hover:bg-slate-700"
        >
          {t('wizard.skip')}
        </button>
      </div>
    </div>
  );
}
