import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  dashboardPrimaryButtonClass,
  linkButtonClass,
  primaryButtonClassDisabled,
} from '../ui/link-button';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';

type Mode = 'dashboard' | 'wizard';

type OpenClawAiConfig = {
  provider: string;
  model: string;
  hasApiKey: boolean;
};

type Props = {
  config: OpenClawAiConfig | null;
  onSaved: () => void;
  t: (key: string, defaultValue?: string) => string;
  mode?: Mode;
  /** 在向导模式下保存成功后，通知父组件推进步骤 */
  onWizardConfigured?: () => void;
  /** 向导模式下与保存按钮同一行的跳过回调 */
  onSkip?: () => void;
};

const AI_PROVIDERS = ['openrouter', 'anthropic', 'openai', 'minimax'];

export function AiConfigForm({ config, onSaved, t, mode = 'dashboard', onWizardConfigured, onSkip }: Props) {
  const [provider, setProvider] = useState(config?.provider ?? '');
  const [model, setModel] = useState(config?.model ?? '');
  const [apiKey, setApiKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [providerChosen, setProviderChosen] = useState(Boolean(config?.provider));

  useEffect(() => {
    if (config) {
      setProvider(config.provider);
      setModel(config.model);
      setProviderChosen(Boolean(config.provider));
    }
  }, [config]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!provider) {
      toast.error(t('wizard.ai.missingProvider', '请选择一个模型提供商'));
      return;
    }
    if (!model.trim()) {
      toast.error(t('wizard.ai.modelRequired', '请填写模型名称'));
      return;
    }
    if (!apiKey.trim()) {
      toast.error(t('wizard.ai.apiKeyRequired', '请填写 API Key'));
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/openclaw/config', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          model: model || undefined,
          apiKey: apiKey || undefined,
        }),
      });
      if (!res.ok) {
        toast.error(t('login.errorGeneric'));
        setLoading(false);
        return;
      }
      toast.success(
        mode === 'wizard'
          ? t('wizard.ai.save', '保存配置并继续')
          : t('dashboard.ai.saved'),
      );
      setApiKey('');
      onSaved();
      if (mode === 'wizard' && onWizardConfigured) {
        onWizardConfigured();
      }
    } catch {
      toast.error(t('login.errorGeneric'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-3"
    >
      <div className="space-y-2">
        <label className="block text-[11px] font-medium text-slate-400 mb-1">
          {t('wizard.ai.provider')}
        </label>
        <RadioGroup
          value={provider}
          onValueChange={(val) => {
            setProvider(val);
            setProviderChosen(true);
          }}
          className="grid gap-2 sm:grid-cols-2"
        >
          {AI_PROVIDERS.map((p) => {
            const isConfigured =
              config?.provider && config?.model && config.provider === p;
            return (
              <RadioGroupItem key={p} value={p}>
                <div className="flex flex-col items-start">
                  <span className="text-xs font-medium capitalize inline-flex items-center gap-1.5">
                    {t(`ai.providers.${p}.name`, p)}
                    {isConfigured && (
                      <span className="rounded-full bg-emerald-500/20 px-1.5 py-0.5 text-[10px] text-emerald-300">
                        {t('dashboard.ai.apiKeyConfigured', '已配置')}
                      </span>
                    )}
                  </span>
                  <span className="mt-0.5 text-[10px] text-slate-400">
                    {t(`ai.providers.${p}.description`)}
                  </span>
                </div>
              </RadioGroupItem>
            );
          })}
        </RadioGroup>
      </div>

      {providerChosen && provider && (
        <>
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t('wizard.ai.model')}
            </label>
            <input
              type="text"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              placeholder={t('wizard.ai.modelPlaceholderExample', '例如：openrouter/free-default')}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500"
              required
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t('wizard.ai.apiKey')}
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={config?.hasApiKey ? '••••••••' : ''}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500"
              required
            />
          </div>
        </>
      )}

      <div className={mode === 'wizard' && onSkip ? 'flex flex-wrap items-center gap-3' : ''}>
        <button
          type="submit"
          disabled={loading}
          className={mode === 'wizard' ? primaryButtonClassDisabled : dashboardPrimaryButtonClass}
        >
          {mode === 'wizard'
            ? loading
              ? t('wizard.ai.saving')
              : t('wizard.ai.save')
            : t('dashboard.ai.save')}
        </button>
        {mode === 'wizard' && onSkip && (
          <button
            type="button"
            onClick={onSkip}
            className={linkButtonClass}
          >
            {t('wizard.skip', '跳过')}
          </button>
        )}
      </div>
    </form>
  );
}

