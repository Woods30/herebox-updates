import { useTranslation } from 'react-i18next';
import { ChannelsSection } from '../settings/ChannelsSection';

type Props = {
  onRunStep?: () => void;
  onSkip?: () => void;
};

export function ConfigureChannelStep({ onRunStep, onSkip }: Props) {
  const { t } = useTranslation();

  return (
    <div className="space-y-3">
      <ChannelsSection
        status={null}
        onSaved={() => {
          if (onRunStep) onRunStep();
        }}
        onSkip={onSkip}
        t={t}
        mode="wizard"
        onWizardDone={onRunStep}
      />
    </div>
  );
}

