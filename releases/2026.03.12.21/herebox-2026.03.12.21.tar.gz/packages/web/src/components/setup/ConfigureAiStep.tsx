import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { linkButtonClass } from '../ui/link-button';
import { AiConfigForm } from '../settings/AiConfigForm';

type Props = {
  /** AI 基本配置完成后，通知上层触发后端 configure-ai 步骤并推进状态 */
  onConfigured?: () => void;
  /** 用户点击跳过时回调 */
  onSkip?: () => void;
};

type AiProvider = {
  id: string;
  name: string;
  models?: { id: string; name: string }[];
};

type OpenClawAiConfig = {
  provider?: string;
  model?: string;
  hasApiKey: boolean;
};

export function ConfigureAiStep({ onConfigured, onSkip }: Props) {
  const { t } = useTranslation();
  const [providers, setProviders] = useState<AiProvider[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [config, setConfig] = useState<OpenClawAiConfig | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        const [provRes, cfgRes] = await Promise.all([
          fetch('/api/ai-providers', { credentials: 'include' }),
          fetch('/api/openclaw/config', { credentials: 'include' }),
        ]);
        const provData = await provRes.json().catch(() => null);
        const cfgData = (await cfgRes.json().catch(() => null)) as OpenClawAiConfig | null;
        if (!provRes.ok || !Array.isArray(provData?.providers)) {
          setError(
            provData?.error ||
              t('wizard.ai.loadProvidersFailed')
          );
          return;
        }
        setProviders(provData.providers);
        if (cfgRes.ok && cfgData) {
          setConfig({
            provider: cfgData.provider || '',
            model: cfgData.model || '',
            hasApiKey: Boolean(cfgData.hasApiKey),
          });
        } else {
          setConfig(null);
        }
      } catch {
        setError(t('wizard.ai.loadConfigFailed'));
      } finally {
        setLoading(false);
      }
    };
    fetchData().catch(() => {});
  }, []);

  return (
    <div className="space-y-3">
      {error && (
        <p className="text-[11px] text-rose-400" role="alert">
          {error}
        </p>
      )}
      {!loading && providers.length > 0 && (
        <AiConfigForm
          config={
            config ?? {
              provider: providers[0]?.id ?? 'openrouter',
              model: '',
              hasApiKey: false,
            }
          }
          onSaved={() => {
            if (onConfigured) onConfigured();
          }}
          onSkip={onSkip}
          t={t}
          mode="wizard"
        />
      )}
      {!loading && onSkip && (error || providers.length === 0) && (
        <button
          type="button"
          onClick={onSkip}
          className={linkButtonClass}
        >
          {t('wizard.skip', '跳过')}
        </button>
      )}
    </div>
  );
}

