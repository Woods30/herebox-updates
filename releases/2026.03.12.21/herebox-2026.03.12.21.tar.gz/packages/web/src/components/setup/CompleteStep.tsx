export function CompleteStep() {
  return (
    <div className="space-y-4">
      <div className="mx-auto mt-2 h-6 w-6 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
    </div>
  );
}

