/** 统一主按钮样式（向导 / 欢迎页「开始」、各步骤主操作） */
export const primaryButtonClass =
  "rounded-xl bg-cyan-600 px-6 py-3 text-sm font-semibold text-white shadow-md shadow-cyan-500/20 hover:bg-cyan-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950";

export const primaryButtonClassDisabled =
  `${primaryButtonClass} disabled:opacity-60`;

/** 统一危险操作按钮样式（Dashboard 重置等） */
export const dangerButtonClass =
  "rounded-xl bg-rose-600 px-6 py-3 text-sm font-semibold text-white shadow-md shadow-rose-500/20 hover:bg-rose-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950";

export const dangerButtonClassDisabled =
  `${dangerButtonClass} disabled:opacity-50`;

/** Dashboard 表单主按钮样式（WiFi / AI / Channels / 修改密码 等） */
export const dashboardPrimaryButtonClass =
  "rounded-md bg-cyan-500 px-3 py-1.5 text-sm font-medium text-slate-950 hover:bg-cyan-400 disabled:opacity-60";

/** 统一 link 按钮样式（下划线、次要操作如「跳过」） */
export const linkButtonClass =
  "text-sm text-slate-500 underline underline-offset-2 hover:text-cyan-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400/50 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900";

export const linkButtonClassDisabled = `${linkButtonClass} disabled:opacity-60 disabled:pointer-events-none`;
