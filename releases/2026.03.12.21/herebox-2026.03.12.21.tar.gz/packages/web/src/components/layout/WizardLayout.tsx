import { ReactNode } from "react";
import { useTranslation } from "react-i18next";

type Props = { children: ReactNode };

export function WizardLayout({ children }: Props) {
  const { i18n } = useTranslation();
  const currentLang = i18n.language.startsWith("zh") ? "zh-CN" : "en-US";

  const switchLang = () => {
    const next = currentLang === "zh-CN" ? "en-US" : "zh-CN";
    i18n.changeLanguage(next);
    localStorage.setItem("herebox-lang", next);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      <header className="shrink-0 flex items-center justify-center relative h-20 px-4">
        <img
          src="/logo.png"
          alt="HereBox"
          className="h-10 w-auto object-contain drop-shadow-[0_0_12px_rgba(56,189,248,0.45)]"
        />
        <div className="absolute top-1/2 right-4 -translate-y-1/2">
          <button
            type="button"
            onClick={switchLang}
            className="inline-flex items-center gap-1 rounded-full border border-slate-700 px-2.5 py-1 text-[11px] text-slate-200 hover:border-cyan-400/70 hover:text-cyan-100"
          >
            {currentLang === "zh-CN" ? "中文" : "EN"}
          </button>
        </div>
      </header>
      <main className="flex-1 flex flex-col min-h-0">
        <div className="mx-auto w-full max-w-7xl px-4 py-6 flex-1 flex flex-col">
          {children}
        </div>
      </main>
    </div>
  );
}
