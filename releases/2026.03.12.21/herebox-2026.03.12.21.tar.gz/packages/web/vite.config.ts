import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:17321',
        configure: (proxy) => {
          proxy.on('proxyReq', (proxyReq, req) => {
            if (req.headers.accept === 'text/event-stream') {
              proxyReq.setHeader('Connection', 'Keep-Alive');
              proxyReq.setHeader('Cache-Control', 'no-cache');
            }
          });
        },
      },
      '/health': 'http://127.0.0.1:17321',
      '/openclaw-ui': {
        target: 'http://127.0.0.1:18789',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/openclaw-ui\/?/, '/') || '/'
      }
    }
  }
});

