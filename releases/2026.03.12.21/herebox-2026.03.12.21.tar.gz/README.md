# HereBox

HereBox 是一个基于 OpenClaw 的本地硬件盒子，提供开箱即用的初始化向导和管理面板：

- 开机自动创建 WiFi 热点和 captive portal
- 浏览器访问 `herebox.local` 即可进入初始化向导
- 向导自动检测系统环境、安装依赖、安装 OpenClaw、配置默认 AI 模型并启动服务
- 初始化完成后提供响应式管理面板，可管理网络、AI 模型、消息通道和安全设置

## 开发

```bash
pnpm install
pnpm dev        # 同时启动 API 和 Web
pnpm dev:api    # 仅启动 API（端口 17321）
pnpm dev:web    # 仅启动 Web（Vite 代理 /api 到 API）
```

默认账号：`admin` / `herebox`。未登录访问 `/wizard` 或 `/dashboard` 会跳转到登录页。

## 部署

在 Ubuntu Server（x86/ARM）上可一键安装并启用 WiFi 热点与 mDNS，详见 **[docs/deployment.md](docs/deployment.md)**。

```bash
sudo ./scripts/install.sh
sudo /opt/herebox/scripts/setup-ap.sh    # 可选：WiFi 热点
sudo /opt/herebox/scripts/setup-mdns.sh  # 可选：herebox.local
```

