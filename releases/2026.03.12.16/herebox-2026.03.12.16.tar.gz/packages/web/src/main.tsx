import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from 'sonner';
import './index.css';
import './i18n';
import { AppShell } from './components/layout/AppShell';
import { WizardLayout } from './components/layout/WizardLayout';
import { RequireAuth } from './components/auth/RequireAuth';
import { DefaultRedirect } from './components/DefaultRedirect';
import { LoginPage } from './pages/LoginPage';
import { WizardPage } from './pages/WizardPage';
import { DashboardPage } from './pages/DashboardPage';
import { OpenClawPage } from './pages/OpenClawPage';

function LayoutSwitch({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const isWizard = location.pathname.startsWith('/wizard');
  if (isWizard) return <WizardLayout>{children}</WizardLayout>;
  return <AppShell>{children}</AppShell>;
}

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <Toaster richColors position="top-center" closeButton />
    <BrowserRouter>
      <LayoutSwitch>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/wizard"
            element={
              <RequireAuth>
                <WizardPage />
              </RequireAuth>
            }
          />
          <Route
            path="/dashboard"
            element={
              <RequireAuth>
                <DashboardPage />
              </RequireAuth>
            }
          />
          <Route
            path="/openclaw"
            element={
              <RequireAuth>
                <OpenClawPage />
              </RequireAuth>
            }
          />
          <Route path="/" element={<DefaultRedirect />} />
          <Route path="*" element={<DefaultRedirect />} />
        </Routes>
      </LayoutSwitch>
    </BrowserRouter>
  </React.StrictMode>,
);

