import { ArrowLeft, Menu, X } from "lucide-react";
import { ReactNode, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useLocation, useNavigate } from "react-router-dom";

type Props = {
  children: ReactNode;
};

type Session = {
  authenticated: boolean;
  username?: string | null;
  wizardCompleted?: boolean;
};

export function AppShell({ children }: Props) {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/session", { credentials: "include" })
      .then((res) => res.json())
      .then((data: Session) => {
        if (!cancelled) setSession(data);
      })
      .catch(() => {
        if (!cancelled) setSession({ authenticated: false });
      });
    return () => {
      cancelled = true;
    };
  }, [location.pathname]);

  const currentLang = i18n.language.startsWith("zh") ? "zh-CN" : "en-US";

  const switchLang = () => {
    const next = currentLang === "zh-CN" ? "en-US" : "zh-CN";
    i18n.changeLanguage(next);
    localStorage.setItem("herebox-lang", next);
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    setSession({ authenticated: false });
    setOpen(false);
    navigate("/login", { replace: true });
  };

  const isActive = (path: string) =>
    location.pathname.startsWith(path)
      ? "text-cyan-300"
      : "text-slate-300 hover:text-cyan-200";

  const menuRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("click", close, true);
    return () => document.removeEventListener("click", close, true);
  }, [open]);

  const isOpenClaw = location.pathname.startsWith("/openclaw");

  const RETURN_TOP_KEY = "herebox-openclaw-return-top";
  const RETURN_RIGHT = 0; // 紧贴右侧
  const defaultReturnTop = 12;
  const [returnTop, setReturnTop] = useState(defaultReturnTop);
  const dragRef = useRef<{ startY: number; startTop: number } | null>(null);
  const didDragRef = useRef(false);
  const returnBtnRef = useRef<HTMLDivElement>(null);
  const lastTopRef = useRef(returnTop);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(RETURN_TOP_KEY);
      if (raw) {
        const n = Number(raw);
        if (Number.isFinite(n)) {
          const t = Math.max(0, n);
          setReturnTop(t);
          lastTopRef.current = t;
        }
      }
    } catch {
      /* ignore */
    }
  }, []);

  const saveReturnTop = (top: number) => {
    setReturnTop(top);
    try {
      localStorage.setItem(RETURN_TOP_KEY, String(top));
    } catch {
      /* ignore */
    }
  };

  const onReturnPointerDown = (e: React.PointerEvent) => {
    didDragRef.current = false;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    lastTopRef.current = returnTop;
    dragRef.current = { startY: e.clientY, startTop: returnTop };
  };
  const onReturnPointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const dy = e.clientY - dragRef.current.startY;
    if (Math.abs(dy) > 4) didDragRef.current = true;
    const top = Math.max(
      0,
      Math.min(window.innerHeight - 48, dragRef.current.startTop + dy),
    );
    lastTopRef.current = top;
    if (returnBtnRef.current) returnBtnRef.current.style.top = `${top}px`;
  };
  const onReturnPointerUp = (e: React.PointerEvent) => {
    if (dragRef.current) {
      const clamped = Math.max(
        0,
        Math.min(window.innerHeight - 48, lastTopRef.current),
      );
      saveReturnTop(clamped);
      if (!didDragRef.current) navigate("/dashboard");
    }
    e.currentTarget.releasePointerCapture(e.pointerId);
    dragRef.current = null;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      {!isOpenClaw && (
        <header className="border-b border-slate-800">
          <div className="mx-auto w-full max-w-7xl px-4 h-14 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img
                src="/logo.png"
                alt="HereBox"
                className="h-8 w-auto shrink-0 object-contain drop-shadow-[0_0_12px_rgba(56,189,248,0.45)]"
              />
              <div className="flex flex-col leading-tight min-w-0">
                <span className="font-semibold text-sm tracking-wide bg-gradient-to-r from-slate-50 via-cyan-200 to-sky-400 bg-clip-text text-transparent">
                  HereBox
                </span>
                <span className="text-[11px] text-slate-400/90 hidden xs:block">
                  {t("app.subtitle")}
                </span>
              </div>
            </div>
            <nav className="hidden md:flex items-center gap-4 text-sm">
              {session?.authenticated && (
                <>
                  {!session.wizardCompleted && (
                    <Link to="/wizard" className={isActive("/wizard")}>
                      {t("nav.wizard")}
                    </Link>
                  )}
                  <Link to="/dashboard" className={isActive("/dashboard")}>
                    {t("nav.dashboard")}
                  </Link>
                  <Link to="/openclaw" className={isActive("/openclaw")}>
                    {t("nav.openclaw")}
                  </Link>
                </>
              )}
            </nav>
            <div className="flex items-center gap-3">
              {session?.authenticated && (
                <>
                  <span className="hidden sm:inline text-xs text-slate-400">
                    {session.username}
                  </span>
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="hidden md:inline-flex items-center gap-1 rounded-full border border-slate-700 px-2.5 py-1 text-[11px] text-slate-200 hover:border-rose-500/50 hover:text-rose-200"
                  >
                    {t("nav.logout")}
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={switchLang}
                className="inline-flex items-center gap-1 rounded-full border border-slate-700 px-2.5 py-1 text-[11px] text-slate-200 hover:border-cyan-400/70 hover:text-cyan-100"
              >
                <span>{currentLang === "zh-CN" ? "中文" : "EN"}</span>
              </button>
              <div className="md:hidden relative" ref={menuRef}>
                <button
                  type="button"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700 text-slate-200 hover:bg-slate-800/60 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setOpen((v) => !v);
                  }}
                  aria-expanded={open}
                  aria-haspopup="true"
                >
                  <span className="sr-only">
                    {open ? "Close menu" : "Open menu"}
                  </span>
                  {open ? (
                    <X className="h-5 w-5" />
                  ) : (
                    <Menu className="h-5 w-5" />
                  )}
                </button>
                {open && session?.authenticated && (
                  <nav
                    className="absolute right-0 top-full z-50 mt-1.5 w-56 rounded-xl border border-slate-700 bg-slate-900 shadow-xl shadow-black/40 py-2"
                    role="menu"
                  >
                    {session.username && (
                      <div className="px-4 py-2 border-b border-slate-800">
                        <span className="text-xs text-slate-400">
                          {session.username}
                        </span>
                      </div>
                    )}
                    <div className="py-1">
                      {!session.wizardCompleted && (
                        <Link
                          to="/wizard"
                          role="menuitem"
                          className={`block px-4 py-2.5 text-sm ${isActive("/wizard")} hover:bg-slate-800/80`}
                          onClick={() => setOpen(false)}
                        >
                          {t("nav.wizard")}
                        </Link>
                      )}
                      <Link
                        to="/dashboard"
                        role="menuitem"
                        className={`block px-4 py-2.5 text-sm ${isActive("/dashboard")} hover:bg-slate-800/80`}
                        onClick={() => setOpen(false)}
                      >
                        {t("nav.dashboard")}
                      </Link>
                      <Link
                        to="/openclaw"
                        role="menuitem"
                        className={`block px-4 py-2.5 text-sm ${isActive("/openclaw")} hover:bg-slate-800/80`}
                        onClick={() => setOpen(false)}
                      >
                        {t("nav.openclaw")}
                      </Link>
                    </div>
                    <div className="border-t border-slate-800 pt-1">
                      <button
                        type="button"
                        role="menuitem"
                        className="block w-full px-4 py-2.5 text-left text-sm text-slate-300 hover:bg-slate-800/80 hover:text-rose-200"
                        onClick={() => {
                          setOpen(false);
                          handleLogout();
                        }}
                      >
                        {t("nav.logout")}
                      </button>
                    </div>
                  </nav>
                )}
              </div>
            </div>
          </div>
        </header>
      )}
      <main
        className={
          isOpenClaw
            ? "flex-1 flex flex-col min-h-0 relative"
            : "flex-1 flex flex-col min-h-0"
        }
      >
        {isOpenClaw ? (
          <>
            <div
              ref={returnBtnRef}
              role="group"
              aria-label={t("nav.backToHerebox")}
              className="group/btn fixed z-[9999] flex cursor-grab active:cursor-grabbing select-none touch-none w-max"
              style={{ top: returnTop, right: RETURN_RIGHT }}
              onPointerDown={onReturnPointerDown}
              onPointerMove={onReturnPointerMove}
              onPointerUp={onReturnPointerUp}
              onPointerCancel={onReturnPointerUp}
            >
              <Link
                to="/dashboard"
                className="flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-0 text-sm text-slate-200 transition-[padding,max-width,box-shadow] duration-200 group-hover/btn:pr-3 group-hover/btn:border group-hover/btn:border-slate-600 group-hover/btn:bg-slate-900/90 group-hover/btn:shadow-lg group-hover/btn:backdrop-blur hover:border-cyan-500/50 hover:bg-slate-800/90 hover:text-cyan-200"
                title={t("nav.backToHerebox")}
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-slate-800/95 shadow-[0_2px_12px_rgba(0,0,0,0.35)] group-hover/btn:shadow-none">
                  <img
                    src="/logo.png"
                    alt=""
                    className="h-5 w-5 object-contain"
                  />
                </span>
                <span className="flex items-center gap-2 overflow-hidden max-w-0 opacity-0 transition-all duration-200 group-hover/btn:max-w-[11rem] group-hover/btn:opacity-100">
                  <ArrowLeft className="h-4 w-4 shrink-0" />
                  <span className="whitespace-nowrap">
                    {t("nav.backToHerebox")}
                  </span>
                </span>
              </Link>
            </div>
            <div className="absolute inset-0 flex flex-col min-h-0">
              {children}
            </div>
          </>
        ) : (
          <div className="mx-auto w-full max-w-7xl px-4 py-6">{children}</div>
        )}
      </main>
    </div>
  );
}
