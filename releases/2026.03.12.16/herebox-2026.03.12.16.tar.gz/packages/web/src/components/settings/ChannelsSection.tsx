import { useState } from "react";
import { toast } from "sonner";

type ChannelsStatus = {
  telegram: { hasToken: boolean };
  discord: { hasToken: boolean };
  feishu: { configured: boolean };
};

type ChannelTab = "telegram" | "discord" | "feishu";

type Mode = "dashboard" | "wizard";

type Props = {
  status: ChannelsStatus | null;
  onSaved: () => void;
  t: (key: string) => string;
  mode?: Mode;
  /** 在向导模式下保存成功后，通知父组件推进步骤 */
  onWizardDone?: () => void;
  /** 向导模式下与保存按钮同一行的跳过回调 */
  onSkip?: () => void;
};

export function ChannelsSection({
  status,
  onSaved,
  t,
  mode = "dashboard",
  onWizardDone,
  onSkip,
}: Props) {
  const [tab, setTab] = useState<ChannelTab>("telegram");
  const [telegramToken, setTelegramToken] = useState("");
  const [discordToken, setDiscordToken] = useState("");
  const [feishuAppId, setFeishuAppId] = useState("");
  const [feishuAppSecret, setFeishuAppSecret] = useState("");
  const [loading, setLoading] = useState(false);

  const saveChannel = async (body: Record<string, unknown>) => {
    setLoading(true);
    try {
      const res = await fetch("/api/openclaw/channels", {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        toast.error(t("login.errorGeneric"));
        return;
      }
      toast.success(t("dashboard.channels.saved"));
      setTelegramToken("");
      setDiscordToken("");
      setFeishuAppId("");
      setFeishuAppSecret("");
      onSaved();
      if (mode === "wizard" && onWizardDone) {
        onWizardDone();
      }
    } catch {
      toast.error(t("login.errorGeneric"));
    } finally {
      setLoading(false);
    }
  };

  const onTelegramSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveChannel({ telegram: { token: telegramToken } });
  };
  const onDiscordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveChannel({ discord: { token: discordToken } });
  };
  const onFeishuSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveChannel({
      feishu: { appId: feishuAppId, appSecret: feishuAppSecret },
    });
  };

  const tabs: { id: ChannelTab; label: string; configured: boolean }[] = [
    { id: "telegram", label: t("dashboard.channels.telegram"), configured: Boolean(status?.telegram?.hasToken) },
    { id: "discord", label: t("dashboard.channels.discord"), configured: Boolean(status?.discord?.hasToken) },
    { id: "feishu", label: t("dashboard.channels.feishu"), configured: Boolean(status?.feishu?.configured) },
  ];

  return (
    <div className="space-y-4">
      <div className="flex gap-1 rounded-lg bg-slate-800/80 p-1">
        {tabs.map(({ id, label, configured }) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors flex items-center justify-center gap-1.5 ${
              tab === id
                ? "bg-cyan-500/20 text-cyan-300"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {label}
            {configured && (
              <span className="rounded-full bg-emerald-500/20 px-1.5 py-0.5 text-[10px] text-emerald-300">
                {t("dashboard.channels.configured")}
              </span>
            )}
          </button>
        ))}
      </div>

      {tab === "telegram" && (
        <form onSubmit={onTelegramSubmit} className="space-y-3">
          <div className="flex flex-wrap items-start gap-4">
            <div className="flex flex-col items-center gap-1">
              <img
                src="/ercode_botfather.png"
                alt="BotFather"
                className="h-28 w-28 rounded-lg border border-slate-700 bg-white object-contain"
              />
              <span className="text-[11px] text-slate-500">
                {t("dashboard.channels.scanBotFather")}
              </span>
            </div>
            <div className="flex-1 min-w-[200px]">
              <div className="text-slate-400 text-[11px] space-y-1">
                <p>
                  1. {t("dashboard.channels.telegramHint1Before")}
                  <a
                    href="https://t.me/BotFather"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:underline"
                  >
                    @BotFather
                  </a>
                </p>
                <p>2. {t("dashboard.channels.telegramHint2")}</p>
                <p>3. {t("dashboard.channels.telegramHint3")}</p>
              </div>
            </div>
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t("dashboard.channels.token")}
            </label>
            <input
              type="password"
              value={telegramToken}
              onChange={(e) => setTelegramToken(e.target.value)}
              placeholder={status?.telegram.hasToken ? "••••••••" : ""}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm placeholder:text-slate-500"
            />
          </div>
          <div className={mode === "wizard" && onSkip ? "flex flex-wrap items-center gap-3" : ""}>
            <button
              type="submit"
              disabled={loading}
              className="rounded-md bg-cyan-500 px-3 py-1.5 text-sm text-slate-950 hover:bg-cyan-400 disabled:opacity-60"
            >
              {t("dashboard.channels.save")}
            </button>
            {mode === "wizard" && onSkip && (
              <button
                type="button"
                onClick={onSkip}
                className="text-xs text-slate-500 hover:text-cyan-300 underline-offset-2 hover:underline"
              >
                {t("wizard.skip")}
              </button>
            )}
          </div>
        </form>
      )}

      {tab === "discord" && (
        <form onSubmit={onDiscordSubmit} className="space-y-3">
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t("dashboard.channels.token")}
            </label>
            <input
              type="password"
              value={discordToken}
              onChange={(e) => setDiscordToken(e.target.value)}
              placeholder={status?.discord.hasToken ? "••••••••" : ""}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm placeholder:text-slate-500"
            />
          </div>
          <div className={mode === "wizard" && onSkip ? "flex flex-wrap items-center gap-3" : ""}>
            <button
              type="submit"
              disabled={loading}
              className="rounded-md bg-cyan-500 px-3 py-1.5 text-sm text-slate-950 hover:bg-cyan-400 disabled:opacity-60"
            >
              {t("dashboard.channels.save")}
            </button>
            {mode === "wizard" && onSkip && (
              <button
                type="button"
                onClick={onSkip}
                className="text-xs text-slate-500 hover:text-cyan-300 underline-offset-2 hover:underline"
              >
                {t("wizard.skip")}
              </button>
            )}
          </div>
        </form>
      )}

      {tab === "feishu" && (
        <form onSubmit={onFeishuSubmit} className="space-y-3">
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t("dashboard.channels.appId")}
            </label>
            <input
              type="text"
              value={feishuAppId}
              onChange={(e) => setFeishuAppId(e.target.value)}
              placeholder={status?.feishu.configured ? "••••••" : ""}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm placeholder:text-slate-500"
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t("dashboard.channels.appSecret")}
            </label>
            <input
              type="password"
              value={feishuAppSecret}
              onChange={(e) => setFeishuAppSecret(e.target.value)}
              placeholder={status?.feishu.configured ? "••••••••" : ""}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-sm placeholder:text-slate-500"
            />
          </div>
          <div className={mode === "wizard" && onSkip ? "flex flex-wrap items-center gap-3" : ""}>
            <button
              type="submit"
              disabled={loading}
              className="rounded-md bg-cyan-500 px-3 py-1.5 text-sm text-slate-950 hover:bg-cyan-400 disabled:opacity-60"
            >
              {t("dashboard.channels.save")}
            </button>
            {mode === "wizard" && onSkip && (
              <button
                type="button"
                onClick={onSkip}
                className="text-xs text-slate-500 hover:text-cyan-300 underline-offset-2 hover:underline"
              >
                {t("wizard.skip")}
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
}

