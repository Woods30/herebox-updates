import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';

type Session = { authenticated: boolean; wizardCompleted?: boolean };

export function DefaultRedirect() {
  const [target, setTarget] = useState<'/login' | '/wizard' | '/dashboard' | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/auth/session', { credentials: 'include' })
      .then((res) => res.json())
      .then((data: Session) => {
        if (cancelled) return;
        if (!data.authenticated) {
          // 未登录：一律进入登录页，由用户先登录再进入向导
          setTarget('/login');
        } else {
          // 已登录：向导未完成则先进入向导，否则进入 dashboard
          setTarget(data.wizardCompleted ? '/dashboard' : '/wizard');
        }
      })
      .catch(() => {
        if (!cancelled) setTarget('/login');
      });
    return () => { cancelled = true; };
  }, []);

  if (target === null) return null;
  return <Navigate to={target} replace />;
}
