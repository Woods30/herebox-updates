import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

type WifiNetwork = {
  ssid: string;
  signal: number;
  security: string;
  freq: string;
};

type Props = {
  /** WiFi 成功连接后回调，由上层触发后端步骤并推进 */
  onAfterSuccessOrSkip?: () => void;
  /** 用户点击跳过时回调，由上层调用 skip API 并推进 */
  onSkip?: () => void;
};

export function ConfigureWifiStep({ onAfterSuccessOrSkip, onSkip }: Props) {
  const { t } = useTranslation();
  const [networks, setNetworks] = useState<WifiNetwork[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [ssid, setSsid] = useState('');
  const [password, setPassword] = useState('');
  const [actionMessage, setActionMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [connectedName, setConnectedName] = useState<string | null>(null);

  const fetchScan = async (quick = false) => {
    setLoading(true);
    setError('');
    try {
      const url = quick ? '/api/wifi/scan?quick=1' : '/api/wifi/scan';
      const res = await fetch(url, { credentials: 'include' });
      const data = await res.json();
      if (!res.ok) {
        setError(
          data?.error ??
            t('wizard.wifi.scanFailed')
        );
        setNetworks([]);
        return;
      }
      setNetworks(Array.isArray(data.networks) ? data.networks : []);
    } catch {
      setError(t('wizard.wifi.scanFailed'));
      setNetworks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScan(true).catch(() => {}); // 首次快速列出（不 rescan），结果秒出
    fetch('/api/wifi/status', { credentials: 'include' })
      .then((res) => res.ok ? res.json() : null)
      .then((data: Record<string, string> | null) => {
        if (!data) return;
        const connected = data['GENERAL.CONNECTION'] || '';
        if (connected) {
          setConnectedName(connected);
          if (!ssid) setSsid(connected);
        }
      })
      .catch(() => {});
  }, []);

  const handleConnect = async (skip: boolean) => {
    setSubmitting(true);
    setActionMessage('');
    setError('');
    try {
      const body = skip ? { skip: true } : { ssid: ssid.trim(), password };
      if (!skip && !body.ssid) {
        setError(t('wizard.wifi.missingSsid', '请输入 Wi‑Fi 名称'));
        setSubmitting(false);
        return;
      }
      const res = await fetch('/api/wifi/connect', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data?.error) {
        setError(
          data?.error ??
            t('wizard.wifi.connectFailed')
        );
        return;
      }
      setActionMessage(
        data?.message ??
          (skip
            ? t('wizard.wifi.skipped')
            : t('wizard.wifi.connected'))
      );
      if (skip) {
        onSkip?.();
      } else {
        onAfterSuccessOrSkip?.();
      }
    } catch {
      setError(
        t('wizard.wifi.connectFailed')
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-3">
      {connectedName && (
          <p className="text-[11px] text-emerald-400">
            {t('wizard.wifi.currentConnected', '当前已连接：')}
            <span className="ml-1 font-mono text-emerald-200">{connectedName}</span>
          </p>
        )}

        <div className="mt-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">
              {t('wizard.wifi.available', '可用网络')}
            </span>
            <button
              type="button"
              onClick={() => fetchScan(false)}
              disabled={loading}
              className="text-xs text-cyan-300 hover:text-cyan-100 disabled:opacity-60"
            >
              {loading
                ? t('wizard.wifi.scanning', '正在扫描…')
                : t('wizard.wifi.rescan', '重新扫描')}
            </button>
          </div>
          <div className="max-h-40 overflow-y-auto rounded-md border border-slate-800 bg-slate-950/60">
            {networks.length === 0 ? (
              <div className="px-3 py-2 text-[11px] text-slate-500">
                {t('wizard.wifi.noNetworks', '未发现附近 Wi‑Fi，可手动输入网络名称。')}
              </div>
            ) : (
              <ul className="text-xs divide-y divide-slate-800">
                {networks.map((n) => {
                  const isConnected = connectedName && n.ssid === connectedName;
                  return (
                    <li
                      key={`${n.ssid}-${n.freq}`}
                      className="px-3 py-2 flex items-center justify-between hover:bg-slate-900/80 cursor-pointer"
                      onClick={() => setSsid(n.ssid)}
                    >
                      <div className="min-w-0">
                        <div className="truncate text-slate-100">
                          {n.ssid}
                          {isConnected && (
                            <span className="ml-2 inline-flex items-center rounded-full bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">
                              {t('wizard.wifi.connected', '已连接')}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {n.security || 'OPEN'} · {n.freq}
                        </div>
                      </div>
                      <div className="text-[10px] text-slate-400 ml-2 shrink-0">
                        {n.signal}%
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>

        <div className="mt-4 space-y-2">
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t('wizard.wifi.ssid', 'Wi‑Fi 名称 (SSID)')}
            </label>
            <input
              type="text"
              value={ssid}
              onChange={(e) => setSsid(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500"
              placeholder={t('wizard.wifi.ssidPlaceholder', '例如：MyHome Wi‑Fi') as string}
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              {t('wizard.wifi.password', '密码（如有）')}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100"
            />
          </div>
        </div>

        {error && (
          <p className="text-[11px] text-rose-400 mt-2" role="alert">
            {error}
          </p>
        )}
        {actionMessage && (
          <p className="text-[11px] text-emerald-400 mt-2">
            {actionMessage}
          </p>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => handleConnect(false)}
            disabled={submitting}
            className="rounded-md bg-cyan-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-cyan-500 disabled:opacity-60"
          >
            {t('wizard.wifi.connect', '连接 Wi‑Fi')}
          </button>
          {onSkip && (
            <button
              type="button"
              onClick={() => handleConnect(true)}
              disabled={submitting}
              className="text-xs text-slate-500 hover:text-cyan-300 underline-offset-2 hover:underline disabled:opacity-60"
            >
              {t('wizard.wifi.skip', '跳过（仅使用有线）')}
            </button>
          )}
        </div>
    </div>
  );
}

