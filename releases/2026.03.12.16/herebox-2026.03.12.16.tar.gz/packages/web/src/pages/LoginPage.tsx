import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export function LoginPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/session", { credentials: "include" })
      .then((res) => res.json())
      .then((data: { authenticated?: boolean; wizardCompleted?: boolean }) => {
        if (!cancelled && data.authenticated)
          navigate(data.wizardCompleted ? "/dashboard" : "/wizard", {
            replace: true,
          });
      })
      .finally(() => {
        if (!cancelled) setChecking(false);
      });
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg =
          (data as { error?: string }).error === "invalid_credentials"
            ? t("login.errorCredentials")
            : t("login.errorGeneric");
        setError(msg);
        toast.error(msg);
        setLoading(false);
        return;
      }
      toast.success(t("login.submit"));
      const sessionRes = await fetch("/api/auth/session", {
        credentials: "include",
      });
      const sessionData = (await sessionRes.json()) as {
        wizardCompleted?: boolean;
      };
      navigate(sessionData.wizardCompleted ? "/dashboard" : "/wizard", {
        replace: true,
      });
    } catch {
      const msg = t("login.errorGeneric");
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="flex min-h-[calc(100vh-3.5rem)] items-center justify-center py-8">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-3.5rem)] flex items-start justify-center px-4 pt-12 pb-8 sm:items-center sm:pt-0 sm:pb-0">
      <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-2xl shadow-black/60 backdrop-blur">
        {/* Logo 与欢迎语：放在登录框内 */}
        <div className="flex flex-col items-center text-center mb-5">
          <img
            src="/logo.png"
            alt="HereBox"
            className="h-16 w-auto object-contain mb-3 drop-shadow-[0_0_12px_rgba(56,189,248,0.45)]"
          />
          <h1 className="text-lg font-bold text-slate-50 mb-0.5">
            {t("login.welcome")
              .split(/(HereBox)/)
              .map((part, i) =>
                part === "HereBox" ? (
                  <span
                    key={i}
                    className="bg-gradient-to-r from-slate-50 via-cyan-200 to-sky-400 bg-clip-text text-transparent"
                  >
                    HereBox
                  </span>
                ) : (
                  <span key={i}>{part}</span>
                ),
              )}
          </h1>
          <p className="text-xs text-slate-400/90">
            {t("login.welcomeSubtitle")}
          </p>
        </div>
        <form className="space-y-4" onSubmit={handleSubmit}>
          {error && (
            <p className="text-xs text-rose-400 rounded-md bg-rose-500/10 px-2 py-1.5">
              {error}
            </p>
          )}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300">
              {t("login.username")}
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm outline-none ring-0 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-500/60"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300">
              {t("login.password")}
            </label>
            <input
              type="password"
              className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm outline-none ring-0 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-500/60"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="mt-2 inline-flex w-full items-center justify-center rounded-md bg-cyan-500 px-3 py-2 text-sm font-medium text-slate-950 hover:bg-cyan-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500/80 disabled:opacity-60"
          >
            {loading ? t("login.submitting") : t("login.submit")}
          </button>
        </form>
      </div>
    </div>
  );
}
