import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Circle, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { ConfigureWifiStep } from '../components/setup/ConfigureWifiStep';
import { ConfigureAiStep } from '../components/setup/ConfigureAiStep';
import { ConfigureChannelStep } from '../components/setup/ConfigureChannelStep';
import { CompleteStep } from '../components/setup/CompleteStep';

type StepStatus = 'pending' | 'running' | 'success' | 'error' | 'skipped';

type WizardStep = {
  id: string;
  nameKey: string;
  status: StepStatus;
  lastMessage?: string;
};

type WizardStatus = {
  steps: WizardStep[];
  running: boolean;
  done: boolean;
  completed?: boolean;
};

const DEFAULT_STEPS: { id: string; nameKey: string }[] = [
  { id: 'configure-wifi', nameKey: 'wizard.steps.configureWifi' },
  { id: 'configure-ai', nameKey: 'wizard.steps.configureAi' },
  { id: 'configure-channel', nameKey: 'wizard.steps.configureChannel' },
  { id: 'complete', nameKey: 'wizard.steps.complete' },
];

export type WizardPhase = 'intro' | 'updating' | 'complete';

export function WizardPage() {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<WizardPhase>('intro');
  const [status, setStatus] = useState<WizardStatus | null>(null);
  const sseOpenedRef = useRef(false);

  // 每次进入配置向导页都从第一步（欢迎页）开始
  useEffect(() => {
    if (location.pathname === '/wizard') {
      setPhase('intro');
      sseOpenedRef.current = false;
    }
  }, [location.pathname]);

  // 路由守卫：已完成则重定向到 dashboard
  useEffect(() => {
    let cancelled = false;
    fetch('/api/wizard/status', { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: WizardStatus | null) => {
        if (cancelled || !data) return;
        setStatus(data);
        if (data.completed === true) {
          navigate('/dashboard', { replace: true });
        }
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [navigate]);

  // 仅当 phase 为 updating 时连接 SSE；用 ref 避免因 setState 导致 effect 重跑并执行 cleanup 关闭连接
  useEffect(() => {
    if (phase !== 'updating') return;
    if (sseOpenedRef.current) return;
    sseOpenedRef.current = true;
    const ev = new EventSource('/api/wizard/stream');
    ev.addEventListener('wizard-status', (e) => {
      try {
        const data = JSON.parse((e as MessageEvent).data) as WizardStatus;
        setStatus(data);
        if (data.done) setPhase('complete');
        if (data.completed === true) {
          navigate('/dashboard', { replace: true });
        }
      } catch {
        // ignore
      }
    });
    return () => {
      ev.close();
      sseOpenedRef.current = false;
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== 'updating' || !status?.steps?.length) return;
    const businessSteps = status.steps.filter((s) => s.id !== 'complete');
    const done =
      status.done === true ||
      (businessSteps.length > 0 &&
        businessSteps.every(
          (s) => s.status === 'success' || s.status === 'skipped',
        ));
    if (done) setPhase('complete');
  }, [phase, status]);

  // 完成阶段：通知后端标记向导完成，然后跳转到 dashboard
  useEffect(() => {
    if (phase !== 'complete') return;
    let cancelled = false;
    (async () => {
      try {
        await fetch('/api/wizard/complete', {
          method: 'POST',
          credentials: 'include',
        });
      } catch {
        // ignore errors, 由后端幂等处理
      }
      if (!cancelled) {
        navigate('/dashboard', { replace: true });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [phase, navigate]);

  const handleStart = useCallback(async () => {
    try {
      await fetch('/api/wizard/reset-steps', {
        method: 'POST',
        credentials: 'include',
      });
    } catch {
      // ignore
    }
    setStatus(null);
    setPhase('updating');
  }, []);

  const steps = useMemo(() => {
    if (status?.steps?.length) return status.steps;
    return DEFAULT_STEPS.map((s) => ({ ...s, status: 'pending' as StepStatus }));
  }, [status]);

  // 顶部仅展示前四个业务步骤，不展示内部的 complete 步骤
  const headerSteps = useMemo(
    () => steps.filter((s) => s.id !== 'complete'),
    [steps],
  );

  const currentStepId = useMemo(() => {
    if (!steps.length) return null;
    const running = steps.find((s) => s.status === 'running');
    if (running) return running.id;
    const error = steps.find((s) => s.status === 'error');
    if (error) return error.id;
    const lastDoneIndex = [...steps]
      .map((s, idx) => ({ s, idx }))
      .reverse()
      .find(({ s }) => s.status === 'success' || s.status === 'skipped')?.idx;
    if (lastDoneIndex != null) {
      const nextIndex = lastDoneIndex + 1;
      if (nextIndex < steps.length) {
        return steps[nextIndex].id;
      }
      return steps[lastDoneIndex].id;
    }
    return steps[0].id;
  }, [steps]);

  const runStep = useCallback(async (id: string) => {
    await fetch(`/api/wizard/step/${encodeURIComponent(id)}`, {
      method: 'POST',
      credentials: 'include',
    });
  }, []);

  const skipStep = useCallback(async (id: string) => {
    await fetch(`/api/wizard/step/${encodeURIComponent(id)}/skip`, {
      method: 'POST',
      credentials: 'include',
    });
  }, []);

  const getStatusIcon = (s: StepStatus) => {
    const className = 'w-4 h-4 shrink-0';
    switch (s) {
      case 'pending':
        return <Circle className={`${className} text-slate-400`} strokeWidth={2} />;
      case 'running':
        return <Loader2 className={`${className} text-cyan-300 animate-spin`} strokeWidth={2} />;
      case 'success':
        return <CheckCircle className={`${className} text-emerald-400`} strokeWidth={2} />;
      case 'error':
        return <XCircle className={`${className} text-rose-400`} strokeWidth={2} />;
      case 'skipped':
        return <Circle className={`${className} text-amber-400/90`} strokeWidth={1.5} />;
      default:
        return <Circle className={`${className} text-slate-400`} strokeWidth={2} />;
    }
  };

  const getStatusLabel = (s: StepStatus) => {
    if (s === 'success') return t('common.done');
    if (s === 'skipped') return t('wizard.skipped');
    if (s === 'error') return t('common.error');
    if (s === 'running') return t('common.running');
    return t('common.pending');
  };

  const getStatusColor = (s: StepStatus) => {
    switch (s) {
      case 'pending': return 'text-slate-400';
      case 'running': return 'text-cyan-300';
      case 'success': return 'text-emerald-400';
      case 'error': return 'text-rose-400';
      case 'skipped': return 'text-amber-400';
      default: return 'text-slate-400';
    }
  };

  // ----- Render by phase -----

  if (phase === 'intro') {
    return (
      <div className="flex flex-col gap-4">
        <div className="text-center mb-2">
          <h1 className="text-xl font-bold text-slate-50 mb-1">
            <span className="bg-gradient-to-r from-slate-50 via-cyan-200 to-sky-400 bg-clip-text text-transparent">
              {t('wizard.welcome')}
            </span>
          </h1>
          <p className="text-sm text-slate-400">{t('wizard.welcomeSubtitle')}</p>
        </div>
        <div className="w-full rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl shadow-black/50 backdrop-blur flex flex-col">
          <h2 className="text-base font-semibold mb-2 text-center text-slate-200">{t('wizard.title')}</h2>
          <p className="text-sm text-slate-400 mb-6 text-center">{t('wizard.subtitle')}</p>
          <div className="mt-auto flex justify-center pt-4 border-t border-slate-700/80">
            <button
              type="button"
              onClick={handleStart}
              className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-500"
            >
              {t('wizard.start')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // updating | complete
  const isComplete = phase === 'complete';
  return (
    <div className="flex flex-col gap-4">
      <div className="w-full rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl shadow-black/50 backdrop-blur flex flex-col">
        {/* 完成状态下不再在顶部重复展示文案，仅保留下方 CompleteStep 卡片 */}
        <div className="mb-4 -mx-2">
          <ul className="flex flex-row gap-3 px-2 overflow-x-auto no-scrollbar text-xs md:text-sm">
            {headerSteps.map((step, index) => {
              const isActive = step.id === currentStepId;
              const colorClass =
                step.status === 'success'
                  ? 'bg-emerald-500/90 border-emerald-400 text-slate-950 ring-2 ring-emerald-300/80'
                  : step.status === 'skipped'
                    ? 'bg-amber-500/20 border-amber-400/60 text-amber-200'
                    : step.status === 'error'
                      ? 'bg-rose-500/90 border-rose-400 text-slate-950 ring-2 ring-rose-300/80'
                      : step.status === 'running'
                        ? 'bg-cyan-500/90 border-cyan-400 text-slate-950 ring-2 ring-cyan-300/80'
                        : 'bg-slate-700/80 border-slate-500 text-slate-100';
              return (
                <li
                  key={step.id}
                  className="flex items-center justify-center flex-none px-1 py-1"
                >
                  <span
                    className={`flex items-center justify-center w-7 h-7 rounded-full border text-[11px] ${colorClass}`}
                  >
                    {index + 1}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
        {currentStepId && (
          <>
            <h1 className="text-lg font-semibold mb-1 text-center">
              {t(
                steps.find((s) => s.id === currentStepId)?.nameKey ?? 'wizard.updatingTitle'
              )}
            </h1>
            <p className="text-xs text-slate-400 mb-4 text-center">
              {t(
                `wizard.stepDescriptions.${currentStepId ?? 'default'}`,
              )}
            </p>
          </>
        )}
        <div className="mt-4 border border-slate-800 rounded-xl bg-slate-950/60 px-4 py-3 min-h-[220px]">
          {currentStepId === 'configure-wifi' && (
            <ConfigureWifiStep
              onAfterSuccessOrSkip={() => runStep('configure-wifi')}
              onSkip={() => skipStep('configure-wifi')}
            />
          )}
          {currentStepId === 'configure-ai' && (
            <ConfigureAiStep
              onConfigured={() => runStep('configure-ai')}
              onSkip={() => skipStep('configure-ai')}
            />
          )}
          {currentStepId === 'configure-channel' && (
            <ConfigureChannelStep
              onRunStep={() => runStep('configure-channel')}
              onSkip={() => skipStep('configure-channel')}
            />
          )}
          {currentStepId === 'complete' && (
            <CompleteStep
            />
          )}
        </div>
        {/* 完成后将自动跳转到 Dashboard，这里不再提供继续按钮 */}
      </div>
    </div>
  );
}
