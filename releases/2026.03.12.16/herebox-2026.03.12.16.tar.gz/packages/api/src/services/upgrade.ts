import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";
import { logger } from "../lib/logger.js";

// 升级工件目录：固定在 /opt 下，但在 install 时确保由 herebox 用户拥有。
const UPDATES_DIR = "/opt/herebox-updates";
const RELEASES_DIR = "/opt/herebox-releases";
const INSTALL_DIR_DEFAULT = "/opt/herebox";

type Manifest = { version: string; url: string; sha256: string };

export type VersionInfo = {
  currentVersion: string | null;
  latestVersion: string | null;
  hasUpdate: boolean;
};

export type UpgradeStatusState = "idle" | "running" | "success" | "error";

export type UpgradeStatus = {
  running: boolean;
  status: UpgradeStatusState;
  lastMessage?: string;
  steps?: {
    id: string;
    status: "pending" | "running" | "success" | "error";
    lastMessage?: string;
  }[];
};

export type UpgradeBroadcastEvent =
  | { type: "upgrade-status"; payload: UpgradeStatus }
  | { type: "upgrade-log"; payload: { message: string } };

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(__dirname, "../../../../");
const INSTALL_SCRIPT = path.resolve(REPO_ROOT, "scripts/install.sh");
const VERSION_FILE = path.join(REPO_ROOT, "VERSION");
const PACKAGE_JSON_PATH = path.join(REPO_ROOT, "package.json");
const MANIFEST_URL = process.env.HEREBOX_UPDATE_MANIFEST_URL ?? "";

const listeners = new Set<(event: UpgradeBroadcastEvent) => void>();

const state: {
  running: boolean;
  status: UpgradeStatusState;
  lastMessage?: string;
  steps: Record<
    string,
    { id: string; status: "pending" | "running" | "success" | "error"; lastMessage?: string }
  >;
  logs: string[];
} = {
  running: false,
  status: "idle",
  steps: {},
  logs: [],
};

function emit(event: UpgradeBroadcastEvent) {
  for (const listener of listeners) {
    try {
      listener(event);
    } catch {
      // ignore
    }
  }
}

function setStep(
  id: string,
  status: "pending" | "running" | "success" | "error",
  lastMessage?: string,
) {
  const existing = state.steps[id];
  state.steps[id] = {
    id,
    status,
    lastMessage: lastMessage ?? existing?.lastMessage,
  };
  if (lastMessage) state.lastMessage = lastMessage;
  emit({ type: "upgrade-status", payload: getUpgradeStatus() });
}

function appendLog(line: string) {
  state.logs.push(line);
  state.lastMessage = line;
  emit({ type: "upgrade-log", payload: { message: line } });
  emit({ type: "upgrade-status", payload: getUpgradeStatus() });
}

function getCurrentVersion(): string | null {
  try {
    if (fs.existsSync(VERSION_FILE)) {
      const s = fs.readFileSync(VERSION_FILE, "utf8").trim();
      if (s) return s;
    }
  } catch {
    // ignore
  }
  try {
    if (fs.existsSync(PACKAGE_JSON_PATH)) {
      const raw = fs.readFileSync(PACKAGE_JSON_PATH, "utf8");
      const data = JSON.parse(raw) as { version?: string };
      if (typeof data?.version === "string") return data.version.trim();
    }
  } catch {
    // ignore
  }
  return null;
}

async function fetchLatestFromManifest(): Promise<string | null> {
  if (!MANIFEST_URL) return null;
  try {
    const res = await fetch(MANIFEST_URL, {
      // 短超时，避免 Dashboard 卡死
      signal: AbortSignal.timeout(8000),
      headers: {
        "User-Agent": "HereBox-Upgrade/1.0",
      },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { version?: string };
    if (typeof data?.version === "string") return data.version.trim();
  } catch (e) {
    logger.warn("fetch latest version from manifest failed", { url: MANIFEST_URL, err: e });
  }
  return null;
}

export async function getVersionInfo(): Promise<VersionInfo> {
  const currentVersion = getCurrentVersion();
  const latestVersion = await fetchLatestFromManifest();

  const parseVersion = (v: string): number[] =>
    v.split(".").map((p) => Number.parseInt(p, 10) || 0);

  const isNewer = (a: string, b: string): boolean => {
    const pa = parseVersion(a);
    const pb = parseVersion(b);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const va = pa[i] ?? 0;
      const vb = pb[i] ?? 0;
      if (va > vb) return true;
      if (va < vb) return false;
    }
    return false;
  };

  const hasUpdate =
    latestVersion != null &&
    (currentVersion === null || isNewer(latestVersion, currentVersion));
  return { currentVersion, latestVersion, hasUpdate };
}

export function getUpgradeStatus(): UpgradeStatus {
  return {
    running: state.running,
    status: state.status,
    lastMessage: state.lastMessage,
    steps: Object.values(state.steps),
  };
}

export function subscribeUpgrade(
  listener: (event: UpgradeBroadcastEvent) => void,
): () => void {
  listeners.add(listener);
  listener({
    type: "upgrade-status",
    payload: getUpgradeStatus(),
  });
  for (const line of state.logs) {
    listener({ type: "upgrade-log", payload: { message: line } });
  }
  return () => listeners.delete(listener);
}

async function fetchManifestFromUrl(url: string): Promise<Manifest> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(15000),
    headers: {
      "User-Agent": "HereBox-Upgrade/1.0",
    },
  });
  if (!res.ok) throw new Error(`manifest fetch ${res.status}`);
  const data = (await res.json()) as unknown;
  if (
    !data ||
    typeof (data as Manifest).version !== "string" ||
    typeof (data as Manifest).url !== "string" ||
    typeof (data as Manifest).sha256 !== "string"
  )
    throw new Error("invalid manifest");
  return data as Manifest;
}

async function downloadAndVerify(
  manifest: Manifest,
  tarballPath: string,
): Promise<void> {
  const res = await fetch(manifest.url, { signal: AbortSignal.timeout(300000) });
  if (!res.body) throw new Error("no response body");
  if (!res.ok) throw new Error(`download ${res.status}`);
  const hash = createHash("sha256");
  const out = fs.createWriteStream(tarballPath, { flags: "w" });
  const reader = res.body.getReader();
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      hash.update(value);
      out.write(Buffer.from(value));
    }
  } finally {
    out.end();
    await new Promise<void>((resolve, reject) =>
      out.once("finish", resolve).once("error", reject),
    );
  }
  const digest = hash.digest("hex").toLowerCase();
  const expected = manifest.sha256.toLowerCase().trim();
  if (digest !== expected)
    throw new Error(`sha256 mismatch: got ${digest}, expected ${expected}`);
}

function extractTarball(tarballPath: string, extractDir: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn("tar", ["-xzf", tarballPath, "-C", extractDir], {
      stdio: ["ignore", "pipe", "pipe"],
    });
    const err: string[] = [];
    if (proc.stderr) proc.stderr.setEncoding("utf8").on("data", (c) => err.push(c));
    proc.on("exit", (code) => {
      if (code !== 0) reject(new Error(`tar exit ${code}: ${err.join("")}`));
      else resolve();
    });
  });
}

function runInstallScript(installDir: string, cwd: string): Promise<void> {
  const script = path.join(cwd, "scripts", "install.sh");
  if (!fs.existsSync(script))
    return Promise.reject(new Error(`install.sh not found in ${cwd}`));

  const isRoot = typeof process.getuid === "function" && process.getuid() === 0;
  const cmd = isRoot ? "/bin/bash" : "sudo";
  const args = isRoot ? [script] : ["-n", "/bin/bash", script];
  const env = isRoot ? { ...process.env, HEREBOX_INSTALL_DIR: installDir } : process.env;

  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, {
      env,
      cwd,
    });

    const appendLine = (line: string) => {
      const stepMatch = line.match(/^##STEP:install:(\S+):(start|success|error)(?::(.*))?$/);
      if (stepMatch) {
        const [, stepId, action, msg] = stepMatch;
        const existing = state.steps[stepId] ?? { id: stepId, status: "pending" as const };
        let nextStatus = existing.status;
        if (action === "start") nextStatus = "running";
        if (action === "success") nextStatus = "success";
        if (action === "error") nextStatus = "error";
        state.steps[stepId] = {
          id: stepId,
          status: nextStatus,
          lastMessage: msg ?? existing.lastMessage,
        };
        if (msg) state.lastMessage = msg;
        emit({ type: "upgrade-status", payload: getUpgradeStatus() });
        return;
      }
      appendLog(line);
    };

    if (proc.stdout) {
      const rl = readline.createInterface({ input: proc.stdout });
      rl.on("line", (line: string) => appendLine(line));
    }
    if (proc.stderr) {
      const rlErr = readline.createInterface({ input: proc.stderr });
      rlErr.on("line", (line: string) => appendLine(line));
    }

    proc.on("exit", (code) => {
      state.running = false;
      if (code !== 0) {
        state.status = "error";
        state.lastMessage = `Process exited with code ${code ?? 1}`;
        logger.warn("upgrade exited with error", { code: code ?? 1 });
        emit({ type: "upgrade-status", payload: getUpgradeStatus() });
        reject(new Error(`upgrade_failed:${code ?? 1}`));
      } else {
        state.status = "success";
        logger.info("upgrade completed");
        emit({ type: "upgrade-status", payload: getUpgradeStatus() });
        resolve();
      }
    });
  });
}

export type RunUpgradeOptions = { targetVersion?: string };

export function runUpgrade(options?: RunUpgradeOptions): Promise<void> {
  if (state.running) {
    return Promise.reject(new Error("upgrade_already_running"));
  }

  state.running = true;
  state.status = "running";
  state.lastMessage = undefined;
  state.logs = [];
  state.steps = {};
  emit({ type: "upgrade-status", payload: getUpgradeStatus() });

  const doRun = async () => {
    let manifest: Manifest | null = null;
    let manifestUrl: string | null = null;

    if (MANIFEST_URL) {
      manifestUrl = MANIFEST_URL;
    }

    if (manifestUrl) {
      setStep("download", "running", "Fetching manifest…");
      appendLog(`Fetching manifest from ${manifestUrl}`);
      manifest = await fetchManifestFromUrl(manifestUrl);
      appendLog(`Manifest version: ${manifest.version}`);
      setStep("download", "running", "Downloading tarball…");
      fs.mkdirSync(UPDATES_DIR, { recursive: true });
      fs.mkdirSync(RELEASES_DIR, { recursive: true });
      const tarballPath = path.join(
        UPDATES_DIR,
        `herebox-${manifest.version}.tar.gz`,
      );
      setStep("verify", "running", "Verifying checksum…");
      await downloadAndVerify(manifest, tarballPath);
      setStep("download", "success", "Download complete");
      setStep("verify", "success", "Checksum OK");
      setStep("extract", "running", "Extracting…");
      const extractDir = path.join(RELEASES_DIR, `herebox-${manifest.version}`);
      fs.mkdirSync(extractDir, { recursive: true });
      await extractTarball(tarballPath, extractDir);
      setStep("extract", "success", "Extracted");
      appendLog(`Running install.sh from ${extractDir} → ${INSTALL_DIR_DEFAULT}`);
      await runInstallScript(INSTALL_DIR_DEFAULT, extractDir);
    } else {
      logger.info("upgrade starting (in-place)", { script: INSTALL_SCRIPT });
      appendLog(`Running install.sh in place (no manifest URL set)`);
      await runInstallScript(INSTALL_DIR_DEFAULT, REPO_ROOT);
    }
  };

  return doRun().catch((err) => {
    state.running = false;
    state.status = "error";
    const msg = err instanceof Error ? err.message : String(err);
    state.lastMessage = msg;
    if (state.steps["download"]?.status === "running") setStep("download", "error", msg);
    else if (state.steps["verify"]?.status === "running")
      setStep("verify", "error", msg);
    else if (state.steps["extract"]?.status === "running")
      setStep("extract", "error", msg);
    else emit({ type: "upgrade-status", payload: getUpgradeStatus() });
    logger.warn("upgrade failed", { err: msg });
    throw err;
  });
}
